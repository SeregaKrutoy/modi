package com.realcars;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.lang.reflect.Method;

public final class HornCompat {
    private static Method hook;

    private HornCompat() {
    }

    public static void notifyNpcs(ServerLevel level, Entity car, LivingEntity honker) {
        if (!FabricLoader.getInstance().isModLoaded("realnpcs")) {
            return;
        }
        if (hook == null && !resolve()) {
            return;
        }
        try {
            hook.invoke(null, level, car, honker);
        } catch (Throwable t) {
            hook = null;
        }
    }

    private static boolean resolve() {
        try {
            hook = Class.forName("com.realnpcs.HornReaction")
                    .getMethod("onHorn", ServerLevel.class, Entity.class, LivingEntity.class);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
