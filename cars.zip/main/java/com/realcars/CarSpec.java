package com.realcars;

import java.util.List;

public record CarSpec(
        String id,
        List<float[]> seats,
        float seatY,
        float width,
        float height,
        float maxSpeed,
        float accel,
        float turn,
        float drift,
        Float doorSplitZ
) {
    public int seatCount() {
        return seats.size();
    }
}
