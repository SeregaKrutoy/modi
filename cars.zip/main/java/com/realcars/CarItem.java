package com.realcars;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class CarItem extends Item {
    private final String carId;

    public CarItem(Properties properties, String carId) {
        super(properties);
        this.carId = carId;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        EntityType<?> type = ModContent.entityType(carId);
        Entity car = type.create(serverLevel, EntitySpawnReason.SPAWN_ITEM_USE);
        if (car == null) {
            return InteractionResult.FAIL;
        }
        car.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        car.setYRot(context.getRotation());
        if (!serverLevel.noCollision(car)) {
            return InteractionResult.FAIL;
        }
        serverLevel.addFreshEntity(car);
        context.getItemInHand().consume(1, context.getPlayer());
        return InteractionResult.SUCCESS;
    }
}
