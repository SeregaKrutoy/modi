package com.realcars;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record ImpactPayload(float impact, int kind) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ImpactPayload> TYPE =
            new CustomPacketPayload.Type<>(RealCarsMod.id("impact"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ImpactPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.FLOAT, ImpactPayload::impact,
                    ByteBufCodecs.VAR_INT, ImpactPayload::kind,
                    ImpactPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
