package com.realcars;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record HonkPayload(float pitch) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<HonkPayload> TYPE =
            new CustomPacketPayload.Type<>(RealCarsMod.id("honk"));

    public static final StreamCodec<RegistryFriendlyByteBuf, HonkPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.FLOAT, HonkPayload::pitch, HonkPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
