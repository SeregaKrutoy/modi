package com.realcars;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record LightsPayload(boolean on) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<LightsPayload> TYPE =
            new CustomPacketPayload.Type<>(RealCarsMod.id("lights"));

    public static final StreamCodec<RegistryFriendlyByteBuf, LightsPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, LightsPayload::on, LightsPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
