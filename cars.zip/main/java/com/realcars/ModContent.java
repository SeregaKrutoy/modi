package com.realcars;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModContent {
    private static final Map<String, EntityType<CarEntity>> ENTITIES = new LinkedHashMap<>();
    private static final Map<String, Item> ITEMS = new LinkedHashMap<>();
    public static final Map<String, SoundEvent> HORN_SOUNDS = new LinkedHashMap<>();
    public static final Map<String, Integer> HORN_TICKS = new LinkedHashMap<>();
    public static final Map<String, Float> CAR_HEALTH = new LinkedHashMap<>();

    static {
        HORN_TICKS.put("pickup", 20);
        HORN_TICKS.put("lowrider", 21);
        HORN_TICKS.put("taxi", 22);
        HORN_TICKS.put("sports", 17);
        HORN_TICKS.put("muscle", 24);
        CAR_HEALTH.put("pickup", 130f);
        CAR_HEALTH.put("lowrider", 100f);
        CAR_HEALTH.put("taxi", 105f);
        CAR_HEALTH.put("sports", 85f);
        CAR_HEALTH.put("muscle", 115f);
    }

    private ModContent() {
    }

    public static void register() {
        registerSound("misc.drift", CarEntity.DRIFT_SOUND);
        registerSound("misc.engine_start", CarEntity.ENGINE_START);
        registerSound("misc.engine_idle", CarEntity.ENGINE_IDLE);
        registerSound("misc.hit_body", CarEntity.HIT_BODY);
        registerSound("misc.hit_metal", CarEntity.HIT_METAL);
        registerSound("misc.crash", CarEntity.CRASH);
        registerSound("misc.repair", CarEntity.REPAIR);

        for (CarSpec spec : CarSpecs.all()) {
            ResourceKey<EntityType<?>> entityKey = ResourceKey.create(Registries.ENTITY_TYPE, RealCarsMod.id(spec.id()));
            EntityType<CarEntity> type = EntityType.Builder
                    .<CarEntity>of((t, level) -> new CarEntity(t, level, spec), MobCategory.MISC)
                    .sized(spec.width(), spec.height())
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(entityKey);
            Registry.register(BuiltInRegistries.ENTITY_TYPE, entityKey, type);
            ENTITIES.put(spec.id(), type);

            ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, RealCarsMod.id(spec.id()));
            Item item = new CarItem(new Item.Properties().setId(itemKey).stacksTo(1), spec.id());
            Registry.register(BuiltInRegistries.ITEM, itemKey, item);
            ITEMS.put(spec.id(), item);

            ResourceKey<SoundEvent> hornKey = ResourceKey.create(Registries.SOUND_EVENT, RealCarsMod.id("misc.horn_" + spec.id()));
            SoundEvent horn = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.horn_" + spec.id()));
            Registry.register(BuiltInRegistries.SOUND_EVENT, hornKey, horn);
            HORN_SOUNDS.put(spec.id(), horn);
        }
    }

    private static void registerSound(String id, SoundEvent sound) {
        Registry.register(BuiltInRegistries.SOUND_EVENT, ResourceKey.create(Registries.SOUND_EVENT, RealCarsMod.id(id)), sound);
    }

    public static EntityType<CarEntity> entityType(String id) {
        return ENTITIES.get(id);
    }

    public static Item item(String id) {
        return ITEMS.get(id);
    }

    public static float healthOf(String id) {
        return CAR_HEALTH.getOrDefault(id, 100f);
    }

    public static Map<String, EntityType<CarEntity>> entities() {
        return ENTITIES;
    }

    public static Map<String, Item> items() {
        return ITEMS;
    }
}
