package com.realcars;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class CarSpecs {
    private static List<CarSpec> all;

    private CarSpecs() {
    }

    public static synchronized List<CarSpec> all() {
        if (all == null) {
            all = load();
        }
        return all;
    }

    private static List<CarSpec> load() {
        try (InputStream in = CarSpecs.class.getResourceAsStream("/realcars_specs/cars.json")) {
            if (in == null) {
                throw new IllegalStateException("realcars_specs/cars.json not found");
            }
            JsonArray arr = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonArray();
            List<CarSpec> out = new ArrayList<>();
            for (JsonElement e : arr) {
                JsonObject o = e.getAsJsonObject();
                List<float[]> seats = new ArrayList<>();
                for (JsonElement s : o.getAsJsonArray("seats")) {
                    JsonArray p = s.getAsJsonArray();
                    seats.add(new float[]{p.get(0).getAsFloat(), p.get(1).getAsFloat()});
                }
                Float doorSplitZ = null;
                if (o.has("door_split") && !o.get("door_split").isJsonNull()) {
                    doorSplitZ = o.get("door_split").getAsFloat();
                }
                out.add(new CarSpec(
                        o.get("id").getAsString(), seats,
                        o.get("seat_y").getAsFloat(),
                        o.get("width").getAsFloat(), o.get("height").getAsFloat(),
                        o.get("max_speed").getAsFloat(), o.get("accel").getAsFloat(),
                        o.get("turn").getAsFloat(), o.get("drift").getAsFloat(),
                        doorSplitZ));
            }
            return Collections.unmodifiableList(out);
        } catch (IOException ex) {
            throw new RuntimeException("Cannot read car specs", ex);
        }
    }
}
