package com.realcars.client;

import net.minecraft.client.renderer.entity.state.EntityRenderState;

public class CarRenderState extends EntityRenderState {
    public float yaw;
    public float wheelRot;

    public float steer;

    public final float[] doors = new float[4];

    public float pitch;

    public float roll;

    public float passPitch;
    public float passRoll;

    public float bodyDrop;

    public float idleVibe;
    public float roadBump;

    public float engineJitter;

    public float time;

    public boolean lightsOn;
}
