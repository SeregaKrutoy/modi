package com.realcars.client;

import com.realcars.CarEntity;
import com.realcars.RealCarsMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fStack;

public final class SpeedometerHud {
    private static final Identifier TEXTURE = RealCarsMod.id("textures/gui/speedometer.png");

    private static final int SIZE = 108;
    private static final float SWEEP_START = 135f;
    private static final float SWEEP = 270f;
    private static final int COLOR_TICK = 0xB8E9EFF5;
    private static final int COLOR_TICK_MINOR = 0x55E9EFF5;
    private static final int COLOR_ACCENT = 0xFFFFB84D;
    private static final int COLOR_DRIFT = 0xFFFF5238;
    private static final int COLOR_TEXT = 0xFFF2F5F8;
    private static final int COLOR_MUTED = 0xFF98A4B0;

    private static final int COLOR_TICK_OFF = 0x50E9EFF5;
    private static final int COLOR_TICK_MINOR_OFF = 0x28E9EFF5;
    private static final int COLOR_TEXT_OFF = 0x66F2F5F8;
    private static final int COLOR_MUTED_OFF = 0x5598A4B0;

    private static float shownSpeed;
    private static boolean snapNext = true;
    private static float animTime;
    private static boolean prevEngine;
    private static float needleTest;

    private SpeedometerHud() {
    }

    public static void render(GuiGraphics g, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui
                || mc.options.getCameraType().isMirrored()
                || !(mc.player.getVehicle() instanceof CarEntity car)) {
            snapNext = true;
            return;
        }

        boolean on = car.engineOn;
        if (on && !prevEngine) {
            needleTest = 1.05f;
        }
        prevEngine = on;

        float dt = tickCounter.getGameTimeDeltaTicks();
        animTime += dt;

        int x0 = g.guiWidth() - SIZE - 8;
        int y0 = g.guiHeight() - SIZE - 8;
        float cx = x0 + SIZE / 2f;
        float cy = y0 + SIZE / 2f;

        float maxKph = car.spec.maxSpeed() * 72f;
        float gaugeMax = 20f * (float) Math.ceil(maxKph * 1.05f / 20f);

        float target = Mth.clamp(car.hudSpeed, 0f, gaugeMax);
        if (snapNext) {
            shownSpeed = target;
            snapNext = false;
        } else {
            shownSpeed += (target - shownSpeed) * Math.min(1f, dt * 0.55f);
        }
        float frac = Mth.clamp(shownSpeed / gaugeMax, 0f, 1f);
        if (needleTest > 0f) {
            needleTest = Math.max(0f, needleTest - dt);
            float t = 1f - needleTest / 1.05f;
            frac = t < 0.5f ? t * 2f : (1f - t) * 2f;
        }
        int tickColor = on ? COLOR_TICK : COLOR_TICK_OFF;
        int tickMinor = on ? COLOR_TICK_MINOR : COLOR_TICK_MINOR_OFF;
        int textColor = on ? COLOR_TEXT : COLOR_TEXT_OFF;
        int mutedColor = on ? COLOR_MUTED : COLOR_MUTED_OFF;

        boolean drifting = on && car.hudSlip > 0.35f && car.hudSpeed > 30f;

        boolean redline = on && needleTest <= 0f && shownSpeed > gaugeMax * 0.92f;
        float pulse = 0.5f + 0.5f * Mth.sin(animTime * 0.55f);
        float hotPulse = 0.5f + 0.5f * Mth.sin(animTime * 0.9f);
        int accent = drifting ? COLOR_DRIFT
                : (redline ? lerpColor(0xFFF03C1E, 0xFFFFC06A, hotPulse) : COLOR_ACCENT);

        g.blit(TEXTURE, x0, y0, x0 + SIZE, y0 + SIZE, 0f, 1f, 0f, 1f);

        Matrix3x2fStack pose = g.pose();

        int majors = Math.max(1, Math.round(gaugeMax / 20f));
        for (int i = 0; i <= majors * 2; i++) {
            float t = i / (float) (majors * 2);
            float angle = SWEEP_START + t * SWEEP;
            boolean major = (i % 2) == 0;
            drawDialRect(g, pose, cx, cy, angle, major ? 34f : 37f, 41f, major ? 2 : 1,
                    major ? tickColor : tickMinor);
        }

        if (on) {
            float sweepLen = frac * SWEEP;
            int segments = Math.max(1, (int) (sweepLen / 2.5f));
            for (int i = 0; i < segments; i++) {
                float t = (i + 0.5f) / segments;
                float angle = SWEEP_START + t * sweepLen;
                drawDialRect(g, pose, cx, cy, angle, 30f, 33f, 2, (accent & 0x00FFFFFF) | 0xE0000000);
            }
        }

        if (on) {

            float needleAngle = SWEEP_START + frac * SWEEP;
            pose.pushMatrix();
            pose.translate(cx, cy);
            pose.rotate((needleAngle + 90f) * Mth.DEG_TO_RAD);
            g.fill(-2, -31, 2, 6, 0xFF0B0E13);
            g.fill(-1, -30, 1, 4, accent);
            pose.popMatrix();

            g.fill((int) cx - 4, (int) cy - 3, (int) cx + 4, (int) cy + 3, 0xF0080B10);
            g.fill((int) cx - 3, (int) cy - 4, (int) cx + 3, (int) cy + 4, 0xF0080B10);
            g.fill((int) cx - 1, (int) cy - 1, (int) cx + 1, (int) cy + 1, accent);
        }

        String speedText = Integer.toString(Math.round(shownSpeed));
        int speedColor = redline ? lerpColor(0xFFFF4530, 0xFFFFD9CF, hotPulse) : textColor;
        pose.pushMatrix();
        pose.translate(cx, cy + 8f);
        pose.scale(2f, 2f);
        g.drawString(mc.font, speedText, -mc.font.width(speedText) / 2, -4, speedColor, true);
        pose.popMatrix();

        g.drawCenteredString(mc.font, Component.translatable("realcars.speedometer.unit"),
                (int) cx, (int) cy + 19, mutedColor);

        if (drifting) {
            g.drawCenteredString(mc.font, Component.translatable("realcars.speedometer.drift"),
                    (int) cx, (int) cy - 26, lerpColor(COLOR_DRIFT, 0xFFFFC06A, pulse));
        } else if (on && car.hudReverse) {
            g.drawCenteredString(mc.font, "R", (int) cx, (int) cy - 26, 0xFFFF5A4A);
        }

        float hp = car.healthRatio();
        if (hp < 0.999f) {
            int barW = 72;
            int barX = (int) cx - barW / 2;
            int barY = y0 + 92;
            g.fill(barX - 1, barY - 1, barX + barW + 1, barY + 5, 0x88000000);
            int barColor = hp > 0.6f ? 0xFF7ED957
                    : (hp > 0.3f ? COLOR_ACCENT : lerpColor(0xFFFF4530, 0xFFFFAFA0, pulse));
            int fillW = Math.max(2, Math.round(barW * Mth.clamp(hp, 0f, 1f)));
            g.fill(barX, barY, barX + fillW, barY + 4, barColor);
        }
    }

    private static void drawDialRect(GuiGraphics g, Matrix3x2fStack pose, float cx, float cy,
                                     float angleDeg, float rIn, float rOut, int width, int color) {
        pose.pushMatrix();
        pose.translate(cx, cy);
        pose.rotate((angleDeg + 90f) * Mth.DEG_TO_RAD);
        int ri = Math.round(rIn);
        int ro = Math.round(rOut);
        g.fill(-(width - width / 2), -ro, width / 2, -ri, color);
        pose.popMatrix();
    }

    private static int lerpColor(int from, int to, float t) {
        int r = (int) (((from >> 16) & 0xFF) + (((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * t);
        int gr = (int) (((from >> 8) & 0xFF) + (((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * t);
        int b = (int) ((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }
}
