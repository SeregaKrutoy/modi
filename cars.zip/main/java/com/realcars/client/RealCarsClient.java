package com.realcars.client;

import com.realcars.CarEntity;
import com.realcars.CarSpec;
import com.realcars.CarSpecs;
import com.realcars.HonkPayload;
import com.realcars.LightsPayload;
import com.realcars.ModContent;
import com.realcars.RealCarsMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import org.lwjgl.glfw.GLFW;

public class RealCarsClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(RealCarsMod.id("cars"));
    private static final KeyMapping HORN = new KeyMapping("key.realcars.horn", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY);

    private static final KeyMapping LIGHTS = new KeyMapping("key.realcars.lights", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY);

    @Override
    public void onInitializeClient() {
        for (CarSpec spec : CarSpecs.all()) {
            final String id = spec.id();
            ModelLayerLocation layer = new ModelLayerLocation(RealCarsMod.id(id), "main");
            EntityModelLayerRegistry.registerModelLayer(layer, () -> CarModel.createLayer(id));
            EntityRenderers.register(ModContent.entityType(id), ctx -> new CarRenderer(ctx, id, layer));
        }

        HudElementRegistry.addLast(RealCarsMod.id("speedometer"), SpeedometerHud::render);

        KeyBindingHelper.registerKeyBinding(HORN);
        KeyBindingHelper.registerKeyBinding(LIGHTS);
        ClientTickEvents.END_CLIENT_TICK.register(RealCarsClient::tickHorn);
        ClientTickEvents.END_CLIENT_TICK.register(RealCarsClient::tickLights);
        ClientTickEvents.END_CLIENT_TICK.register(HeadlightLights::tick);
    }

    private static void tickHorn(Minecraft client) {
        LocalPlayer player = client.player;
        if (player == null) {
            return;
        }
        while (HORN.consumeClick()) {
            if (player.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == player) {
                float pitch = 0.97F + car.getRandom().nextFloat() * 0.06F;
                if (car.honk(pitch)) {
                    ClientPlayNetworking.send(new HonkPayload(pitch));
                }
            }
        }
    }

    private static void tickLights(Minecraft client) {
        LocalPlayer player = client.player;
        if (player == null) {
            return;
        }
        while (LIGHTS.consumeClick()) {
            if (player.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == player) {
                ClientPlayNetworking.send(new LightsPayload(!car.lightsOn()));
            }
        }
    }
}
