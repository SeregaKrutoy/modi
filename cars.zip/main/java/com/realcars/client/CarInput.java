package com.realcars.client;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;

public final class CarInput {
    private CarInput() {
    }

    public static boolean handbrake(LivingEntity driver) {
        return driver instanceof LocalPlayer local && local.input.keyPresses.jump();
    }
}
