package com.realcars.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class CarModel extends EntityModel<CarRenderState> {
    private static final String[] WHEELS = {"wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"};

    private static final String[] DOORS = {"door_lf", "door_lr", "door_rf", "door_rr"};
    private final ModelPart[] wheels = new ModelPart[WHEELS.length];
    private final ModelPart[] doors = new ModelPart[DOORS.length];

    private final ModelPart body;
    private final ModelPart steering;
    private final float steerBaseY;

    public CarModel(ModelPart root) {
        super(root);
        this.body = root.getChild("body");
        this.steering = root.hasChild("steer") ? root.getChild("steer") : null;
        this.steerBaseY = this.steering != null ? this.steering.y : 0.0F;
        for (int i = 0; i < WHEELS.length; i++) {
            wheels[i] = root.getChild(WHEELS[i]);
        }
        for (int i = 0; i < DOORS.length; i++) {

            doors[i] = root.hasChild(DOORS[i]) ? root.getChild(DOORS[i]) : null;
        }
    }

    @Override
    public void setupAnim(CarRenderState state) {
        super.setupAnim(state);
        for (int i = 0; i < wheels.length; i++) {
            ModelPart w = wheels[i];
            w.xRot = state.wheelRot;

            w.yRot = i < 2 ? -state.steer * 0.55F : 0.0F;
        }
        for (int i = 0; i < doors.length; i++) {
            ModelPart door = doors[i];
            if (door == null) {
                continue;
            }
            float open = state.doors[i] * 1.08F;
            door.yRot = i < 2 ? open : -open;
        }

        float susp = bodySuspension(state);
        this.body.y = susp;
        for (int i = 0; i < doors.length; i++) {
            if (doors[i] != null) {
                doors[i].y = susp;
            }
        }
        if (this.steering != null) {
            this.steering.y = this.steerBaseY + susp;

            this.steering.zRot = state.steer * 1.9F;
        }
    }

    public static LayerDefinition createLayer(String carId) {
        JsonObject json = loadModel(carId);
        int tex = json.get("texture").getAsInt();
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        for (JsonElement pe : json.getAsJsonArray("parts")) {
            JsonObject p = pe.getAsJsonObject();
            CubeListBuilder builder = CubeListBuilder.create();
            for (JsonElement ce : p.getAsJsonArray("cubes")) {
                JsonObject c = ce.getAsJsonObject();
                builder.texOffs(c.get("u").getAsInt(), c.get("v").getAsInt()).addBox(
                        c.get("x").getAsFloat(), c.get("y").getAsFloat(), c.get("z").getAsFloat(),
                        c.get("w").getAsFloat(), c.get("h").getAsFloat(), c.get("d").getAsFloat(),
                        new CubeDeformation(c.get("grow").getAsFloat()));
            }
            JsonArray pv = p.getAsJsonArray("pivot");
            root.addOrReplaceChild(p.get("name").getAsString(), builder,
                    PartPose.offset(pv.get(0).getAsFloat(), pv.get(1).getAsFloat(), pv.get(2).getAsFloat()));
        }
        return LayerDefinition.create(mesh, tex, tex);
    }

    private static JsonObject loadModel(String carId) {
        String path = "/assets/realcars/car_models/" + carId + ".json";
        try (InputStream in = CarModel.class.getResourceAsStream(path)) {
            if (in == null) {
                throw new IllegalStateException("Missing model " + path);
            }
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (IOException e) {
            throw new RuntimeException("Cannot read model " + path, e);
        }
    }

    private static final Map<String, float[]> LAMP_CACHE = new ConcurrentHashMap<>();

    public static float[] lampInfo(String carId) {
        return LAMP_CACHE.computeIfAbsent(carId, CarModel::parseLampInfo);
    }

    private static float[] parseLampInfo(String carId) {
        JsonObject json = loadModel(carId);
        float minZ = Float.MAX_VALUE;
        for (JsonElement pe : json.getAsJsonArray("parts")) {
            for (JsonElement ce : pe.getAsJsonObject().getAsJsonArray("cubes")) {
                minZ = Math.min(minZ, ce.getAsJsonObject().get("z").getAsFloat());
            }
        }
        float fasciaZ = Float.MAX_VALUE;
        for (JsonElement pe : json.getAsJsonArray("parts")) {
            for (JsonElement ce : pe.getAsJsonObject().getAsJsonArray("cubes")) {
                float z = ce.getAsJsonObject().get("z").getAsFloat();
                if (z > minZ && z < fasciaZ) {
                    fasciaZ = z;
                }
            }
        }
        float fasciaY = Float.MAX_VALUE;
        for (JsonElement pe : json.getAsJsonArray("parts")) {
            for (JsonElement ce : pe.getAsJsonObject().getAsJsonArray("cubes")) {
                JsonObject cube = ce.getAsJsonObject();
                if (cube.get("z").getAsFloat() == fasciaZ) {
                    fasciaY = Math.min(fasciaY, cube.get("y").getAsFloat());
                }
            }
        }
        return new float[]{minZ, fasciaY};
    }

    public static float bodySuspension(CarRenderState state) {
        return state.bodyDrop * 16.0F
                + Mth.sin(state.time * 2.73F + 1.6F) * state.idleVibe * 16.0F
                + Mth.sin(state.wheelRot * 2.2F) * state.roadBump * 16.0F;
    }
}
