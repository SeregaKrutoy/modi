package com.realcars.client;

import com.realcars.CarEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class HeadlightLights {
    private static final double RANGE = 72.0;

    private static final double[] AHEAD = {1.6, 4.2, 6.8};

    private static final Map<Integer, BlockPos[]> PLACED = new HashMap<>();

    private static ClientLevel trackedLevel;

    private HeadlightLights() {
    }

    public static void tick(Minecraft client) {
        ClientLevel level = client.level;
        if (level == null) {
            PLACED.clear();
            trackedLevel = null;
            return;
        }
        if (level != trackedLevel) {
            PLACED.clear();
            trackedLevel = level;
        }
        Vec3 center = client.player != null ? client.player.position() : null;
        List<Integer> active = new ArrayList<>();
        for (Entity entity : level.entitiesForRendering()) {
            if (!(entity instanceof CarEntity car) || !car.lightsOn()) {
                continue;
            }
            if (center != null && car.position().distanceToSqr(center) > RANGE * RANGE) {
                continue;
            }
            active.add(car.getId());
            BlockPos[] target = targetPositions(car);
            BlockPos[] previous = PLACED.get(car.getId());
            if (previous != null) {
                for (BlockPos old : previous) {
                    if (!contains(target, old)) {
                        clear(level, old);
                    }
                }
            }
            for (BlockPos pos : target) {
                place(level, pos);
            }
            PLACED.put(car.getId(), target);
        }
        if (PLACED.size() > active.size()) {
            PLACED.entrySet().removeIf(entry -> {
                if (active.contains(entry.getKey())) {
                    return false;
                }
                for (BlockPos pos : entry.getValue()) {
                    clear(level, pos);
                }
                return true;
            });
        }
    }

    private static BlockPos[] targetPositions(CarEntity car) {
        float yaw = car.getYRot() * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw);
        double fz = Mth.cos(yaw);
        double y = car.getY() + 0.5;
        BlockPos[] positions = new BlockPos[AHEAD.length];
        for (int i = 0; i < AHEAD.length; i++) {
            positions[i] = BlockPos.containing(car.getX() + fx * AHEAD[i], y, car.getZ() + fz * AHEAD[i]);
        }
        return positions;
    }

    private static boolean contains(BlockPos[] positions, BlockPos pos) {
        for (BlockPos candidate : positions) {
            if (candidate.equals(pos)) {
                return true;
            }
        }
        return false;
    }

    private static void place(ClientLevel level, BlockPos pos) {
        if (!loaded(level, pos)) {
            return;
        }
        BlockState state = level.getBlockState(pos);
        if (!state.isAir() && !state.is(Blocks.LIGHT)) {
            return;
        }
        BlockState light = Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 15);
        level.setBlock(pos, light, Block.UPDATE_ALL);
    }

    private static void clear(ClientLevel level, BlockPos pos) {
        if (!loaded(level, pos)) {
            return;
        }
        if (level.getBlockState(pos).is(Blocks.LIGHT)) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    private static boolean loaded(ClientLevel level, BlockPos pos) {
        return level.getChunkSource().hasChunk(SectionPos.blockToSectionCoord(pos.getX()), SectionPos.blockToSectionCoord(pos.getZ()));
    }
}
