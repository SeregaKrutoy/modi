package com.realcars.client;

import com.realcars.ImpactPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public final class ImpactSender {
    private ImpactSender() {
    }

    public static void send(float impact, int kind) {
        ClientPlayNetworking.send(new ImpactPayload(impact, kind));
    }
}
