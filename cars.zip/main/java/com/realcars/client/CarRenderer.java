package com.realcars.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.realcars.CarEntity;
import com.realcars.RealCarsMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CarRenderer extends EntityRenderer<CarEntity, CarRenderState> {
    private static final RenderType GLOW_LAYER = RenderTypes.entityTranslucentEmissive(RealCarsMod.id("textures/entity/light_glow.png"));

    private static final RenderType BEAM_LAYER = RenderTypes.entityTranslucentEmissive(RealCarsMod.id("textures/entity/light_beam.png"));

    private final CarModel model;
    private final Identifier texture;
    private final float[] lamps;

    public CarRenderer(EntityRendererProvider.Context context, String carId, ModelLayerLocation layer) {
        super(context);
        this.model = new CarModel(context.bakeLayer(layer));
        this.texture = RealCarsMod.id("textures/entity/" + carId + ".png");
        this.lamps = CarModel.lampInfo(carId);
        this.shadowRadius = 1.1f;
    }

    @Override
    public CarRenderState createRenderState() {
        return new CarRenderState();
    }

    @Override
    public void extractRenderState(CarEntity entity, CarRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.yaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        state.wheelRot = Mth.lerp(partialTick, entity.wheelRotO, entity.wheelRot);
        state.steer = Mth.lerp(partialTick, entity.steerVisO, entity.steerVis);
        for (int i = 0; i < state.doors.length; i++) {
            state.doors[i] = Mth.lerp(partialTick, entity.doorOpenO[i], entity.doorOpen[i]);
        }
        state.pitch = Mth.lerp(partialTick, entity.bodyPitchO, entity.bodyPitch);
        state.roll = Mth.lerp(partialTick, entity.bodyRollO, entity.bodyRoll);
        state.passPitch = Mth.lerp(partialTick, entity.passPitchO, entity.passPitch);
        state.passRoll = Mth.lerp(partialTick, entity.passRollO, entity.passRoll);
        state.bodyDrop = Mth.lerp(partialTick, entity.bodyDropO, entity.bodyDrop);
        state.idleVibe = entity.idleVibe;
        state.roadBump = entity.roadBump;
        state.engineJitter = entity.engineJitter;
        state.time = entity.tickCount + partialTick;
        state.lightsOn = entity.lightsOn();
    }

    @Override
    public void submit(CarRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera) {
        poseStack.pushPose();

        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f - state.yaw));

        poseStack.translate(0.0f, -0.5625f, 0.0f);

        poseStack.mulPose(Axis.XP.rotationDegrees(state.pitch + state.passPitch));
        poseStack.mulPose(Axis.ZP.rotationDegrees(state.roll + state.passRoll));
        poseStack.translate(0.0f, 0.5625f, 0.0f);
        poseStack.scale(-1.0f, -1.0f, 1.0f);

        float jitter = state.engineJitter;
        if (jitter > 0.01f) {
            float t = state.time * 5.7f;
            poseStack.translate(Mth.sin(t * 1.7f) * 0.022f * jitter,
                    Mth.sin(t * 2.3f + 1.1f) * 0.017f * jitter, 0.0f);
        }
        poseStack.translate(0.0f, -1.501f, 0.0f);
        collector.submitModel(model, state, poseStack, model.renderType(texture),
                state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor, null);
        if (state.lightsOn) {
            this.submitLights(state, poseStack, collector);
        }
        poseStack.popPose();
        super.submit(state, poseStack, collector, camera);
    }

    private void submitLights(CarRenderState state, PoseStack poseStack, SubmitNodeCollector collector) {
        float fascia = this.lamps[1] + CarModel.bodySuspension(state);
        float z0 = this.lamps[0] + 1.5f;
        float z1 = z0 - 52.0f;
        collector.submitCustomGeometry(poseStack, GLOW_LAYER, (pose, vertexConsumer) -> {
            glow(vertexConsumer, pose, -12.4f, fascia + 1.5f, z0);
            glow(vertexConsumer, pose, 12.4f, fascia + 1.5f, z0);
        });
        collector.submitCustomGeometry(poseStack, BEAM_LAYER, (pose, vertexConsumer) -> {
            groundBeam(vertexConsumer, pose, -12.4f, fascia + 1.5f, z0, z1, 200);
            groundBeam(vertexConsumer, pose, 12.4f, fascia + 1.5f, z0, z1, 200);
            airBeam(vertexConsumer, pose, -12.4f, fascia + 1.5f, z0, z1, 130);
            airBeam(vertexConsumer, pose, 12.4f, fascia + 1.5f, z0, z1, 130);
        });
    }

    private static void glow(VertexConsumer vertexConsumer, PoseStack.Pose pose, float cx, float cy, float z) {
        vertex(vertexConsumer, pose, cx - 2.6f, cy - 1.5f, z, 0.0f, 0.0f, 255);
        vertex(vertexConsumer, pose, cx + 2.6f, cy - 1.5f, z, 1.0f, 0.0f, 255);
        vertex(vertexConsumer, pose, cx + 2.6f, cy + 1.5f, z, 1.0f, 1.0f, 255);
        vertex(vertexConsumer, pose, cx - 2.6f, cy + 1.5f, z, 0.0f, 1.0f, 255);
    }

    private static void groundBeam(VertexConsumer vertexConsumer, PoseStack.Pose pose, float cx, float cy, float z0, float z1, int alpha) {
        float far = cx * 1.15f;
        vertex(vertexConsumer, pose, cx - 1.8f, cy + 0.6f, z0, 0.0f, 0.0f, alpha);
        vertex(vertexConsumer, pose, cx + 1.8f, cy + 0.6f, z0, 1.0f, 0.0f, alpha);
        vertex(vertexConsumer, pose, far + 7.0f, 24.0f, z1, 1.0f, 1.0f, alpha);
        vertex(vertexConsumer, pose, far - 7.0f, 24.0f, z1, 0.0f, 1.0f, alpha);
    }

    private static void airBeam(VertexConsumer vertexConsumer, PoseStack.Pose pose, float cx, float cy, float z0, float z1, int alpha) {
        float far = cx * 1.15f;
        vertex(vertexConsumer, pose, cx, cy - 1.2f, z0, 0.5f, 0.0f, alpha);
        vertex(vertexConsumer, pose, cx, cy + 1.2f, z0, 0.5f, 0.0f, alpha);
        vertex(vertexConsumer, pose, far + 6.0f, 24.0f, z1, 1.0f, 1.0f, alpha);
        vertex(vertexConsumer, pose, far - 6.0f, 24.0f, z1, 0.0f, 1.0f, alpha);
    }

    private static void vertex(VertexConsumer vertexConsumer, PoseStack.Pose pose, float x, float y, float z, float u, float v, int alpha) {
        vertexConsumer.addVertex(pose, x / 16.0f, y / 16.0f, z / 16.0f)
                .setColor(255, 244, 210, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0f, 1.0f, 0.0f);
    }
}
