package com.realcars;

import com.realcars.client.CarInput;
import com.realcars.client.ImpactSender;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.BlockTags;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.InterpolationHandler;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class CarEntity extends Entity {
    public final CarSpec spec;

    public static final SoundEvent DRIFT_SOUND = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.drift"));

    public static final SoundEvent HIT_BODY = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.hit_body"));

    public static final SoundEvent HIT_METAL = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.hit_metal"));

    public static final SoundEvent CRASH = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.crash"));

    public static final SoundEvent REPAIR = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.repair"));

    private static final EntityDataAccessor<Float> DATA_HEALTH = SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.FLOAT);

    private static final EntityDataAccessor<Boolean> DATA_LIGHTS = SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.BOOLEAN);

    private float speed;

    private float side;

    public float wheelRot;
    public float wheelRotO;

    public float steerVis;
    public float steerVisO;

    public float hudSpeed;

    public float hudSlip;

    public boolean hudReverse;

    public boolean engineOn;

    public float engineJitter;

    private int engineStartTicks = -1;
    private int engineIdleTimer;

    public static final int DOOR_LF = 0, DOOR_LR = 1, DOOR_RF = 2, DOOR_RR = 3;

    public final float[] doorOpen = new float[4];
    public final float[] doorOpenO = new float[4];
    private final int[] doorHold = new int[4];

    private final float[] doorVel = new float[4];

    private final float[] seatAnim;

    public static final SoundEvent ENGINE_START = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.engine_start"));

    public static final SoundEvent ENGINE_IDLE = SoundEvent.createVariableRangeEvent(RealCarsMod.id("misc.engine_idle"));

    public float bodyPitch, bodyPitchO, bodyRoll, bodyRollO;

    public float passPitch, passPitchO, passRoll, passRollO;
    private float passPitchVel, passRollVel;

    public float bodyDrop, bodyDropO;
    private float bodyDropVel;

    private float fallSpeed;
    private boolean wasOnGround = true;

    public float idleVibe, roadBump;

    private float burnout;

    private double prevX, prevZ;
    private float prevYaw;
    private float lastDYaw;
    private float prevHudSpeed;
    private boolean prevInit;
    private int screechCooldown;
    private int honkCooldown;
    private int impactCooldown;
    private int repairCooldown;
    private int impactReportCooldown;

    private double velX, velZ;
    private double prevYPos;
    private double tickDist;
    private double tickDY;
    private double lastTickDist;
    private double lastTickDY;
    private double pendingCrash;
    private int pendingKind;
    private double lastDirX;
    private double lastDirZ;
    private final double[] crashWindow = new double[10];
    private int crashWindowCursor;

    private UUID[] prevPax = new UUID[0];
    private UUID prevDriver;

    private final InterpolationHandler interpolation = new InterpolationHandler(this, 3);

    public CarEntity(EntityType<?> type, Level level, CarSpec spec) {
        super(type, level);
        this.spec = spec;
        this.seatAnim = new float[spec.seatCount()];
        Arrays.fill(this.seatAnim, 1f);
        this.entityData.set(DATA_HEALTH, ModContent.healthOf(spec.id()));
    }

    @Override
    public InterpolationHandler getInterpolation() {
        return this.interpolation;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_HEALTH, 100f);
        builder.define(DATA_LIGHTS, false);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        this.entityData.set(DATA_HEALTH, input.getFloatOr("Health", this.getMaxHealth()));
        this.entityData.set(DATA_LIGHTS, input.getBooleanOr("Lights", false));
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        output.putFloat("Health", this.getHealth());
        output.putBoolean("Lights", this.lightsOn());
    }

    public float getHealth() {
        return this.entityData.get(DATA_HEALTH);
    }

    public float getMaxHealth() {
        return ModContent.healthOf(this.spec.id());
    }

    public float healthRatio() {
        return Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f);
    }

    public boolean lightsOn() {
        return this.entityData.get(DATA_LIGHTS);
    }

    public void setLights(boolean on) {
        this.entityData.set(DATA_LIGHTS, on);
    }

    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public float maxUpStep() {
        return 1.0F;
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (this.isRemoved()) {
            return false;
        }
        Entity attacker = source.getEntity();
        if (attacker != null && this.hasPassenger(attacker)) {
            return false;
        }
        if (source.is(DamageTypeTags.IS_FIRE)) {
            return false;
        }
        if (attacker instanceof Player player && player.isShiftKeyDown()) {
            if (!this.getPassengers().isEmpty()) {
                return false;
            }
            if (!player.getAbilities().instabuild) {
                this.spawnAtLocation(level, new ItemStack(ModContent.item(spec.id())));
            }
            this.discard();
            return true;
        }
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            this.ejectPassengers();
            this.discard();
            return true;
        }
        this.playCarSound(HIT_METAL, 0.9f + this.getRandom().nextFloat() * 0.2f, 0.9f + this.getRandom().nextFloat() * 0.3f);
        this.damageCar(level, amount * 3f);
        return true;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().size() < spec.seatCount();
    }

    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity living ? living : null;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        int idx = this.getPassengers().indexOf(passenger);
        if (idx < 0) {
            return;
        }
        idx = Math.min(idx, spec.seatCount() - 1);
        float[] seat = spec.seats().get(idx);
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double sin = Mth.sin(yaw);
        double cos = Mth.cos(yaw);

        float left = seat[0];
        float fwd = seat[1];
        double y = this.getY() + spec.seatY();

        float t = idx < this.seatAnim.length ? Mth.clamp(this.seatAnim[idx], 0f, 1f) : 1f;
        if (t < 1f) {
            float sm = t * t * (3f - 2f * t);
            float side = seat[0] >= 0f ? 1f : -1f;
            left = Mth.lerp(sm, seat[0] + side * 0.95f, seat[0]);
            fwd = Mth.lerp(sm, seat[1] + 0.35f, seat[1]);
            y += 0.85f * (1f - sm);
        }
        double x = this.getX() + (-sin) * fwd + cos * left;
        double z = this.getZ() + cos * fwd + sin * left;
        callback.accept(passenger, x, y, z);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        int oldIdx = this.getPassengers().indexOf(passenger);
        super.removePassenger(passenger);
        if (this.level() instanceof ServerLevel) {
            this.dismountOnServer(passenger, oldIdx);
        }
    }

    private void dismountOnServer(Entity passenger, int oldIdx) {
        double vx = this.velX;
        double vz = this.velZ;
        double v = Math.sqrt(vx * vx + vz * vz);
        int seatIdx = Mth.clamp(oldIdx, 0, spec.seatCount() - 1);
        float[] seat = spec.seats().get(seatIdx);
        float sgn = seat[0] >= 0f ? 1f : -1f;
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double sideX = Mth.cos(yaw) * sgn;
        double sideZ = Mth.sin(yaw) * sgn;
        if (v > 0.12) {

            passenger.setDeltaMovement(vx * 0.8 + sideX * 0.24, 0.36, vz * 0.8 + sideZ * 0.24);
            passenger.hurtMarked = true;
        } else {

            double px = this.getX() + sideX * (Math.abs(seat[0]) + 1.0);
            double pz = this.getZ() + sideZ * (Math.abs(seat[0]) + 1.0);
            AABB box = passenger.getDimensions(passenger.getPose()).makeBoundingBox(px, this.getY(), pz);
            if (this.level().noCollision(passenger, box)) {
                if (passenger instanceof ServerPlayer sp) {
                    sp.connection.teleport(px, this.getY(), pz, sp.getYRot(), sp.getXRot());
                } else {
                    passenger.teleportTo(px, this.getY(), pz);
                }
            }
        }
        if (this.getPassengers().isEmpty()) {

            double fx = -Mth.sin(yaw);
            double fz = Mth.cos(yaw);
            double lx = Mth.cos(yaw);
            double lz = Mth.sin(yaw);
            this.speed = (float) (vx * fx + vz * fz);
            this.side = (float) (vx * lx + vz * lz);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.honkCooldown > 0) {
            this.honkCooldown--;
        }
        if (this.impactCooldown > 0) {
            this.impactCooldown--;
        }
        if (this.repairCooldown > 0) {
            this.repairCooldown--;
        }
        if (this.impactReportCooldown > 0) {
            this.impactReportCooldown--;
        }
        this.interpolation.interpolate();
        this.wheelRotO = this.wheelRot;
        this.steerVisO = this.steerVis;
        for (int i = 0; i < 4; i++) {
            this.doorOpenO[i] = this.doorOpen[i];
        }
        this.bodyPitchO = this.bodyPitch;
        this.bodyRollO = this.bodyRoll;
        this.passPitchO = this.passPitch;
        this.passRollO = this.passRoll;
        this.bodyDropO = this.bodyDrop;
        this.resetFallDistance();

        if (this.isLocalInstanceAuthoritative()) {
            this.drive();
        } else {
            this.speed = 0f;
            this.side = 0f;
            this.setDeltaMovement(Vec3.ZERO);
        }

        for (Entity p : this.getPassengers()) {
            p.resetFallDistance();
            if (p instanceof LivingEntity living) {
                living.setYBodyRot(this.getYRot());
            }
        }

        this.updateMotionReadout();

        if (this.level() instanceof ServerLevel server) {
            this.serverCollisions(server);
            if (this.isRemoved()) {
                return;
            }
        }

        this.animateCar();
    }

    private void updateMotionReadout() {
        if (!prevInit) {
            prevX = getX();
            prevZ = getZ();
            prevYaw = getYRot();
            this.prevYPos = getY();
            prevInit = true;
        }
        double dx = getX() - prevX;
        double dz = getZ() - prevZ;
        double dy = getY() - this.prevYPos;
        double dist = Math.sqrt(dx * dx + dz * dz);
        prevX = getX();
        prevZ = getZ();
        this.prevYPos = getY();
        this.velX = dx;
        this.velZ = dz;
        this.tickDist = dist;
        this.tickDY = dy;
        if (dist > 0.05) {
            this.lastDirX = dx / dist;
            this.lastDirZ = dz / dist;
        }

        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double fwd = dx * (-Mth.sin(yaw)) + dz * Mth.cos(yaw);
        double lat = dx * Mth.cos(yaw) + dz * Mth.sin(yaw);

        this.wheelRot += (float) ((fwd >= 0 ? dist : -dist) / 0.3125);

        this.hudSpeed = (float) Math.min(dist, 4.0) * 72.0f;
        this.hudReverse = fwd < -0.02;
        this.hudSlip = (float) Math.min(1.0, Math.abs(lat) / 0.5);

        float dYaw = Mth.wrapDegrees(this.getYRot() - this.prevYaw);
        this.prevYaw = this.getYRot();
        this.lastDYaw = dYaw;
        float steerTarget = Mth.clamp(-dYaw / 5.0f, -1.0f, 1.0f);
        if (Math.abs(steerTarget) < 0.02f) {
            steerTarget = 0f;
        }
        this.steerVis += (steerTarget - this.steerVis) * 0.4f;

        this.driftEffects(lat);
    }

    private void driftEffects(double lat) {
        if (this.screechCooldown > 0) {
            this.screechCooldown--;
        }
        boolean sliding = this.hudSlip > 0.3f && this.hudSpeed > 25.0f && this.onGround();
        if (!sliding) {
            return;
        }

        if (!this.level().isClientSide()) {
            if (this.screechCooldown == 0) {
                float volume = 1.30f + 0.50f * this.hudSlip;
                float pitch = 0.96f + this.getRandom().nextFloat() * 0.08f;
                this.playCarSound(DRIFT_SOUND, volume, pitch);
                this.screechCooldown = 14 + this.getRandom().nextInt(6);
            }
            return;
        }

        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double lx = Mth.cos(yaw);
        double lz = Mth.sin(yaw);
        double slide = Math.signum(lat);
        int count = this.hudSlip > 0.6f ? 2 : 1;
        for (int i = 0; i < count; i++) {
            this.spawnTireSmoke(-lx * slide * 0.05, -lz * slide * 0.05);
        }
    }

    private void spawnTireSmoke(double vx, double vz) {
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw);
        double fz = Mth.cos(yaw);
        double lx = Mth.cos(yaw);
        double lz = Mth.sin(yaw);
        double corner = this.getRandom().nextBoolean() ? 1.0 : -1.0;
        this.level().addParticle(ParticleTypes.WHITE_SMOKE,
                this.getX() - fx * 0.75 + lx * 0.6 * corner,
                this.getY() + 0.11,
                this.getZ() - fz * 0.75 + lz * 0.6 * corner,
                vx + (this.getRandom().nextDouble() - 0.5) * 0.04,
                0.012 + this.getRandom().nextDouble() * 0.035,
                vz + (this.getRandom().nextDouble() - 0.5) * 0.04);
    }

    private void animateCar() {
        List<Entity> pax = this.getPassengers();

        UUID[] now = new UUID[pax.size()];
        for (int i = 0; i < now.length; i++) {
            now[i] = pax.get(i).getUUID();
        }
        for (int i = 0; i < now.length; i++) {
            boolean known = false;
            for (UUID u : this.prevPax) {
                if (u.equals(now[i])) {
                    known = true;
                    break;
                }
            }
            if (!known) {
                this.onBoarded(i);
            }
        }
        for (int i = 0; i < this.prevPax.length; i++) {
            boolean still = false;
            for (UUID u : now) {
                if (u.equals(this.prevPax[i])) {
                    still = true;
                    break;
                }
            }
            if (!still) {
                this.onLeft(i);
            }
        }
        this.prevPax = now;

        for (int d = 0; d < 4; d++) {
            if (this.doorHold[d] > 0) {
                this.doorHold[d]--;
            }
            float target = this.doorHold[d] > 0 ? 1f : 0f;
            this.doorVel[d] += (target - this.doorOpen[d]) * 0.32f;
            this.doorVel[d] *= 0.55f;
            this.doorOpen[d] = Mth.clamp(this.doorOpen[d] + this.doorVel[d], -0.02f, 1.09f);
        }

        for (int i = 0; i < this.seatAnim.length; i++) {
            if (this.seatAnim[i] < 1f) {
                this.seatAnim[i] = Math.min(1f, this.seatAnim[i] + 0.125f);
            }
        }

        UUID driverNow = pax.isEmpty() ? null : pax.get(0).getUUID();
        if (driverNow == null) {
            if (this.prevDriver != null) {
                this.engineOn = false;
                this.engineStartTicks = -1;
            }
        } else if (!driverNow.equals(this.prevDriver)) {
            this.engineOn = false;
            this.engineJitter = 0f;
            this.engineStartTicks = 12;
            this.playCarSound(ENGINE_START, 1.30f, 1.0f);
        }
        this.prevDriver = driverNow;

        if (this.engineStartTicks > 0 && --this.engineStartTicks == 0) {
            this.engineOn = true;
            this.engineJitter = 1f;
            this.engineIdleTimer = 22;
            if (this.level().isClientSide()) {
                this.spawnExhaust();
            }
        }
        if (this.engineJitter > 0f) {
            this.engineJitter = Math.max(0f, this.engineJitter - 0.055f);
        }
        if (this.engineOn && --this.engineIdleTimer <= 0) {

            this.engineIdleTimer = 40;
            float sp = Mth.clamp(this.hudSpeed / (spec.maxSpeed() * 72f), 0f, 1f);
            this.playCarSound(ENGINE_IDLE, 1.00f + 0.20f * sp, 1.0f);
        }

        if (!this.level().isClientSide()) {
            return;
        }

        LivingEntity seated = this.getControllingPassenger();
        boolean burnoutNow = this.engineOn && this.onGround() && seated != null
                && seated.zza > 0.1f && this.hudSpeed < 6f;
        this.burnout += ((burnoutNow ? 1f : 0f) - this.burnout) * 0.18f;
        float pitchTarget = Mth.clamp((this.hudSpeed - this.prevHudSpeed) * 0.5f, -3.0f, 3.0f)
                + this.burnout * 1.6f;
        float rollTarget = Mth.clamp(this.lastDYaw * Mth.clamp(this.hudSpeed / 45f, 0f, 1f) * 0.7f, -4.5f, 4.5f);
        this.bodyPitch += (pitchTarget - this.bodyPitch) * 0.22f;
        this.bodyRoll += (rollTarget - this.bodyRoll) * 0.22f;
        this.prevHudSpeed = this.hudSpeed;

        float netL = 0f;
        float netF = 0f;
        for (int i = 0; i < pax.size(); i++) {
            float[] seat = spec.seats().get(Math.min(i, spec.seatCount() - 1));
            netL += Mth.clamp(seat[0] / 0.55f, -1f, 1f);
            netF += seat[1] >= 0f ? 0.8f : -0.8f;
        }
        float passPitchTarget = Mth.clamp(-netF * 0.9f, -4f, 4f);
        float passRollTarget = Mth.clamp(netL * 1.3f, -4.5f, 4.5f);
        this.passPitchVel += (passPitchTarget - this.passPitch) * 0.22f;
        this.passPitchVel *= 0.68f;
        this.passPitch += this.passPitchVel;
        this.passRollVel += (passRollTarget - this.passRoll) * 0.22f;
        this.passRollVel *= 0.68f;
        this.passRoll += this.passRollVel;

        if (this.onGround()) {
            if (!this.wasOnGround && this.fallSpeed > 0.3f) {
                this.bodyDropVel += Math.min(0.85f, this.fallSpeed * 0.55f);
            }
            this.fallSpeed = 0f;
        } else {
            this.fallSpeed = Math.max(this.fallSpeed, (float) -this.getDeltaMovement().y);
        }
        this.wasOnGround = this.onGround();
        this.bodyDropVel += (0f - this.bodyDrop) * 0.30f;
        this.bodyDropVel *= 0.55f;
        this.bodyDrop = Mth.clamp(this.bodyDrop + this.bodyDropVel, -0.025f, 0.20f);

        float speedK = Mth.clamp(this.hudSpeed / 60f, 0f, 1f);
        this.idleVibe = this.engineOn ? 0.006f + 0.006f * speedK + 0.026f * this.burnout : 0f;
        this.roadBump = this.engineOn && this.onGround() ? 0.008f * speedK : 0f;

        if (this.onGround() && this.hudSpeed > 30f && this.getRandom().nextInt(3) == 0) {
            float yaw = this.getYRot() * Mth.DEG_TO_RAD;
            double fx = -Mth.sin(yaw);
            double fz = Mth.cos(yaw);
            double lx = Mth.cos(yaw);
            double lz = Mth.sin(yaw);
            double corner = this.getRandom().nextBoolean() ? 0.7 : -0.7;
            double bx = this.getX() - fx * 0.9 + lx * corner;
            double bz = this.getZ() - fz * 0.9 + lz * corner;
            BlockPos pos = BlockPos.containing(bx, this.getY() - 0.2, bz);
            BlockState st = this.level().getBlockState(pos);
            if (st.is(BlockTags.DIRT) || st.is(BlockTags.SAND) || st.is(Blocks.GRAVEL)) {
                this.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, st),
                        bx, this.getY() + 0.06, bz,
                        -fx * 0.05 + (this.getRandom().nextDouble() - 0.5) * 0.03,
                        0.03 + this.getRandom().nextDouble() * 0.04,
                        -fz * 0.05 + (this.getRandom().nextDouble() - 0.5) * 0.03);
            }
        }

        float wearK = this.healthRatio();
        if (wearK < 0.66f && this.engineOn) {
            boolean heavy = wearK < 0.33f;
            if (this.getRandom().nextInt(heavy ? 3 : 9) == 0) {
                float smokeYaw = this.getYRot() * Mth.DEG_TO_RAD;
                double sfx = -Mth.sin(smokeYaw);
                double sfz = Mth.cos(smokeYaw);
                this.level().addParticle(heavy ? ParticleTypes.LARGE_SMOKE : ParticleTypes.SMOKE,
                        this.getX() + sfx * 1.35 + (this.getRandom().nextDouble() - 0.5) * 0.5,
                        this.getY() + 0.72,
                        this.getZ() + sfz * 1.35 + (this.getRandom().nextDouble() - 0.5) * 0.5,
                        sfx * 0.02,
                        0.030 + this.getRandom().nextDouble() * 0.03,
                        sfz * 0.02);
            }
            if (heavy && this.hudSpeed > 25f && this.getRandom().nextInt(5) == 0) {
                this.level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                        this.getX() + (this.getRandom().nextDouble() - 0.5) * 1.2,
                        this.getY() + 0.12,
                        this.getZ() + (this.getRandom().nextDouble() - 0.5) * 1.2,
                        0.0, 0.02, 0.0);
            }
        }
    }

    private void onBoarded(int idx) {
        int seatIdx = Math.min(idx, spec.seatCount() - 1);
        if (seatIdx < this.seatAnim.length) {
            this.seatAnim[seatIdx] = 0f;
        }
        this.doorHold[this.doorSlot(spec.seats().get(seatIdx))] = 11;
        if (this.level().isClientSide()) {
            this.bodyDropVel += 0.4f;
        }
    }

    private void onLeft(int idx) {
        int seatIdx = Math.min(idx, spec.seatCount() - 1);
        this.doorHold[this.doorSlot(spec.seats().get(seatIdx))] = 9;
        if (seatIdx < this.seatAnim.length) {
            this.seatAnim[seatIdx] = 1f;
        }
    }

    private int doorSlot(float[] seat) {
        boolean left = seat[0] >= 0f;
        boolean rear = spec.doorSplitZ() != null && seat[1] < spec.doorSplitZ();
        return left ? (rear ? DOOR_LR : DOOR_LF) : (rear ? DOOR_RR : DOOR_RF);
    }

    private void spawnExhaust() {
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw);
        double fz = Mth.cos(yaw);
        double lx = Mth.cos(yaw) * 0.5;
        double lz = Mth.sin(yaw) * 0.5;
        for (int i = 0; i < 4; i++) {
            this.level().addParticle(ParticleTypes.CLOUD,
                    this.getX() - fx * 2.7 + lx + (this.getRandom().nextDouble() - 0.5) * 0.2,
                    this.getY() + 0.16,
                    this.getZ() - fz * 2.7 + lz + (this.getRandom().nextDouble() - 0.5) * 0.2,
                    -fx * 0.05 + (this.getRandom().nextDouble() - 0.5) * 0.02,
                    0.02 + this.getRandom().nextDouble() * 0.02,
                    -fz * 0.05 + (this.getRandom().nextDouble() - 0.5) * 0.02);
        }
    }

    private void playCarSound(SoundEvent sound, float volume, float pitch) {
        if (this.level() instanceof ServerLevel server) {
            server.playSound(null, this, sound, SoundSource.NEUTRAL, volume, pitch);
        }
    }

    public boolean honk(float pitch) {
        if (this.honkCooldown > 0) {
            return false;
        }
        SoundEvent sound = ModContent.HORN_SOUNDS.get(this.spec.id());
        if (sound == null) {
            return false;
        }
        this.honkCooldown = ModContent.HORN_TICKS.getOrDefault(this.spec.id(), 20);
        if (this.level() instanceof ServerLevel server) {
            LivingEntity driver = this.getControllingPassenger();
            server.playSound(driver instanceof Player player ? player : null, this, sound, SoundSource.NEUTRAL, 4.0F, pitch);
            if (driver instanceof Player player) {
                HornCompat.notifyNpcs(server, this, player);
            }
        } else {
            this.level().playLocalSound(this, sound, SoundSource.NEUTRAL, 4.0F, pitch);
        }
        return true;
    }

    private void serverCollisions(ServerLevel server) {
        double dist = this.tickDist;
        double dy = this.tickDY;
        double prevDist = this.lastTickDist;
        double prevDY = this.lastTickDY;
        this.lastTickDist = dist;
        this.lastTickDY = dy;
        if (dist > 3.0 || prevDist > 3.0 || Math.abs(dy) > 3.0 || Math.abs(prevDY) > 3.0) {
            this.pendingCrash = 0.0;
            this.pendingKind = 0;
            return;
        }
        this.crashWindow[this.crashWindowCursor] = dist;
        this.crashWindowCursor = (this.crashWindowCursor + 1) % this.crashWindow.length;
        double ref = 0.0;
        for (double w : this.crashWindow) {
            ref = Math.max(ref, w);
        }
        if (this.pendingCrash > 0.0) {
            double pending = this.pendingCrash;
            int kind = this.pendingKind;
            this.pendingCrash = 0.0;
            this.pendingKind = 0;
            boolean confirmed = this.impactCooldown == 0
                    && (kind == 3 ? dy > -pending * 0.35
                    : dist < pending * (kind == 2 ? 0.70 : 0.55) && this.blockedAhead());
            if (confirmed) {
                float impact = (float) pending;
                float mult = this.getControllingPassenger() instanceof Player ? 1.0f : 0.6f;
                if (kind == 3) {
                    this.impactCooldown = 10;
                    this.hardHit(server, impact, (impact - 0.50f) * 45.0f * mult);
                } else if (kind == 2) {
                    this.impactCooldown = 8;
                    this.scrapeHit(server, impact, (impact - 0.30f) * 12.0f * mult);
                } else {
                    this.impactCooldown = 10;
                    this.hardHit(server, impact, (impact - 0.28f) * 62.0f * mult);
                }
                if (this.isRemoved()) {
                    return;
                }
            }
        }
        if (this.impactCooldown == 0 && this.pendingCrash == 0.0) {
            if (ref > 0.35 && dist < ref * 0.45 && this.blockedAhead()) {
                this.pendingCrash = ref;
                this.pendingKind = 1;
            } else if (ref > 0.45 && dist < ref * 0.62 && this.blockedAhead()
                    && this.getControllingPassenger() instanceof Player) {
                this.pendingCrash = ref;
                this.pendingKind = 2;
            } else if (prevDY < -0.65 && dy > -0.15 && !this.isInWater()) {
                this.pendingCrash = -prevDY;
                this.pendingKind = 3;
            }
        }
        double v = Math.sqrt(this.velX * this.velX + this.velZ * this.velZ);
        if (v > 0.10) {
            this.ramEntities(server, v);
        }
    }

    private boolean blockedAhead() {
        double len = Math.sqrt(this.lastDirX * this.lastDirX + this.lastDirZ * this.lastDirZ);
        if (len < 0.5) {
            return false;
        }
        AABB base = this.getBoundingBox();
        AABB near = base.move(this.lastDirX * 0.18, 0.0, this.lastDirZ * 0.18);
        if (!this.level().noBlockCollision(this, near)) {
            return true;
        }
        AABB far = base.move(this.lastDirX * 0.45, 0.0, this.lastDirZ * 0.45);
        return !this.level().noBlockCollision(this, far);
    }

    public void clientImpact(float impact, int kind) {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        if (this.isRemoved() || this.impactCooldown > 0) {
            return;
        }
        if (!(this.getControllingPassenger() instanceof Player)) {
            return;
        }
        float imp = Mth.clamp(impact, 0f, this.spec.maxSpeed() * 1.15f);
        if (imp < 0.32f) {
            return;
        }
        if (kind == 2 && imp >= 0.45f) {
            this.impactCooldown = 8;
            this.scrapeHit(server, imp, (imp - 0.30f) * 12.0f);
        } else {
            this.impactCooldown = 10;
            this.hardHit(server, imp, (imp - 0.28f) * 62.0f);
        }
    }

    private void hardHit(ServerLevel server, float impact, float dmg) {
        this.playCarSound(HIT_METAL, Mth.clamp(0.7f + impact * 0.8f, 0.8f, 1.9f), 0.82f + this.getRandom().nextFloat() * 0.3f);
        if (impact > 0.5f) {
            float sparkYaw = this.getYRot() * Mth.DEG_TO_RAD;
            double nx = -Mth.sin(sparkYaw);
            double nz = Mth.cos(sparkYaw);
            int sparks = impact > 1.0f ? 12 : 6;
            server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    this.getX() + nx * 1.2, this.getY() + 0.75, this.getZ() + nz * 1.2,
                    sparks, 0.4, 0.35, 0.4, 0.05);
            if (impact > 0.9f) {
                server.sendParticles(ParticleTypes.SMOKE,
                        this.getX() + nx * 1.3, this.getY() + 0.6, this.getZ() + nz * 1.3,
                        6, 0.3, 0.2, 0.3, 0.02);
            }
        }
        this.damageCar(server, dmg);
        if (dmg >= 20f) {
            DamageSource src = this.impactSource(server);
            List<Entity> pax = List.copyOf(this.getPassengers());
            for (int i = 1; i < pax.size(); i++) {
                if (pax.get(i) instanceof LivingEntity living) {
                    living.hurtServer(server, src, dmg * 0.25f);
                }
            }
        }
    }

    private void scrapeHit(ServerLevel server, float impact, float dmg) {
        this.playCarSound(HIT_METAL, Mth.clamp(0.45f + impact * 0.45f, 0.55f, 1.1f), 0.88f + this.getRandom().nextFloat() * 0.25f);
        if (impact > 0.6f) {
            float sparkYaw = this.getYRot() * Mth.DEG_TO_RAD;
            server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    this.getX() - Mth.sin(sparkYaw) * 1.1, this.getY() + 0.7, this.getZ() + Mth.cos(sparkYaw) * 1.1,
                    3, 0.35, 0.3, 0.35, 0.04);
        }
        this.damageCar(server, dmg);
    }

    private void ramEntities(ServerLevel server, double v) {
        AABB contact = this.getBoundingBox().inflate(0.35, 0.06, 0.35);
        AABB reach = contact.expandTowards(this.velX, 0.0, this.velZ);
        List<Entity> found = server.getEntities(this, reach, e -> !this.hasPassenger(e) && !e.isPassenger() && e.isAlive());
        if (found.isEmpty()) {
            return;
        }
        double nx = this.velX / v;
        double nz = this.velZ / v;
        for (Entity e : found) {
            if (this.isRemoved()) {
                return;
            }
            if (!e.getBoundingBox().intersects(contact)) {
                continue;
            }
            if (e.getBoundingBox().minY >= this.getBoundingBox().maxY - 0.2) {
                continue;
            }
            double rx = e.getX() - this.getX();
            double rz = e.getZ() - this.getZ();
            if (rx * this.velX + rz * this.velZ <= 0.0) {
                continue;
            }
            if (e instanceof CarEntity other) {
                this.ramCar(server, other);
            } else if (e instanceof LivingEntity victim) {
                this.ramVictim(server, victim, v, nx, nz);
            }
        }
    }

    private void ramCar(ServerLevel server, CarEntity other) {
        if (this.impactCooldown > 0 || other.impactCooldown > 0) {
            return;
        }
        double rvx = this.velX - other.velX;
        double rvz = this.velZ - other.velZ;
        double rel = Math.sqrt(rvx * rvx + rvz * rvz);
        if (rel < 0.45) {
            return;
        }
        double rx = other.getX() - this.getX();
        double rz = other.getZ() - this.getZ();
        if (rx * rvx + rz * rvz <= 0.0) {
            return;
        }
        this.impactCooldown = 10;
        other.impactCooldown = 10;
        float dmg = (float) ((rel - 0.40) * 55.0);
        this.playCarSound(HIT_METAL, Mth.clamp(0.8f + (float) rel * 0.6f, 0.8f, 1.5f), 0.8f + this.getRandom().nextFloat() * 0.3f);
        this.damageCar(server, dmg);
        other.damageCar(server, dmg);
        double len = Math.sqrt(rx * rx + rz * rz);
        if (len > 1.0E-4) {
            other.push(rx / len * 0.22, 0.02, rz / len * 0.22);
            other.hurtMarked = true;
        }
    }

    private void ramVictim(ServerLevel server, LivingEntity victim, double v, double nx, double nz) {
        if (v > 0.15) {
            float dmg = (float) ((v - 0.10) * 30.0);
            if (victim.hurtServer(server, this.impactSource(server), dmg)) {
                double k = Math.min(1.5, 0.45 + v * 1.1);
                victim.push(nx * k, 0.30 + Math.min(0.4, v * 0.28), nz * k);
                victim.hurtMarked = true;
                server.playSound(null, victim, HIT_BODY, SoundSource.NEUTRAL, 1.05f, 0.85f + this.getRandom().nextFloat() * 0.3f);
                this.speed *= 0.96f;
            }
        } else {
            double k = Math.min(0.5, 0.2 + v * 1.5);
            victim.push(nx * k, 0.12, nz * k);
            victim.hurtMarked = true;
        }
    }

    private DamageSource impactSource(ServerLevel server) {
        LivingEntity driver = this.getControllingPassenger();
        if (driver instanceof Player player) {
            return server.damageSources().playerAttack(player);
        }
        if (driver != null) {
            return server.damageSources().mobAttack(driver);
        }
        return server.damageSources().generic();
    }

    private void damageCar(ServerLevel server, float dmg) {
        if (dmg <= 0.5f || this.isRemoved()) {
            return;
        }
        float next = this.getHealth() - dmg;
        if (next <= 0f) {
            this.wreckCar(server);
        } else {
            this.entityData.set(DATA_HEALTH, next);
        }
    }

    private void wreckCar(ServerLevel server) {
        this.playCarSound(CRASH, 1.8f, 0.9f + this.getRandom().nextFloat() * 0.2f);
        server.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.8, this.getZ(), 16, 1.1, 0.6, 1.1, 0.06);
        server.sendParticles(ParticleTypes.FLAME, this.getX(), this.getY() + 0.6, this.getZ(), 10, 0.8, 0.4, 0.8, 0.03);
        server.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.6, this.getZ(), 3, 0.7, 0.3, 0.7, 0.0);
        DamageSource src = this.impactSource(server);
        for (Entity passenger : List.copyOf(this.getPassengers())) {
            if (passenger instanceof LivingEntity living) {
                living.hurtServer(server, src, 6.0f);
            }
        }
        this.ejectPassengers();
        this.spawnAtLocation(server, new ItemStack(ModContent.item(this.spec.id())));
        this.discard();
    }

    public boolean tryRepair(ServerLevel level, Player player) {
        if (this.repairCooldown > 0 || this.getHealth() >= this.getMaxHealth()) {
            return false;
        }
        this.repairCooldown = 8;
        this.entityData.set(DATA_HEALTH, Math.min(this.getMaxHealth(), this.getHealth() + 30.0f));
        if (!player.getAbilities().instabuild) {
            player.getMainHandItem().shrink(1);
        }
        this.playCarSound(REPAIR, 0.85f, 0.95f + this.getRandom().nextFloat() * 0.15f);
        return true;
    }

    private void drive() {
        float forward = 0f;
        float strafe = 0f;
        boolean handbrake = false;
        LivingEntity driver = this.getControllingPassenger();
        if (driver != null) {
            forward = driver.zza;
            strafe = driver.xxa;
            if (this.level().isClientSide()) {
                if (!this.engineOn) {
                    forward = Math.min(forward, 0f);
                }
                handbrake = CarInput.handbrake(driver);
            }
        }

        float wear = this.healthRatio();
        final float max = spec.maxSpeed() * (0.60f + 0.40f * wear);
        final float accel = spec.accel() * (0.45f + 0.55f * wear);
        final float drift = spec.drift();

        float absSpeed = Math.abs(speed);
        boolean pulling = handbrake && absSpeed > 0.10f;
        float dRad = 0f;
        if (absSpeed > 0.02f && strafe != 0f) {
            float sgn = speed > 0 ? 1f : -1f;
            float k = Mth.clamp(absSpeed / 0.25f, 0f, 1f) * (1.0f - 0.45f * absSpeed / max);
            if (!this.onGround()) {
                k *= 0.35f;
            }
            float steerRate = strafe * spec.turn() * k;
            if (pulling) {
                steerRate *= 1.30f + 0.60f * drift;
            }
            float dDeg = -steerRate * sgn;
            this.setYRot(this.getYRot() + dDeg);
            dRad = dDeg * Mth.DEG_TO_RAD;
        }

        if (dRad != 0f) {
            float ns = speed - dRad * side;
            side += dRad * speed;
            speed = ns;
        }

        if (forward > 0) {
            if (speed < 0) {
                speed += 0.07f;
            } else {
                speed = Math.min(max, speed + accel * (1.0f - 0.6f * speed / max));
            }
        } else if (forward < 0) {
            if (speed > 0.01f) {
                speed -= 0.07f;
            } else {
                speed = Math.max(-max * 0.35f, speed - accel * 0.7f);
            }
        } else {
            speed *= (driver != null) ? 0.975f : 0.9f;
            if (Math.abs(speed) < 0.004f) {
                speed = 0f;
            }
        }

        float grip;
        if (pulling) {
            grip = 0.935f + 0.05f * drift;
            speed *= 0.996f;
        } else {
            grip = 0.70f + 0.16f * drift + 0.05f * Mth.clamp(Math.abs(speed) / max, 0f, 1f);
            grip = Math.min(grip, 0.92f);
        }
        side *= grip;
        if (!pulling && Math.abs(side) < 0.02f) {
            side = 0f;
        }
        float sideCap = max * 0.9f;
        side = Mth.clamp(side, -sideCap, sideCap);

        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        double mx = -Mth.sin(yaw) * speed + Mth.cos(yaw) * side;
        double mz = Mth.cos(yaw) * speed + Mth.sin(yaw) * side;

        double h = Math.sqrt(mx * mx + mz * mz);
        double limit = max * 1.15;
        if (h > limit) {
            float sc = (float) (limit / h);
            mx *= sc;
            mz *= sc;
            speed *= sc;
            side *= sc;
        }

        Vec3 dm = this.getDeltaMovement();
        double my;
        if (this.isInWater()) {
            my = 0.03;
            speed *= 0.9f;
            side *= 0.9f;
            mx *= 0.9;
            mz *= 0.9;
        } else if (this.onGround()) {
            my = -0.08;
        } else {
            my = (dm.y - 0.08) * 0.98;
        }

        this.setDeltaMovement(mx, my, mz);
        this.move(MoverType.SELF, this.getDeltaMovement());

        if (this.horizontalCollision) {
            Vec3 after = this.getDeltaMovement();
            double intended = Math.sqrt(mx * mx + mz * mz);
            double actual = Math.sqrt(after.x * after.x + after.z * after.z);
            if (actual < intended * 0.6) {
                if (this.level().isClientSide() && this.impactReportCooldown == 0
                        && intended > 0.32 && this.getControllingPassenger() instanceof Player) {
                    ImpactSender.send((float) intended, actual < intended * 0.45 ? 1 : 2);
                    this.impactReportCooldown = 8;
                }
                speed *= 0.4f;
                side *= 0.5f;
            } else if (actual < intended * 0.82 && intended > 0.5
                    && this.level().isClientSide() && this.impactReportCooldown == 0
                    && this.getControllingPassenger() instanceof Player) {
                ImpactSender.send((float) intended, 2);
                this.impactReportCooldown = 10;
            }
        }

        if (this.onGround() && forward > 0.1f && Math.abs(speed) < 0.2f) {
            this.wheelRot += 0.55f * (1.0f - Math.abs(speed) / 0.2f);
            if (this.level().isClientSide() && this.getRandom().nextInt(3) == 0) {
                this.spawnTireSmoke(0.0, 0.0);
            }
        }
    }
}
