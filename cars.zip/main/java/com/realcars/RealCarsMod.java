package com.realcars;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Items;

public class RealCarsMod implements ModInitializer {
    public static final String MOD_ID = "realcars";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModContent.register();

        PayloadTypeRegistry.playC2S().register(HonkPayload.TYPE, HonkPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(HonkPayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == player) {
                        car.honk(payload.pitch());
                    }
                }));

        PayloadTypeRegistry.playC2S().register(ImpactPayload.TYPE, ImpactPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ImpactPayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == player) {
                        car.clientImpact(payload.impact(), payload.kind());
                    }
                }));

        PayloadTypeRegistry.playC2S().register(LightsPayload.TYPE, LightsPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(LightsPayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == player) {
                        car.setLights(payload.on());
                    }
                }));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries ->
                ModContent.items().values().forEach(entries::accept));

        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!(entity instanceof CarEntity car) || hand != InteractionHand.MAIN_HAND) {
                return InteractionResult.PASS;
            }
            if (player.isPassenger()) {
                return InteractionResult.PASS;
            }
            if (player.getMainHandItem().is(Items.IRON_INGOT) && car.healthRatio() < 1f) {
                if (world instanceof ServerLevel server) {
                    car.tryRepair(server, player);
                }
                return InteractionResult.SUCCESS;
            }
            if (player.isSecondaryUseActive()) {
                return InteractionResult.PASS;
            }
            if (car.getPassengers().size() >= car.spec.seatCount()) {
                return InteractionResult.PASS;
            }
            if (!world.isClientSide()) {
                player.startRiding(car);
            }
            return InteractionResult.SUCCESS;
        });
    }
}
