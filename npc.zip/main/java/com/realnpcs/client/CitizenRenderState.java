package com.realnpcs.client;

import com.realnpcs.RealNpcsMod;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class CitizenRenderState extends LivingEntityRenderState {
    public Identifier texture = RealNpcsMod.id("textures/entity/citizen/v01.png");
    public boolean riding;
    public float attackAnim;
}
