package com.realnpcs.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class CitizenModel extends EntityModel<CitizenRenderState> {
    private final ModelPart head;
    private final ModelPart hat;
    private final ModelPart body;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart legR;
    private final ModelPart legL;

    public CitizenModel(ModelPart root) {
        super(root);
        this.head = root.getChild("head");
        this.hat = root.getChild("hat");
        this.body = root.getChild("body");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
        this.legR = root.getChild("leg_r");
        this.legL = root.getChild("leg_l");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        try (InputStream in = CitizenModel.class.getResourceAsStream("/assets/realnpcs/citizen_models/citizen.json")) {
            if (in == null) {
                throw new IllegalStateException("citizen.json not found");
            }
            JsonObject json = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (JsonElement element : json.getAsJsonArray("parts")) {
                JsonObject part = element.getAsJsonObject();
                JsonArray pivot = part.getAsJsonArray("pivot");
                CubeListBuilder cubes = CubeListBuilder.create();
                for (JsonElement cubeElement : part.getAsJsonArray("cubes")) {
                    JsonObject cube = cubeElement.getAsJsonObject();
                    cubes.texOffs(cube.get("u").getAsInt(), cube.get("v").getAsInt());
                    cubes.addBox(cube.get("x").getAsFloat(), cube.get("y").getAsFloat(), cube.get("z").getAsFloat(),
                            cube.get("w").getAsFloat(), cube.get("h").getAsFloat(), cube.get("d").getAsFloat(),
                            new CubeDeformation(cube.get("grow").getAsFloat()));
                }
                root.addOrReplaceChild(part.get("name").getAsString(), cubes,
                        PartPose.offset(pivot.get(0).getAsFloat(), pivot.get(1).getAsFloat(), pivot.get(2).getAsFloat()));
            }
            int textureSize = json.get("texture").getAsInt();
            return LayerDefinition.create(mesh, textureSize, textureSize);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void setupAnim(CitizenRenderState state) {
        super.setupAnim(state);
        this.head.xRot = state.xRot * Mth.DEG_TO_RAD;
        this.head.yRot = state.yRot * Mth.DEG_TO_RAD;
        this.hat.xRot = this.head.xRot;
        this.hat.yRot = this.head.yRot;
        if (state.riding) {
            this.body.xRot = 0.0F;
            this.armR.xRot = -0.628F;
            this.armL.xRot = -0.628F;
            this.armR.yRot = 0.0F;
            this.armL.yRot = 0.0F;
            this.armR.zRot = 0.1F;
            this.armL.zRot = -0.1F;
            this.legR.xRot = -1.4137F;
            this.legR.yRot = 0.314F;
            this.legR.zRot = 0.0785F;
            this.legL.xRot = -1.4137F;
            this.legL.yRot = -0.314F;
            this.legL.zRot = -0.0785F;
        } else {
            float swing = state.walkAnimationPos * 0.6662F;
            float speed = Math.min(state.walkAnimationSpeed, 1.2F);
            float breathe = Mth.sin(state.ageInTicks * 0.09F) * 0.02F;
            this.body.xRot = 0.0F;
            this.armR.xRot = Mth.cos(swing + 3.1415927F) * speed + breathe;
            this.armL.xRot = Mth.cos(swing) * speed - breathe;
            this.armR.yRot = 0.0F;
            this.armL.yRot = 0.0F;
            this.armR.zRot = 0.06F;
            this.armL.zRot = -0.06F;
            this.legR.xRot = Mth.cos(swing) * 1.4F * speed;
            this.legR.yRot = 0.0F;
            this.legR.zRot = 0.0F;
            this.legL.xRot = Mth.cos(swing + 3.1415927F) * 1.4F * speed;
            this.legL.yRot = 0.0F;
            this.legL.zRot = 0.0F;
        }
        if (state.attackAnim > 0.0F) {
            this.armR.xRot = Mth.lerp(state.attackAnim, this.armR.xRot, -1.5F);
            this.armR.zRot = Mth.lerp(state.attackAnim, this.armR.zRot, 0.0F);
        }
    }
}
