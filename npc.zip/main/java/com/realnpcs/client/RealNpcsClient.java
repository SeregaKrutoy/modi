package com.realnpcs.client;

import com.realnpcs.RealNpcsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderers;

public class RealNpcsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModelLayerLocation layer = new ModelLayerLocation(RealNpcsMod.id("citizen"), "main");
        EntityModelLayerRegistry.registerModelLayer(layer, CitizenModel::createLayer);
        EntityRenderers.register(RealNpcsMod.CITIZEN,
                context -> new CitizenRenderer(context, new CitizenModel(context.bakeLayer(layer))));
    }
}
