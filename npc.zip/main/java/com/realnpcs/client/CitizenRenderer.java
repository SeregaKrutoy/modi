package com.realnpcs.client;

import com.realnpcs.CitizenEntity;
import com.realnpcs.RealNpcsMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.Identifier;

public class CitizenRenderer extends LivingEntityRenderer<CitizenEntity, CitizenRenderState, CitizenModel> {
    public CitizenRenderer(EntityRendererProvider.Context context, CitizenModel model) {
        super(context, model, 0.5F);
    }

    @Override
    public CitizenRenderState createRenderState() {
        return new CitizenRenderState();
    }

    @Override
    public void extractRenderState(CitizenEntity entity, CitizenRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.texture = RealNpcsMod.id("textures/entity/citizen/" + entity.getVariant() + ".png");
        state.riding = entity.isPassenger();
        state.attackAnim = entity.getAttackAnim(partialTick);
    }

    @Override
    public Identifier getTextureLocation(CitizenRenderState state) {
        return state.texture;
    }
}
