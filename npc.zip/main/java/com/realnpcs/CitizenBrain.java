package com.realnpcs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.List;
import java.util.UUID;

public class CitizenBrain {
    private static final int IDLE = 0;
    private static final int WALK = 1;
    private static final int SEEK_CAR = 2;
    private static final int DRIVE = 3;
    private static final int FLEE = 4;
    private static final int FIGHT = 5;
    private static final int TALK = 6;
    private static final int HOME = 7;
    private static final int PATROL = 8;
    private static final int SHELTER = 9;
    private static final int SPOOK = 10;
    private static final int SEEK_RIDE = 11;
    private static final int RIDE = 12;

    private final CitizenEntity npc;
    private int state = IDLE;
    private int stateTicks;
    private int idleTicks;
    private int cooldown;
    private int scan;
    private int alertCooldown;
    private int warnCooldown;
    private int greetCooldown;
    private int attackCooldown;
    private UUID threatId;
    private int threatTicks;
    private Entity carRef;
    private UUID banCarId;
    private int banTicks;
    private double lastCarX;
    private double lastCarZ;
    private double destX;
    private double destZ;
    private boolean hasDest;
    private int stuckTicks;
    private int reverseTicks;
    private int attempts;
    private int driveGiveups;
    private BlockPos targetPos;
    private boolean resting;
    private int honkCooldown;
    private int rideExitTicks;
    private int rideStopTicks;
    private double rideLastX;
    private double rideLastZ;

    public CitizenBrain(CitizenEntity npc) {
        this.npc = npc;
    }

    public void tick() {
        this.stateTicks++;
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        if (this.banTicks > 0) {
            this.banTicks--;
        } else if (this.banCarId != null) {
            this.banCarId = null;
        }
        if (this.warnCooldown > 0) {
            this.warnCooldown--;
        }
        if (this.greetCooldown > 0) {
            this.greetCooldown--;
        }
        if (this.alertCooldown > 0) {
            this.alertCooldown--;
        }
        if (this.threatTicks > 0) {
            this.threatTicks--;
        }
        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }
        if (this.honkCooldown > 0) {
            this.honkCooldown--;
        }
        if (!(this.npc.level() instanceof ServerLevel level)) {
            return;
        }
        if (this.npc.getNameKey().isEmpty()) {
            this.npc.init(CitizenSpecs.random(this.npc.getRandom()), this.npc.blockPosition());
        } else if (this.npc.getHomePos().equals(BlockPos.ZERO)) {
            this.npc.setHomePos(this.npc.blockPosition());
        }
        if (this.npc.isPassenger()) {
            Entity vehicle = this.npc.getVehicle();
            if (vehicle != null && isCar(vehicle)) {
                if (this.state == RIDE) {
                    this.rideTick(level, vehicle);
                } else {
                    this.driveTick(level, vehicle);
                }
            } else if (vehicle != null) {
                this.npc.stopRiding();
            }
            return;
        }
        if (this.state == DRIVE || this.state == RIDE) {
            this.state = IDLE;
            this.stateTicks = 0;
            this.targetPos = null;
            this.resting = false;
            this.npc.setPermanentDriver(false);
        }
        this.perceive(level);
        if (this.threatTicks > 0) {
            this.respondThreat(level);
            return;
        }
        if (this.state == FLEE || this.state == FIGHT) {
            this.state = IDLE;
            this.stateTicks = 0;
            this.say("calm", false);
        }
        this.social(level);
        if (this.state == TALK) {
            this.talkTick(level);
            return;
        }
        if (this.schedule(level)) {
            return;
        }
        if (this.state == IDLE) {
            this.idleTick(level);
        } else {
            this.walkTick(level);
        }
    }

    private void perceive(ServerLevel level) {
        this.scan++;
        if ((this.scan + this.npc.getId()) % 7 != 0) {
            return;
        }
        LivingEntity attacker = this.npc.getLastHurtByMob();
        if (attacker != null && attacker.isAlive()) {
            if (this.threatId == null || !this.threatId.equals(attacker.getUUID())) {
                this.setThreat(attacker, level);
            } else {
                this.threatTicks = Math.max(this.threatTicks, 160);
            }
        }
        if (this.state != DRIVE && this.warnCooldown == 0) {
            Player player = level.getNearestPlayer(this.npc, 7.0);
            if (player != null && this.isDangerous(player)) {
                this.warnCooldown = 240;
                if (this.isGuard()) {
                    this.setThreat(player, level);
                } else {
                    this.threatId = player.getUUID();
                    this.threatTicks = Math.max(this.threatTicks, 140);
                    this.state = FLEE;
                    this.stateTicks = 0;
                    this.say("warn", true);
                }
            }
        }
        if (this.threatTicks <= 0 && this.state != DRIVE) {
            if (this.isGuard()) {
                if (this.cooldown == 0) {
                    List<Monster> monsters = level.getEntitiesOfClass(Monster.class, this.npc.getBoundingBox().inflate(12.0));
                    if (!monsters.isEmpty()) {
                        this.threatId = monsters.get(0).getUUID();
                        this.threatTicks = 220;
                        this.stateTicks = 0;
                        this.state = FIGHT;
                        this.say("monster", true);
                        this.alertNearby(level);
                    }
                }
            } else if (this.cooldown == 0 && this.npc.getRandom().nextFloat() < 0.6F) {
                List<Monster> monsters = level.getEntitiesOfClass(Monster.class, this.npc.getBoundingBox().inflate(6.0));
                if (!monsters.isEmpty()) {
                    this.threatId = monsters.get(0).getUUID();
                    this.threatTicks = 100;
                    this.state = FLEE;
                    this.stateTicks = 0;
                    this.say("flee", true);
                }
            }
        }
    }

    private boolean isDangerous(Player player) {
        if (this.npc.distanceTo(player) > 6.0F) {
            return false;
        }
        if (!player.getMainHandItem().is(ItemTags.SWORDS)) {
            return false;
        }
        return player.isSprinting() || player.swinging;
    }

    private void setThreat(LivingEntity threat, ServerLevel level) {
        this.threatId = threat.getUUID();
        this.threatTicks = 220;
        this.stateTicks = 0;
        boolean brave = this.isGuard();
        this.state = brave ? FIGHT : FLEE;
        this.say(brave ? "fight" : "flee", true);
        this.alertNearby(level);
    }

    public void onHurt(Entity attacker) {
        if (!(attacker instanceof LivingEntity living) || living == this.npc) {
            return;
        }
        this.threatId = living.getUUID();
        this.threatTicks = 260;
        this.stateTicks = 0;
        this.state = this.isGuard() ? FIGHT : FLEE;
        this.say("hurt", true);
        if (this.npc.level() instanceof ServerLevel level) {
            this.alertNearby(level);
        }
    }

    public void onTalked(Player player) {
        this.npc.speak(Speech.pick(this.npc.getRandom(), "talk", this.npc.getProfile()), 60, true);
        if (this.state == IDLE || this.state == WALK) {
            this.state = TALK;
            this.stateTicks = 0;
        }
    }

    private void alertNearby(ServerLevel level) {
        List<CitizenEntity> nearby = level.getEntitiesOfClass(CitizenEntity.class, this.npc.getBoundingBox().inflate(14.0));
        for (CitizenEntity other : nearby) {
            if (other == this.npc) {
                continue;
            }
            CitizenBrain brain = other.getCitizenBrain();
            if (brain.threatTicks > 0 || brain.alertCooldown > 0 || brain.state == DRIVE || brain.state == SEEK_CAR) {
                continue;
            }
            brain.threatId = this.threatId;
            brain.threatTicks = 180;
            brain.alertCooldown = 320;
            brain.stateTicks = 0;
            brain.state = brain.isGuard() ? FIGHT : FLEE;
            brain.say(brain.isGuard() ? "fight" : "flee", true);
        }
    }

    private LivingEntity threatEntity(ServerLevel level) {
        if (this.threatId == null) {
            return null;
        }
        List<LivingEntity> found = level.getEntitiesOfClass(LivingEntity.class,
                this.npc.getBoundingBox().inflate(40.0),
                entity -> this.threatId.equals(entity.getUUID()));
        if (found.isEmpty()) {
            return null;
        }
        LivingEntity threat = found.get(0);
        return threat.isAlive() ? threat : null;
    }

    private void respondThreat(ServerLevel level) {
        LivingEntity threat = this.threatEntity(level);
        if (threat == null) {
            this.threatTicks = 0;
            this.threatId = null;
            return;
        }
        if (this.isGuard()) {
            this.state = FIGHT;
            this.npc.getLookControl().setLookAt(threat, 30.0F, 30.0F);
            double distance = this.npc.distanceTo(threat);
            if (distance > 2.2) {
                if (this.stateTicks % 10 == 0) {
                    this.npc.getNavigation().moveTo(threat, 1.25);
                }
            } else {
                this.npc.getNavigation().stop();
                if (this.attackCooldown == 0) {
                    this.attackCooldown = 22;
                    this.npc.swing(InteractionHand.MAIN_HAND);
                    this.npc.doHurtTarget(level, threat);
                }
            }
        } else {
            this.state = FLEE;
            if (this.stateTicks % 12 == 0 || this.npc.getNavigation().isDone()) {
                double dx = this.npc.getX() - threat.getX();
                double dz = this.npc.getZ() - threat.getZ();
                double length = Math.sqrt(dx * dx + dz * dz);
                if (length < 1.0E-4) {
                    dx = this.npc.getRandom().nextDouble() - 0.5;
                    dz = this.npc.getRandom().nextDouble() - 0.5;
                    length = Math.max(1.0E-4, Math.sqrt(dx * dx + dz * dz));
                }
                double runX = this.npc.getX() + dx / length * 15.0;
                double runZ = this.npc.getZ() + dz / length * 15.0;
                BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        BlockPos.containing(runX, this.npc.getY(), runZ));
                this.npc.getNavigation().moveTo(top.getX() + 0.5, top.getY(), top.getZ() + 0.5, 1.35);
            }
        }
    }

    private void social(ServerLevel level) {
        if (this.greetCooldown > 0 || this.state == DRIVE || this.state == SEEK_CAR || this.state == SPOOK) {
            return;
        }
        this.greetCooldown = 25;
        Player player = level.getNearestPlayer(this.npc, 7.0);
        if (player == null) {
            return;
        }
        if (!this.npc.hasLineOfSight(player) || this.npc.getRandom().nextFloat() >= 0.45F) {
            return;
        }
        this.npc.getLookControl().setLookAt(player, 30.0F, 30.0F);
        this.npc.speak(Speech.pick(this.npc.getRandom(), "greet", this.npc.getProfile()), 55, false);
        if (this.state == IDLE || this.state == WALK || this.state == PATROL) {
            this.state = TALK;
            this.stateTicks = 0;
        }
    }

    private void talkTick(ServerLevel level) {
        Player player = level.getNearestPlayer(this.npc, 10.0);
        if (player != null) {
            this.npc.getLookControl().setLookAt(player, 30.0F, 30.0F);
        }
        if (this.stateTicks > 60) {
            this.pickTask(level);
        }
    }

    private boolean schedule(ServerLevel level) {
        if (this.state == SEEK_CAR || this.state == DRIVE || this.state == TALK
                || this.state == SEEK_RIDE || this.state == RIDE || this.state == SPOOK) {
            return false;
        }
        if (this.isGuard()) {
            if (this.state != PATROL) {
                this.state = PATROL;
                this.stateTicks = 0;
                this.resting = false;
                this.targetPos = null;
                this.say("patrol", false);
            }
            return false;
        }
        boolean night = isNight(level);
        if (night) {
            if (this.state != HOME) {
                this.state = HOME;
                this.stateTicks = 0;
                this.resting = false;
                this.targetPos = this.npc.getHomePos();
                this.say("evening", false);
                return true;
            }
            if (!this.resting) {
                return false;
            }
            if (this.stateTicks % 260 == 0 && this.npc.getRandom().nextFloat() < 0.5F) {
                this.say("night", false);
            }
            return true;
        }
        if ((this.state == HOME || this.state == SHELTER) && this.resting) {
            float release = this.state == HOME ? 0.02F : 0.05F;
            if (this.npc.getRandom().nextFloat() < release) {
                this.pickTask(level);
            } else {
                return true;
            }
        }
        if (this.state != SHELTER && level.isRainingAt(this.npc.blockPosition()) && !this.underRoof(level)) {
            this.startShelter(level);
            return true;
        }
        return false;
    }

    private boolean isNight(ServerLevel level) {
        long time = level.getDayTime() % 24000L;
        return time >= 13500L || time < 2000L;
    }

    private boolean underRoof(ServerLevel level) {
        BlockPos base = this.npc.blockPosition();
        for (int i = 1; i <= 12; i++) {
            BlockPos pos = base.above(i);
            if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private void startShelter(ServerLevel level) {
        this.state = SHELTER;
        this.stateTicks = 0;
        this.resting = false;
        BlockPos shelter = this.findShelter(level);
        this.targetPos = shelter != null ? shelter : this.npc.getHomePos();
        this.say("rain", false);
    }

    private BlockPos findShelter(ServerLevel level) {
        RandomSource random = this.npc.getRandom();
        BlockPos base = this.npc.blockPosition();
        for (int i = 0; i < 14; i++) {
            int dx = random.nextInt(25) - 12;
            int dz = random.nextInt(25) - 12;
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base.offset(dx, 0, dz));
            for (int j = 1; j <= 12; j++) {
                BlockPos pos = top.above(j);
                if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
                    return top;
                }
            }
        }
        return null;
    }

    private void idleTick(ServerLevel level) {
        if (this.idleTicks > 0) {
            this.idleTicks--;
            if (this.stateTicks % 120 == 0 && this.npc.getRandom().nextFloat() < 0.35F) {
                this.idleSpeak(level);
            }
            if (this.idleTicks == 0) {
                this.pickTask(level);
            }
            return;
        }
        this.pickTask(level);
    }

    private void idleSpeak(ServerLevel level) {
        long time = level.getDayTime() % 24000L;
        String situation;
        if (time >= 13500L || time < 2000L) {
            situation = "night";
        } else if (time >= 11000L) {
            situation = "evening";
        } else if (time < 3500L) {
            situation = "morning";
        } else {
            situation = "bored";
        }
        this.say(situation, false);
    }

    private void pickTask(ServerLevel level) {
        this.stateTicks = 0;
        this.targetPos = null;
        this.resting = false;
        if (this.cooldown > 0) {
            this.state = IDLE;
            this.idleTicks = 40;
            return;
        }
        String profile = this.npc.getProfile();
        RandomSource random = this.npc.getRandom();
        if ("driver".equals(profile) && random.nextFloat() < 0.6F) {
            Entity car = this.findCar(level);
            if (car != null) {
                this.carRef = car;
                this.state = SEEK_CAR;
                this.say("car_seek", false);
                return;
            }
        }
        if (this.isGuard()) {
            this.state = PATROL;
            return;
        }
        int radius;
        switch (profile) {
            case "wanderer" -> radius = 30;
            case "worker" -> radius = 16;
            case "coward" -> radius = 10;
            default -> radius = 24;
        }
        this.wander(level, radius);
    }

    private void wander(ServerLevel level, int radius) {
        RandomSource random = this.npc.getRandom();
        BlockPos home = this.npc.getHomePos();
        for (int i = 0; i < 10; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = 6.0 + random.nextDouble() * radius;
            int targetX = (int) Math.round(home.getX() + Math.cos(angle) * distance);
            int targetZ = (int) Math.round(home.getZ() + Math.sin(angle) * distance);
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    BlockPos.containing(targetX, home.getY(), targetZ));
            if (Math.abs(top.getY() - this.npc.getY()) > 12) {
                continue;
            }
            this.targetPos = top;
            break;
        }
        if (this.targetPos == null) {
            this.targetPos = home;
        }
        this.state = WALK;
    }

    private void walkTick(ServerLevel level) {
        if (this.state == SEEK_CAR) {
            this.seekCarTick(level);
            return;
        }
        if (this.state == SEEK_RIDE) {
            this.seekRideTick(level);
            return;
        }
        if (this.state == SPOOK) {
            this.spookTick(level);
            return;
        }
        if (this.resting) {
            return;
        }
        if (this.targetPos == null) {
            this.pickTask(level);
            return;
        }
        double distance = this.npc.position().distanceToSqr(
                this.targetPos.getX() + 0.5, this.targetPos.getY(), this.targetPos.getZ() + 0.5);
        if (distance < 9.0) {
            this.arrive(level);
            return;
        }
        if (this.stateTicks % 12 == 0 && this.npc.getNavigation().isDone()) {
            this.npc.getNavigation().moveTo(
                    this.targetPos.getX() + 0.5, this.targetPos.getY(), this.targetPos.getZ() + 0.5, this.speed());
        }
        if (this.stateTicks > 400) {
            this.pickTask(level);
        }
    }

    private void arrive(ServerLevel level) {
        this.npc.getNavigation().stop();
        switch (this.state) {
            case PATROL -> {
                this.state = IDLE;
                this.stateTicks = 0;
                this.targetPos = null;
                this.idleTicks = 80 + this.npc.getRandom().nextInt(200);
                if (this.npc.getRandom().nextFloat() < 0.35F) {
                    this.say("patrol", false);
                }
            }
            case HOME -> {
                this.resting = true;
                this.say("home", false);
            }
            case SHELTER -> {
                this.resting = true;
            }
            default -> {
                this.state = IDLE;
                this.stateTicks = 0;
                this.targetPos = null;
                this.idleTicks = 40 + this.npc.getRandom().nextInt(160);
                if ("worker".equals(this.npc.getProfile()) && this.npc.getRandom().nextFloat() < 0.5F) {
                    this.say("work", false);
                } else if (this.npc.getRandom().nextFloat() < 0.4F) {
                    this.idleSpeak(level);
                }
            }
        }
    }

    private double speed() {
        return switch (this.npc.getProfile()) {
            case "guard" -> 1.15D;
            case "worker" -> 0.95D;
            case "coward" -> 0.85D;
            default -> 1.0D;
        };
    }

    private void seekCarTick(ServerLevel level) {
        Entity car = this.carRef;
        if (car == null || car.isRemoved() || !isCar(car)) {
            this.carRef = null;
            this.pickTask(level);
            return;
        }
        if (this.npc.distanceTo(car) > 42.0F) {
            this.carRef = null;
            this.pickTask(level);
            return;
        }
        if (this.npc.distanceTo(car) < 2.6F) {
            this.npc.getNavigation().stop();
            if (this.npc.startRiding(car)) {
                this.state = DRIVE;
                this.stateTicks = 0;
                this.attempts = 0;
                this.driveGiveups = 0;
                this.stuckTicks = 0;
                this.reverseTicks = 0;
                this.hasDest = false;
                this.lastCarX = car.getX();
                this.lastCarZ = car.getZ();
                return;
            }
            this.carRef = null;
            this.pickTask(level);
            return;
        }
        if (this.npc.distanceTo(car) < 6.0F && this.npc.getNavigation().isDone()) {
            this.npc.getMoveControl().setWantedPosition(car.getX(), car.getY(), car.getZ(), 1.15);
        }
        if (this.stateTicks % 8 == 0 && this.npc.getNavigation().isDone()) {
            this.npc.getNavigation().moveTo(car, 1.15);
        }
        if (this.stateTicks > 400) {
            this.carRef = null;
            this.pickTask(level);
        }
    }

    public boolean onHorn(ServerLevel level, Entity car, Player honker) {
        if (this.npc.isPassenger() || this.resting) {
            return false;
        }
        if (this.state == DRIVE || this.state == SEEK_CAR || this.state == SEEK_RIDE || this.state == RIDE || this.state == SPOOK) {
            return false;
        }
        if (this.honkCooldown > 0) {
            return false;
        }
        if (this.npc.distanceTo(car) > 26.0F) {
            return false;
        }
        this.honkCooldown = 50;
        RandomSource random = this.npc.getRandom();
        if (random.nextFloat() >= 0.72F) {
            return false;
        }
        this.honkCooldown = 460;
        this.stateTicks = 0;
        this.idleTicks = 0;
        this.targetPos = null;
        float rideChance = switch (this.npc.getProfile()) {
            case "coward" -> 0.25F;
            case "guard" -> 0.45F;
            default -> 0.7F;
        };
        if (random.nextFloat() < rideChance) {
            this.carRef = car;
            this.state = SEEK_RIDE;
            this.say("ride_ask", true);
        } else {
            this.startSpook(level, car);
        }
        return true;
    }

    private void startSpook(ServerLevel level, Entity car) {
        this.carRef = null;
        this.state = SPOOK;
        this.stateTicks = 0;
        this.resting = false;
        RandomSource random = this.npc.getRandom();
        double dx = this.npc.getX() - car.getX();
        double dz = this.npc.getZ() - car.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-4) {
            dx = random.nextDouble() - 0.5;
            dz = random.nextDouble() - 0.5;
            length = Math.max(1.0E-4, Math.sqrt(dx * dx + dz * dz));
        }
        double runX = this.npc.getX() + dx / length * (18.0 + random.nextDouble() * 8.0);
        double runZ = this.npc.getZ() + dz / length * (18.0 + random.nextDouble() * 8.0);
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                BlockPos.containing(runX, this.npc.getY(), runZ));
        this.targetPos = top;
        this.say("honk", true);
        this.npc.getNavigation().moveTo(top.getX() + 0.5, top.getY(), top.getZ() + 0.5, 1.35);
    }

    private void spookTick(ServerLevel level) {
        if (this.targetPos == null) {
            this.state = IDLE;
            this.stateTicks = 0;
            this.idleTicks = 30;
            return;
        }
        double distance = this.npc.position().distanceToSqr(
                this.targetPos.getX() + 0.5, this.targetPos.getY(), this.targetPos.getZ() + 0.5);
        if (distance < 9.0 || this.stateTicks > 300) {
            this.state = IDLE;
            this.stateTicks = 0;
            this.targetPos = null;
            this.idleTicks = 40;
            if (distance < 9.0 && this.npc.getRandom().nextFloat() < 0.4F) {
                this.say("calm", false);
            }
            return;
        }
        if (this.stateTicks % 10 == 0 && this.npc.getNavigation().isDone()) {
            this.npc.getNavigation().moveTo(
                    this.targetPos.getX() + 0.5, this.targetPos.getY(), this.targetPos.getZ() + 0.5, 1.35);
        }
    }

    private void seekRideTick(ServerLevel level) {
        Entity car = this.carRef;
        if (car == null || car.isRemoved() || !isCar(car) || !(car.getFirstPassenger() instanceof Player)) {
            this.carRef = null;
            this.state = IDLE;
            this.stateTicks = 0;
            this.idleTicks = 60;
            return;
        }
        if (this.npc.distanceTo(car) > 42.0F) {
            this.carRef = null;
            this.state = IDLE;
            this.stateTicks = 0;
            this.idleTicks = 60;
            return;
        }
        if (this.npc.distanceTo(car) < 2.6F) {
            this.npc.getNavigation().stop();
            if (this.npc.startRiding(car)) {
                this.state = RIDE;
                this.stateTicks = 0;
                this.rideExitTicks = 0;
                this.rideStopTicks = 0;
                this.rideLastX = car.getX();
                this.rideLastZ = car.getZ();
                this.say("ride_in", false);
            } else {
                this.carRef = null;
                this.state = IDLE;
                this.stateTicks = 0;
                this.idleTicks = 80;
            }
            return;
        }
        if (this.npc.distanceTo(car) < 6.0F && this.npc.getNavigation().isDone()) {
            this.npc.getMoveControl().setWantedPosition(car.getX(), car.getY(), car.getZ(), 1.15);
        }
        if (this.stateTicks % 8 == 0 && this.npc.getNavigation().isDone()) {
            this.npc.getNavigation().moveTo(car, 1.15);
        }
        if (this.stateTicks > 500) {
            this.carRef = null;
            this.state = IDLE;
            this.stateTicks = 0;
            this.idleTicks = 60;
        }
    }

    private void rideTick(ServerLevel level, Entity car) {
        this.state = RIDE;
        if (!(car.getFirstPassenger() instanceof Player driver)) {
            this.rideExitTicks++;
            if (this.rideExitTicks > 60) {
                this.finishRide();
            }
            return;
        }
        this.rideExitTicks = 0;
        if (this.stateTicks % 20 == 0) {
            this.npc.getLookControl().setLookAt(driver, 30.0F, 30.0F);
        }
        double dx = car.getX() - this.rideLastX;
        double dz = car.getZ() - this.rideLastZ;
        this.rideLastX = car.getX();
        this.rideLastZ = car.getZ();
        if (dx * dx + dz * dz < 0.0025) {
            this.rideStopTicks++;
        } else {
            this.rideStopTicks = 0;
        }
        if (this.rideStopTicks > 240) {
            this.finishRide();
        }
    }

    private void finishRide() {
        this.npc.stopRiding();
        this.carRef = null;
        this.rideExitTicks = 0;
        this.rideStopTicks = 0;
        this.state = IDLE;
        this.stateTicks = 0;
        this.targetPos = null;
        this.idleTicks = 60;
        this.say("ride_out", false);
    }

    private void driveTick(ServerLevel level, Entity car) {
        this.state = DRIVE;
        if (car.getFirstPassenger() != this.npc) {
            if (this.stateTicks > 20) {
                this.npc.stopRiding();
            }
            return;
        }
        double carX = car.getX();
        double carZ = car.getZ();
        float yaw = car.getYRot();
        double forwardX = -Mth.sin(yaw * Mth.DEG_TO_RAD);
        double forwardZ = Mth.cos(yaw * Mth.DEG_TO_RAD);
        double speed = (carX - this.lastCarX) * forwardX + (carZ - this.lastCarZ) * forwardZ;
        this.lastCarX = carX;
        this.lastCarZ = carZ;
        if (!this.hasDest) {
            this.pickDest(level, carX, carZ, yaw);
        }
        double toX = this.destX - carX;
        double toZ = this.destZ - carZ;
        double distance = Math.sqrt(toX * toX + toZ * toZ);
        if (distance < 5.0) {
            if (Math.abs(speed) > 0.05) {
                this.npc.zza = speed > 0.0 ? -1.0F : 1.0F;
                this.npc.xxa = 0.0F;
            } else if (this.npc.isPermanentDriver()) {
                this.attempts = 0;
                this.driveGiveups = 0;
                this.stuckTicks = 0;
                this.reverseTicks = 0;
                this.hasDest = false;
                this.stateTicks = 0;
            } else {
                this.npc.zza = 0.0F;
                this.npc.xxa = 0.0F;
                this.npc.stopRiding();
                this.cooldown = 100;
                this.say("drive_done", false);
                this.pickTask(level);
            }
            return;
        }
        float desired = (float) (Mth.atan2(-toX, toZ) * (double) Mth.RAD_TO_DEG);
        float delta = Mth.wrapDegrees(desired - yaw);
        float steer = Mth.clamp(-delta * 0.05F, -1.0F, 1.0F);
        if (Math.abs(speed) < 0.02 && this.stateTicks > 50) {
            this.stuckTicks++;
        } else {
            this.stuckTicks = 0;
        }
        if (this.stuckTicks > 45) {
            this.stuckTicks = 0;
            this.reverseTicks = 30;
            this.attempts++;
        }
        if (this.attempts > 3) {
            if (Math.abs(speed) > 0.03) {
                this.npc.zza = speed > 0.0 ? -1.0F : 1.0F;
                this.npc.xxa = 0.0F;
                return;
            }
            if (this.npc.isPermanentDriver() && this.driveGiveups < 6) {
                this.driveGiveups++;
                this.attempts = 0;
                this.stuckTicks = 0;
                this.reverseTicks = 0;
                this.hasDest = false;
                this.stateTicks = 0;
                return;
            }
            this.npc.zza = 0.0F;
            this.npc.xxa = 0.0F;
            this.npc.stopRiding();
            this.npc.setPermanentDriver(false);
            this.banCarId = car.getUUID();
            this.banTicks = 800;
            this.say("stuck", false);
            this.pickTask(level);
            return;
        }
        float throttle;
        if (this.reverseTicks > 0) {
            this.reverseTicks--;
            throttle = -0.7F;
            steer = -steer;
        } else if (speed < 0.3) {
            throttle = 1.0F;
        } else if (Math.abs(delta) > 65.0F && speed > 0.42) {
            throttle = -0.7F;
        } else if (speed > 0.55) {
            throttle = -0.8F;
        } else {
            throttle = 0.0F;
        }
        this.npc.zza = throttle;
        this.npc.xxa = steer;
        if (this.stateTicks == 30 && Math.abs(speed) > 0.1) {
            this.say("drive_start", false);
        }
    }

    private void pickDest(ServerLevel level, double x, double z, float yaw) {
        RandomSource random = this.npc.getRandom();
        for (int i = 0; i < 10; i++) {
            float angle = yaw + (random.nextFloat() - 0.5F) * 140.0F;
            double length = 40.0 + random.nextDouble() * 30.0;
            double targetX = x - Mth.sin(angle * Mth.DEG_TO_RAD) * length;
            double targetZ = z + Mth.cos(angle * Mth.DEG_TO_RAD) * length;
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    BlockPos.containing(targetX, this.npc.getY(), targetZ));
            if (Math.abs(top.getY() - this.npc.getY()) <= 8.0) {
                this.destX = targetX;
                this.destZ = targetZ;
                this.hasDest = true;
                return;
            }
        }
        this.destX = x - Mth.sin(yaw * Mth.DEG_TO_RAD) * 30.0;
        this.destZ = z + Mth.cos(yaw * Mth.DEG_TO_RAD) * 30.0;
        this.hasDest = true;
    }

    private Entity findCar(ServerLevel level) {
        List<Entity> cars = level.getEntities(this.npc, this.npc.getBoundingBox().inflate(34.0),
                entity -> isCar(entity) && entity.getPassengers().isEmpty()
                        && (this.banCarId == null || !this.banCarId.equals(entity.getUUID())));
        return cars.isEmpty() ? null : cars.get(0);
    }

    public static boolean isCar(Entity entity) {
        if (entity == null) {
            return false;
        }
        return BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).getNamespace().equals("realcars");
    }

    private boolean isGuard() {
        return "guard".equals(this.npc.getProfile());
    }

    private void say(String situation, boolean urgent) {
        this.npc.speak(Speech.pick(this.npc.getRandom(), situation, this.npc.getProfile()), 55, urgent);
    }
}
