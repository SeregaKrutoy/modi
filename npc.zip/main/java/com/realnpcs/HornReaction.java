package com.realnpcs;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.List;

public final class HornReaction {
    private HornReaction() {
    }

    public static void onHorn(ServerLevel level, Entity car, LivingEntity honker) {
        if (!(honker instanceof Player)) {
            return;
        }
        if (car == null || car.isRemoved()) {
            return;
        }
        List<CitizenEntity> citizens = level.getEntitiesOfClass(CitizenEntity.class, car.getBoundingBox().inflate(26.0));
        for (CitizenEntity citizen : citizens) {
            citizen.getCitizenBrain().onHorn(level, car, (Player) honker);
        }
    }
}
