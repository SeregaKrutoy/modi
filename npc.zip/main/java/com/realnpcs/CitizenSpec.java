package com.realnpcs;

public record CitizenSpec(String variant, String nameKey, String profile) {
}
