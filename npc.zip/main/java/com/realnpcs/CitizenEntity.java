package com.realnpcs;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class CitizenEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> DATA_VARIANT =
            SynchedEntityData.defineId(CitizenEntity.class, EntityDataSerializers.STRING);

    private String nameKey = "";
    private String profile = "wanderer";
    private BlockPos homePos = BlockPos.ZERO;
    private final CitizenBrain brain = new CitizenBrain(this);
    private int speechTicks;
    private int speechCooldown;
    private boolean permanentDriver;

    public CitizenEntity(EntityType<? extends CitizenEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_VARIANT, "v01");
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            this.brain.tick();
            this.tickSpeech();
        }
    }

    private void tickSpeech() {
        if (this.speechCooldown > 0) {
            this.speechCooldown--;
        }
        if (this.speechTicks > 0) {
            this.speechTicks--;
            if (this.speechTicks == 0 && !this.nameKey.isEmpty()) {
                this.setCustomName(Component.translatable(this.nameKey));
            }
        }
    }

    public void speak(String key, int duration, boolean urgent) {
        if (key == null) {
            return;
        }
        if (!urgent && this.speechCooldown > 0) {
            return;
        }
        this.setCustomName(Component.translatable(key));
        this.speechTicks = duration;
        this.speechCooldown = duration + 40;
    }

    public void init(CitizenSpec spec, BlockPos home) {
        this.setVariant(spec.variant());
        this.nameKey = spec.nameKey();
        this.profile = spec.profile();
        this.homePos = home.immutable();
        this.applyIdentity();
    }

    public void applyIdentity() {
        if (!this.nameKey.isEmpty()) {
            this.setCustomName(Component.translatable(this.nameKey));
        }
        this.setCustomNameVisible(true);
    }

    public String getVariant() {
        return this.entityData.get(DATA_VARIANT);
    }

    public void setVariant(String variant) {
        this.entityData.set(DATA_VARIANT, variant);
    }

    public String getNameKey() {
        return this.nameKey;
    }

    public String getProfile() {
        return this.profile;
    }

    public boolean isPermanentDriver() {
        return this.permanentDriver;
    }

    public void setPermanentDriver(boolean permanentDriver) {
        this.permanentDriver = permanentDriver;
    }

    public BlockPos getHomePos() {
        return this.homePos;
    }

    public void setHomePos(BlockPos homePos) {
        this.homePos = homePos.immutable();
    }

    public CitizenBrain getCitizenBrain() {
        return this.brain;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide()) {
            this.getLookControl().setLookAt(player, 30.0F, 30.0F);
            this.brain.onTalked(player);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean hurt = super.hurtServer(level, source, amount);
        if (hurt) {
            this.brain.onHurt(source.getEntity());
        }
        return hurt;
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putString("variant", this.getVariant());
        output.putString("name_key", this.nameKey);
        output.putString("profile", this.profile);
        output.putLong("home", this.homePos.asLong());
        output.putBoolean("permanent_driver", this.permanentDriver);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setVariant(input.getStringOr("variant", "v01"));
        this.nameKey = input.getStringOr("name_key", "");
        this.profile = input.getStringOr("profile", "wanderer");
        this.homePos = BlockPos.of(input.getLongOr("home", BlockPos.ZERO.asLong()));
        this.permanentDriver = input.getBooleanOr("permanent_driver", false);
        if (this.nameKey.isEmpty()) {
            this.init(CitizenSpecs.random(this.getRandom()), this.blockPosition());
        } else {
            this.applyIdentity();
        }
    }
}
