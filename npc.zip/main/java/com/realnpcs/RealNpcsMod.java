package com.realnpcs;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class RealNpcsMod implements ModInitializer {
    public static final String MOD_ID = "realnpcs";
    public static EntityType<CitizenEntity> CITIZEN;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CitizenSpecs.load();
        Speech.load();

        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id("citizen"));
        CITIZEN = Registry.register(BuiltInRegistries.ENTITY_TYPE, key, EntityType.Builder
                .<CitizenEntity>of(CitizenEntity::new, MobCategory.CREATURE)
                .sized(0.6F, 1.8F)
                .eyeHeight(1.62F)
                .clientTrackingRange(10)
                .build(key));

        FabricDefaultAttributeRegistry.register(CITIZEN, Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 24.0));

        ServerTickEvents.END_WORLD_TICK.register(NpcSpawner::tickWorld);
    }
}
