package com.realnpcs;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.util.RandomSource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Speech {
    private static final Map<String, Map<String, List<String>>> DATA = new HashMap<>();
    private static final Map<String, List<String>> EMPTY = new HashMap<>();

    private Speech() {
    }

    public static void load() {
        DATA.clear();
        try (InputStream in = Speech.class.getResourceAsStream("/realnpcs_specs/speech.json")) {
            if (in == null) {
                return;
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> group : root.entrySet()) {
                Map<String, List<String>> situations = new HashMap<>();
                for (Map.Entry<String, JsonElement> situation : group.getValue().getAsJsonObject().entrySet()) {
                    List<String> keys = new ArrayList<>();
                    for (JsonElement key : situation.getValue().getAsJsonArray()) {
                        keys.add(key.getAsString());
                    }
                    situations.put(situation.getKey(), keys);
                }
                DATA.put(group.getKey(), situations);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static String pick(RandomSource random, String situation, String profile) {
        List<String> keys = null;
        Map<String, List<String>> byProfile = DATA.getOrDefault(profile, EMPTY);
        keys = byProfile.get(situation);
        if (keys == null) {
            keys = DATA.getOrDefault("common", EMPTY).get(situation);
        }
        if (keys == null || keys.isEmpty()) {
            return null;
        }
        return keys.get(random.nextInt(keys.size()));
    }
}
