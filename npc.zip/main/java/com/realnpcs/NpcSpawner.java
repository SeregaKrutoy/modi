package com.realnpcs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

public final class NpcSpawner {
    private static final float DRIVER_CHANCE = 0.8F;
    private static List<EntityType<?>> carTypes;

    private NpcSpawner() {
    }

    public static void tickWorld(ServerLevel level) {
        long time = level.getGameTime();
        if (time % 40L == 0L) {
            trySpawn(level);
        }
        if (time % 200L == 0L) {
            despawn(level);
        }
    }

    private static void trySpawn(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            int nearby = level.getEntitiesOfClass(CitizenEntity.class, player.getBoundingBox().inflate(96.0)).size();
            boolean driverRoom = level.getEntitiesOfClass(CitizenEntity.class, player.getBoundingBox().inflate(140.0),
                    CitizenEntity::isPermanentDriver).size() < 3;
            if (nearby >= 6 && !driverRoom) {
                continue;
            }
            for (int i = 0; i < 6; i++) {
                if (attempt(level, player, nearby < 6, driverRoom)) {
                    break;
                }
            }
        }
    }

    private static boolean attempt(ServerLevel level, ServerPlayer player, boolean allowWalker, boolean allowDriver) {
        RandomSource random = level.getRandom();
        float angle = player.getYRot() + 180.0F + (random.nextFloat() - 0.5F) * 130.0F;
        double distance = 26.0 + random.nextDouble() * 20.0;
        double spawnX = player.getX() - Mth.sin(angle * Mth.DEG_TO_RAD) * distance;
        double spawnZ = player.getZ() + Mth.cos(angle * Mth.DEG_TO_RAD) * distance;
        double viewX = -Mth.sin(player.getYRot() * Mth.DEG_TO_RAD);
        double viewZ = Mth.cos(player.getYRot() * Mth.DEG_TO_RAD);
        double dirX = spawnX - player.getX();
        double dirZ = spawnZ - player.getZ();
        double length = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (length > 1.0E-4 && (dirX / length * viewX + dirZ / length * viewZ) > -0.25) {
            return false;
        }
        BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                BlockPos.containing(spawnX, player.getY(), spawnZ));
        if (Math.abs(surface.getY() - player.getY()) > 20) {
            return false;
        }
        if (!isFree(level, surface)) {
            return false;
        }
        String profile = allowWalker ? spawnProfile(level, random) : "driver";
        if ("driver".equals(profile) && allowDriver && (!allowWalker || random.nextFloat() < DRIVER_CHANCE)
                && spawnDriver(level, spawnX, spawnZ, surface, random)) {
            return true;
        }
        if (!allowWalker) {
            return false;
        }
        CitizenEntity npc = RealNpcsMod.CITIZEN.create(level, EntitySpawnReason.NATURAL);
        if (npc == null) {
            return false;
        }
        npc.snapTo(spawnX, surface.getY(), spawnZ, random.nextFloat() * 360.0F, 0.0F);
        npc.init(CitizenSpecs.pick(random, profile), surface);
        level.addFreshEntity(npc);
        if (random.nextFloat() < 0.35F) {
            spawnCompanion(level, surface, random);
        }
        return true;
    }

    private static boolean spawnDriver(ServerLevel level, double x, double z, BlockPos surface, RandomSource random) {
        List<EntityType<?>> cars = carTypes();
        if (cars.isEmpty()) {
            return false;
        }
        AABB clearance = new AABB(x - 0.9, surface.getY(), z - 0.9, x + 0.9, surface.getY() + 2.0, z + 0.9);
        if (!level.noCollision(null, clearance)) {
            return false;
        }
        EntityType<?> type = cars.get(random.nextInt(cars.size()));
        Entity car = type.create(level, EntitySpawnReason.NATURAL);
        if (car == null) {
            return false;
        }
        float yaw = random.nextFloat() * 360.0F;
        car.snapTo(x, surface.getY(), z, yaw, 0.0F);
        level.addFreshEntity(car);
        CitizenEntity npc = RealNpcsMod.CITIZEN.create(level, EntitySpawnReason.NATURAL);
        if (npc == null) {
            car.discard();
            return false;
        }
        npc.snapTo(x, surface.getY(), z, yaw, 0.0F);
        npc.init(CitizenSpecs.pick(random, "driver"), surface);
        npc.setPermanentDriver(true);
        level.addFreshEntity(npc);
        if (!npc.startRiding(car)) {
            npc.discard();
            car.discard();
            return false;
        }
        return true;
    }

    private static List<EntityType<?>> carTypes() {
        if (carTypes == null) {
            List<EntityType<?>> list = new ArrayList<>();
            for (Identifier id : BuiltInRegistries.ENTITY_TYPE.keySet()) {
                if (!id.getNamespace().equals("realcars")) {
                    continue;
                }
                EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getValue(id);
                if (type != null) {
                    list.add(type);
                }
            }
            carTypes = list;
        }
        return carTypes;
    }

    private static void spawnCompanion(ServerLevel level, BlockPos around, RandomSource random) {
        for (int i = 0; i < 5; i++) {
            BlockPos candidate = around.offset(random.nextInt(9) - 4, 0, random.nextInt(9) - 4);
            BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, candidate);
            if (Math.abs(surface.getY() - around.getY()) > 3) {
                continue;
            }
            if (!isFree(level, surface)) {
                continue;
            }
            CitizenEntity npc = RealNpcsMod.CITIZEN.create(level, EntitySpawnReason.NATURAL);
            if (npc == null) {
                return;
            }
            npc.snapTo(surface.getX() + 0.5, surface.getY(), surface.getZ() + 0.5, random.nextFloat() * 360.0F, 0.0F);
            npc.init(CitizenSpecs.pick(random, spawnProfile(level, random)), surface);
            level.addFreshEntity(npc);
            return;
        }
    }

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        if (!level.getFluidState(pos).isEmpty() || !level.getFluidState(pos.above()).isEmpty()) {
            return false;
        }
        if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
            return false;
        }
        if (!level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()) {
            return false;
        }
        return !level.getBlockState(pos.below()).getCollisionShape(level, pos.below()).isEmpty();
    }

    private static String spawnProfile(ServerLevel level, RandomSource random) {
        long time = level.getDayTime() % 24000L;
        boolean night = time >= 13500L || time < 2000L;
        if (night) {
            float roll = random.nextFloat();
            if (roll < 0.40F) {
                return "guard";
            }
            if (roll < 0.65F) {
                return "coward";
            }
            if (roll < 0.80F) {
                return "driver";
            }
            return "wanderer";
        }
        float roll = random.nextFloat();
        if (roll < 0.36F) {
            return "driver";
        }
        if (roll < 0.58F) {
            return "wanderer";
        }
        if (roll < 0.76F) {
            return "worker";
        }
        if (roll < 0.90F) {
            return "guard";
        }
        return "coward";
    }

    private static void despawn(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        for (ServerPlayer player : players) {
            List<CitizenEntity> citizens = level.getEntitiesOfClass(CitizenEntity.class, player.getBoundingBox().inflate(140.0));
            for (CitizenEntity npc : citizens) {
                if (npc.tickCount < 2400) {
                    continue;
                }
                if (npc.distanceTo(player) <= 118.0F) {
                    continue;
                }
                boolean nearOther = false;
                for (ServerPlayer other : players) {
                    if (other != player && npc.distanceTo(other) <= 118.0F) {
                        nearOther = true;
                        break;
                    }
                }
                if (!nearOther) {
                    Entity vehicle = npc.getVehicle();
                    if (vehicle != null && CitizenBrain.isCar(vehicle) && vehicle.getControllingPassenger() == npc) {
                        vehicle.discard();
                    }
                    npc.discard();
                }
            }
        }
    }
}
