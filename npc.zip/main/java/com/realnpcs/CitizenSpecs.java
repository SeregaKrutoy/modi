package com.realnpcs;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.util.RandomSource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class CitizenSpecs {
    private static final List<CitizenSpec> ALL = new ArrayList<>();

    private CitizenSpecs() {
    }

    public static void load() {
        ALL.clear();
        try (InputStream in = CitizenSpecs.class.getResourceAsStream("/realnpcs_specs/citizens.json")) {
            if (in == null) {
                return;
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (JsonElement element : root.getAsJsonArray("variants")) {
                JsonObject object = element.getAsJsonObject();
                ALL.add(new CitizenSpec(
                        object.get("id").getAsString(),
                        object.get("name").getAsString(),
                        object.get("profile").getAsString()));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static CitizenSpec random(RandomSource random) {
        if (ALL.isEmpty()) {
            return new CitizenSpec("v01", "realnpcs.name.v01", "wanderer");
        }
        return ALL.get(random.nextInt(ALL.size()));
    }

    public static CitizenSpec pick(RandomSource random, String profile) {
        List<CitizenSpec> matches = new ArrayList<>();
        for (CitizenSpec spec : ALL) {
            if (spec.profile().equals(profile)) {
                matches.add(spec);
            }
        }
        if (matches.isEmpty()) {
            return random(random);
        }
        return matches.get(random.nextInt(matches.size()));
    }
}
