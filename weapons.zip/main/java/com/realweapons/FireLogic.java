package com.realweapons;

import java.util.Optional;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class FireLogic {
	private FireLogic() {
	}

	public static void fire(ServerPlayer player, boolean aiming) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		if (player.isSpectator() || player.isUsingItem()) {
			return;
		}
		ItemStack stack = player.getMainHandItem();
		if (!(stack.getItem() instanceof WeaponItem weapon)) {
			return;
		}
		WeaponSpec spec = weapon.spec();
		switch (spec.category()) {
			case KNIFE -> knifeAttack(player, level, spec);
			case MOLOTOV, FLASHBANG, FRAG, SMOKE -> throwGrenade(player, level, spec, stack);
			case GRENADE_LAUNCHER -> launchGrenade(player, level, spec, stack);
			case RPG -> launchRocket(player, level, spec, stack);
			default -> shoot(player, level, spec, stack, aiming);
		}
	}

	public static void reload(ServerPlayer player) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		ItemStack stack = player.getMainHandItem();
		if (!(stack.getItem() instanceof WeaponItem weapon)) {
			return;
		}
		startReload(player, level, weapon.spec(), stack);
	}

	public static void finishReload(ServerPlayer player, String weaponId) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		ItemStack stack = player.getMainHandItem();
		if (!(stack.getItem() instanceof WeaponItem weapon) || !weapon.spec().id().equals(weaponId)) {
			return;
		}
		stack.set(Components.MAGAZINE, new Components.Magazine(weapon.spec().magSize()));
		broadcast(level, player.position(), 48.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.RELOAD_END, weaponId), null);
	}

	private static void startReload(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack) {
		if (spec.magSize() <= 0 || spec.reloadTicks() <= 0) {
			return;
		}
		if (ServerState.isReloading(player)) {
			return;
		}
		Components.Magazine magazine = stack.getOrDefault(Components.MAGAZINE,
				new Components.Magazine(spec.magSize()));
		if (magazine.count() >= spec.magSize()) {
			return;
		}
		long end = level.getGameTime() + spec.reloadTicks();
		ServerState.startReload(player, spec.id(), end);
		broadcast(level, player.position(), 48.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.RELOAD_START, spec.id()), player);
	}

	private static boolean prepareShot(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack) {
		if (ServerState.isReloading(player)) {
			return false;
		}
		long now = level.getGameTime();
		Components.Magazine magazine = stack.getOrDefault(Components.MAGAZINE,
				new Components.Magazine(spec.magSize()));
		if (magazine.count() <= 0) {
			dryFire(player, level, spec, stack, now);
			return false;
		}
		if (ServerState.onCooldown(player, spec, now)) {
			return false;
		}
		ServerState.markAction(player, now);
		stack.set(Components.MAGAZINE, new Components.Magazine(magazine.count() - 1));
		return true;
	}

	private static void dryFire(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack, long now) {
		if (ServerState.dryCooldown(player, now)) {
			ServerState.markDry(player, now);
			playSound(player, level, player.getX(), player.getEyeY(), player.getZ(), "weapon.dry", 1.0F,
					1.0F + player.getRandom().nextFloat() * 0.1F);
		}
		startReload(player, level, spec, stack);
	}

	private static void shoot(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack,
			boolean aiming) {
		if (!prepareShot(player, level, spec, stack)) {
			return;
		}
		Vec3 eye = player.getEyePosition();
		Vec3 dir = player.getViewVector(1.0F);
		double spread = spec.spread();
		if (player.isCrouching()) {
			spread *= 0.55;
		}
		if (player.getDeltaMovement().horizontalDistanceSqr() > 0.015) {
			spread *= 1.65;
		}
		if (aiming) {
			spread *= 0.45;
		}

		Vec3 tracerEnd = null;
		for (int i = 0; i < spec.pellets(); i++) {
			Vec3 pelletDir = applySpread(dir, spread, player.getRandom());
			RayHit hit = raycast(level, player, eye, pelletDir, spec.range());
			applyHit(player, level, spec, hit, pelletDir);
			if (i == 0) {
				tracerEnd = hit.point();
			}
		}
		if (tracerEnd == null) {
			tracerEnd = eye.add(dir.scale(spec.range()));
		}
		playSound(player, level, player.getX(), player.getEyeY(), player.getZ(), "weapon." + spec.id(),
				fireVolume(spec), 1.0F + player.getRandom().nextFloat() * 0.05F);
		spawnShotFx(level, spec, eye, dir, tracerEnd);
		broadcast(level, player.position(), 64.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.FIRE, spec.id()), player);
	}

	private static void knifeAttack(ServerPlayer player, ServerLevel level, WeaponSpec spec) {
		long now = level.getGameTime();
		if (ServerState.onCooldown(player, spec, now)) {
			return;
		}
		ServerState.markAction(player, now);
		Vec3 eye = player.getEyePosition();
		Vec3 dir = player.getViewVector(1.0F);
		RayHit hit = raycast(level, player, eye, dir, spec.range());
		playSound(null, level, player.getX(), player.getEyeY(), player.getZ(), "melee.swing", 0.9F,
				1.0F + player.getRandom().nextFloat() * 0.1F);
		if (hit.entity() != null) {
			DamageSource source = source(level, player, "knife");
			if (hit.entity().hurtServer(level, source, (float) spec.damage())) {
				Vec3 push = dir.scale(spec.knockback()).add(0.0, 0.06, 0.0);
				hit.entity().push(push.x, push.y, push.z);
				hit.entity().hurtMarked = true;
				playSound(null, level, hit.point().x, hit.point().y, hit.point().z, "melee.hit", 1.0F,
						0.95F + player.getRandom().nextFloat() * 0.1F);
			}
		}
	}

	private static void throwGrenade(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack) {
		if (ServerState.isReloading(player)) {
			return;
		}
		long now = level.getGameTime();
		if (ServerState.onCooldown(player, spec, now) || stack.isEmpty()) {
			return;
		}
		ServerState.markAction(player, now);
		ThrowableItemProjectile projectile = switch (spec.category()) {
			case MOLOTOV -> new MolotovEntity(level, player, stack.copyWithCount(1));
			case FLASHBANG -> new FlashbangEntity(level, player, stack.copyWithCount(1));
			case FRAG -> new FragGrenadeEntity(level, player, stack.copyWithCount(1));
			case SMOKE -> new SmokeGrenadeEntity(level, player, stack.copyWithCount(1));
			default -> null;
		};
		if (projectile == null) {
			return;
		}
		projectile.setPos(player.getX(), player.getEyeY() - 0.15, player.getZ());
		projectile.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, (float) spec.throwVelocity(),
				0.6F);
		level.addFreshEntity(projectile);
		if (!player.hasInfiniteMaterials()) {
			stack.shrink(1);
		}
		playSound(player, level, player.getX(), player.getEyeY(), player.getZ(), "throw.whoosh", 1.2F,
				0.9F + player.getRandom().nextFloat() * 0.15F);
		broadcast(level, player.position(), 48.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.THROW, spec.id()), player);
	}

	private static void launchGrenade(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack) {
		if (!prepareShot(player, level, spec, stack)) {
			return;
		}
		Vec3 eye = player.getEyePosition();
		Vec3 dir = player.getViewVector(1.0F);
		Vec3 muzzle = eye.add(dir.scale(spec.muzzleOffset() * 0.6)).add(0.0, -0.1, 0.0);
		GrenadeShellEntity shell = new GrenadeShellEntity(level, player, stack.copyWithCount(1));
		shell.setPos(muzzle);
		shell.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.05F, 0.35F);
		level.addFreshEntity(shell);
		playSound(player, level, player.getX(), player.getEyeY(), player.getZ(), "weapon.grenade_launcher", 5.0F,
				1.0F);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, muzzle.x, muzzle.y, muzzle.z, 6, 0.12, 0.12, 0.12, 0.04);
		level.sendParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 3, 0.08, 0.08, 0.08, 0.02);
		broadcast(level, player.position(), 64.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.FIRE, spec.id()), player);
	}

	private static void launchRocket(ServerPlayer player, ServerLevel level, WeaponSpec spec, ItemStack stack) {
		if (!prepareShot(player, level, spec, stack)) {
			return;
		}
		Vec3 eye = player.getEyePosition();
		Vec3 dir = player.getViewVector(1.0F);
		Vec3 muzzle = eye.add(dir.scale(spec.muzzleOffset() * 0.5)).add(0.0, -0.12, 0.0);
		RocketEntity rocket = new RocketEntity(level, player, stack.copyWithCount(1));
		rocket.setPos(muzzle);
		rocket.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.5F, 0.15F);
		level.addFreshEntity(rocket);
		playSound(player, level, player.getX(), player.getEyeY(), player.getZ(), "rocket.launch", 6.0F, 1.0F);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, muzzle.x, muzzle.y, muzzle.z, 10, 0.18, 0.18, 0.18, 0.06);
		level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, muzzle.x - dir.x, muzzle.y - dir.y, muzzle.z - dir.z, 6,
				0.3, 0.3, 0.3, 0.03);
		broadcast(level, player.position(), 64.0,
				new WeaponEventPayload(player.getId(), WeaponEventPayload.FIRE, spec.id()), player);
	}

	private static void applyHit(ServerPlayer shooter, ServerLevel level, WeaponSpec spec, RayHit hit, Vec3 dir) {
		Entity entity = hit.entity();
		if (entity != null) {
			double damage = spec.damage();
			if (spec.range() > 0.0 && spec.pellets() == 1) {
				double half = spec.range() * 0.5;
				if (hit.distance() > half) {
					damage *= Mth.lerp((hit.distance() - half) / half, 1.0, 0.65);
				}
			}
			boolean headshot = entity instanceof LivingEntity && hit.point().y >= entity.getEyeY() - 0.15;
			if (headshot) {
				damage *= 2.0;
			}
			DamageSource source = source(level, shooter, "bullet");
			if (entity.hurtServer(level, source, (float) damage)) {
				Vec3 push = dir.scale(spec.knockback()).add(0.0, 0.04, 0.0);
				entity.push(push.x, push.y, push.z);
				entity.hurtMarked = true;
				ServerPlayNetworking.send(shooter, new HitMarkerPayload(headshot));
				playSound(null, level, hit.point().x, hit.point().y, hit.point().z,
						headshot ? "impact.head" : "impact.flesh", 1.4F,
						headshot ? 1.0F : 0.95F + shooter.getRandom().nextFloat() * 0.1F);
				level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, hit.point().x, hit.point().y + 0.2, hit.point().z,
						3, 0.15, 0.15, 0.15, 0.1);
			}
		} else if (hit.blockPos() != null) {
			BlockState state = level.getBlockState(hit.blockPos());
			level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), hit.point().x, hit.point().y,
					hit.point().z, 10, 0.1, 0.1, 0.1, 0.12);
			playSound(null, level, hit.point().x, hit.point().y, hit.point().z, "impact.solid", 1.0F,
					1.0F + shooter.getRandom().nextFloat() * 0.15F);
		}
	}

	private record RayHit(Entity entity, Vec3 point, BlockPos blockPos, double distance) {
	}

	private static RayHit raycast(ServerLevel level, ServerPlayer shooter, Vec3 start, Vec3 dir, double range) {
		Vec3 end = start.add(dir.scale(range));
		BlockHitResult blockHit = level.clip(
				new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
		double closest = blockHit.getType() == HitResult.Type.MISS ? range : start.distanceTo(blockHit.getLocation());
		Entity hitEntity = null;
		Vec3 hitPoint = null;
		AABB area = shooter.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0);
		for (Entity candidate : level.getEntities(shooter, area, e -> isValidTarget(shooter, e))) {
			Optional<Vec3> clip = candidate.getBoundingBox().inflate(0.22).clip(start, end);
			if (clip.isPresent()) {
				double distance = start.distanceTo(clip.get());
				if (distance < closest) {
					closest = distance;
					hitEntity = candidate;
					hitPoint = clip.get();
				}
			}
		}
		if (hitEntity != null) {
			return new RayHit(hitEntity, hitPoint, null, closest);
		}
		if (blockHit.getType() != HitResult.Type.MISS) {
			return new RayHit(null, blockHit.getLocation(), blockHit.getBlockPos(), closest);
		}
		return new RayHit(null, end, null, range);
	}

	private static boolean isValidTarget(ServerPlayer shooter, Entity entity) {
		return entity != shooter && entity != shooter.getVehicle() && entity.isAlive() && entity.isPickable()
				&& !entity.isSpectator();
	}

	private static Vec3 applySpread(Vec3 dir, double spreadDegrees, RandomSource random) {
		if (spreadDegrees <= 0.0) {
			return dir;
		}
		double spread = Math.toRadians(spreadDegrees);
		double angle = random.nextDouble() * Math.PI * 2.0;
		double radius = Math.sqrt(random.nextDouble()) * spread;
		Vec3 up = Math.abs(dir.y) > 0.99 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(0.0, 1.0, 0.0);
		Vec3 right = dir.cross(up).normalize();
		Vec3 vertical = right.cross(dir).normalize();
		return dir.add(right.scale(Math.cos(angle) * radius)).add(vertical.scale(Math.sin(angle) * radius)).normalize();
	}

	private static float fireVolume(WeaponSpec spec) {
		return switch (spec.category()) {
			case SNIPER, RPG -> 9.0F;
			case SHOTGUN_DOUBLE, SHOTGUN_PUMP, GRENADE_LAUNCHER -> 7.0F;
			case MACHINE_GUN, RIFLE -> 6.0F;
			default -> 5.0F;
		};
	}

	private static DamageSource source(ServerLevel level, ServerPlayer shooter, String id) {
		Holder<DamageType> holder = level.registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE)
				.getOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, RealWeaponsMod.id(id)));
		return new DamageSource(holder, shooter);
	}

	private static void spawnShotFx(ServerLevel level, WeaponSpec spec, Vec3 eye, Vec3 dir, Vec3 impact) {
		Vec3 muzzle = eye.add(dir.scale(spec.muzzleOffset())).add(0.0, -0.08, 0.0);
		level.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 4, 0.03, 0.03, 0.03, 0.02);

		Vec3 right = dir.cross(new Vec3(0.0, 1.0, 0.0));
		if (right.lengthSqr() < 1.0E-4) {
			right = new Vec3(1.0, 0.0, 0.0);
		}
		right = right.normalize();
		level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.GOLD_NUGGET)),
				eye.x + dir.x * 0.5 + right.x * 0.3, eye.y + dir.y * 0.5 - 0.28, eye.z + dir.z * 0.5 + right.z * 0.3,
				1, right.x * 0.06, 0.12, right.z * 0.06, 0.25);
	}

	private static void playSound(ServerPlayer except, ServerLevel level, double x, double y, double z, String id,
			float volume, float pitch) {
		SoundEvent sound = ModContent.sound(id);
		if (sound != null) {
			level.playSound(except, x, y, z, sound, SoundSource.PLAYERS, volume, pitch);
		}
	}

	private static void broadcast(ServerLevel level, Vec3 pos, double radius, WeaponEventPayload payload,
			ServerPlayer exclude) {
		double radiusSqr = radius * radius;
		for (ServerPlayer other : level.players()) {
			if (other == exclude) {
				continue;
			}
			if (other.position().distanceToSqr(pos) <= radiusSqr) {
				ServerPlayNetworking.send(other, payload);
			}
		}
	}
}
