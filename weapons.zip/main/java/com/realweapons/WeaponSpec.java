package com.realweapons;

public record WeaponSpec(
		String id,
		WeaponCategory category,
		double damage,
		int pellets,
		int interval,
		int magSize,
		int reloadTicks,
		boolean automatic,
		double spread,
		double recoil,
		double range,
		double knockback,
		int adsZoom,
		double muzzleOffset,
		double throwVelocity,
		int fuseTicks
) {
	public static WeaponSpec gun(String id, WeaponCategory category, double damage, int pellets, int interval,
			int magSize, int reloadTicks, boolean automatic, double spread, double recoil, double range,
			double knockback, int adsZoom, double muzzleOffset) {
		return new WeaponSpec(id, category, damage, pellets, interval, magSize, reloadTicks, automatic, spread,
				recoil, range, knockback, adsZoom, muzzleOffset, 0.0, 0);
	}

	public static WeaponSpec launcher(String id, WeaponCategory category, int interval, int magSize, int reloadTicks,
			double recoil, int adsZoom, double muzzleOffset, int fuseTicks) {
		return new WeaponSpec(id, category, 0.0, 1, interval, magSize, reloadTicks, false, 0.4, recoil, 0.0, 0.0,
				adsZoom, muzzleOffset, 0.0, fuseTicks);
	}

	public static WeaponSpec throwable(String id, WeaponCategory category, int interval, double throwVelocity,
			int fuseTicks) {
		return new WeaponSpec(id, category, 0.0, 0, interval, 0, 0, false, 0.0, 0.0, 0.0, 0.0, 0, 0.0,
				throwVelocity, fuseTicks);
	}

	public static WeaponSpec knife(String id, double damage, double range, double knockback) {
		return new WeaponSpec(id, WeaponCategory.KNIFE, damage, 1, 11, 0, 0, false, 0.0, 0.18, range, knockback, 0,
				0.0, 0.0, 0);
	}
}
