package com.realweapons;

import java.util.LinkedHashMap;
import java.util.Map;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModContent {
	public static final Map<String, Item> ITEMS = new LinkedHashMap<>();
	public static final Map<String, SoundEvent> SOUNDS = new LinkedHashMap<>();

	public static final EntityType<FragGrenadeEntity> FRAG_GRENADE =
			registerEntity("frag_grenade", FragGrenadeEntity::new, 0.25F, 0.25F);
	public static final EntityType<SmokeGrenadeEntity> SMOKE_GRENADE =
			registerEntity("smoke_grenade", SmokeGrenadeEntity::new, 0.25F, 0.25F);
	public static final EntityType<FlashbangEntity> FLASHBANG =
			registerEntity("flashbang", FlashbangEntity::new, 0.25F, 0.25F);
	public static final EntityType<MolotovEntity> MOLOTOV =
			registerEntity("molotov", MolotovEntity::new, 0.25F, 0.25F);
	public static final EntityType<GrenadeShellEntity> GRENADE_SHELL =
			registerEntity("grenade_shell", GrenadeShellEntity::new, 0.25F, 0.25F);
	public static final EntityType<RocketEntity> ROCKET =
			registerEntity("rocket", RocketEntity::new, 0.3F, 0.3F);

	private static final ArmorMaterial VEST_MATERIAL = new ArmorMaterial(
			25,
			Map.of(ArmorType.CHESTPLATE, 8),
			12,
			SoundEvents.ARMOR_EQUIP_IRON,
			1.5F,
			0.0F,
			ItemTags.REPAIRS_IRON_ARMOR,
			ResourceKey.create(EquipmentAssets.ROOT_ID, RealWeaponsMod.id("vest"))
	);

	private static final String[] SOUND_IDS = {
			"weapon.pistol", "weapon.revolver", "weapon.double_barrel", "weapon.pump_shotgun", "weapon.combat_mg",
			"weapon.assault_rifle", "weapon.assault_sniper", "weapon.grenade_launcher", "weapon.rpg",
			"reload.mag_out", "reload.mag_in", "reload.rack", "reload.pump", "reload.shell", "reload.belt",
			"reload.cylinder", "reload.break_open", "reload.break_close", "reload.rocket",
			"weapon.dry", "melee.swing", "melee.hit",
			"impact.flesh", "impact.head", "impact.solid", "impact.hitmarker",
			"explosion.grenade", "explosion.rpg", "flashbang.bang", "smoke.pop", "fire.ignite", "glass.break",
			"throw.whoosh", "rocket.launch", "bounce.clink"
	};

	private ModContent() {
	}

	public static void register() {
		for (WeaponSpec spec : WeaponSpecs.all()) {
			registerWeapon(spec);
		}
		registerVest();

		for (String id : SOUND_IDS) {
			SoundEvent sound = SoundEvent.createVariableRangeEvent(RealWeaponsMod.id(id));
			Registry.register(BuiltInRegistries.SOUND_EVENT,
					ResourceKey.create(Registries.SOUND_EVENT, RealWeaponsMod.id(id)), sound);
			SOUNDS.put(id, sound);
		}

		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
			for (Item item : ITEMS.values()) {
				entries.accept(item);
			}
		});
	}

	public static Item item(String id) {
		return ITEMS.get(id);
	}

	public static SoundEvent sound(String id) {
		return SOUNDS.get(id);
	}

	private static void registerWeapon(WeaponSpec spec) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, RealWeaponsMod.id(spec.id()));
		Item.Properties properties = new Item.Properties()
				.setId(key)
				.stacksTo(spec.category().isThrowable() ? 16 : 1);
		if (spec.magSize() > 0) {
			properties = properties.component(Components.MAGAZINE, new Components.Magazine(spec.magSize()));
		}
		Item item = new WeaponItem(spec, properties);
		Registry.register(BuiltInRegistries.ITEM, key, item);
		ITEMS.put(spec.id(), item);
	}

	private static void registerVest() {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, RealWeaponsMod.id("vest"));
		Item item = new Item(new Item.Properties().setId(key).humanoidArmor(VEST_MATERIAL, ArmorType.CHESTPLATE));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		ITEMS.put("vest", item);
	}

	private static <T extends Entity> EntityType<T> registerEntity(String id, EntityType.EntityFactory<T> factory,
			float width, float height) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, RealWeaponsMod.id(id));
		EntityType<T> type = EntityType.Builder.of(factory, MobCategory.MISC)
				.sized(width, height)
				.clientTrackingRange(8)
				.updateInterval(1)
				.build(key);
		Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
		return type;
	}
}
