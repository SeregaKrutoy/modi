package com.realweapons;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record WeaponEventPayload(int entityId, int event, String weapon) implements CustomPacketPayload {
	public static final int FIRE = 0;
	public static final int RELOAD_START = 1;
	public static final int RELOAD_END = 2;
	public static final int THROW = 3;

	public static final CustomPacketPayload.Type<WeaponEventPayload> TYPE =
			new CustomPacketPayload.Type<>(RealWeaponsMod.id("weapon_event"));

	public static final StreamCodec<RegistryFriendlyByteBuf, WeaponEventPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, WeaponEventPayload::entityId,
			ByteBufCodecs.VAR_INT, WeaponEventPayload::event,
			ByteBufCodecs.STRING_UTF8, WeaponEventPayload::weapon,
			WeaponEventPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
