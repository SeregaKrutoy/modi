package com.realweapons;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record FirePayload(boolean aiming) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<FirePayload> TYPE =
			new CustomPacketPayload.Type<>(RealWeaponsMod.id("fire"));

	public static final StreamCodec<RegistryFriendlyByteBuf, FirePayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL, FirePayload::aiming,
			FirePayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
