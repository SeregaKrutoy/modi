package com.realweapons;

import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class FlashbangEntity extends BaseGrenadeEntity {
	public FlashbangEntity(EntityType<FlashbangEntity> entityType, Level level) {
		super(entityType, level);
	}

	public FlashbangEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.FLASHBANG, owner, level, stack);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("flashbang");
	}

	@Override
	protected int fuseTicks() {
		return 50;
	}

	@Override
	protected boolean impactDetonates() {
		return false;
	}

	@Override
	protected void detonate(ServerLevel level) {
		Vec3 pos = this.position();
		WeaponFx.playSound(level, pos, "flashbang.bang", 14.0F, 1.0F);
		level.sendParticles(ColorParticleOption.create(ParticleTypes.FLASH, 16777215), pos.x, pos.y + 0.2, pos.z, 2,
				0.0, 0.0, 0.0, 0.0);
		level.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y + 0.2, pos.z, 28, 0.6, 0.6, 0.6, 0.4);

		AABB area = new AABB(pos, pos).inflate(14.0);
		for (Entity entity : level.getEntities((Entity) null, area, e -> e instanceof LivingEntity)) {
			LivingEntity living = (LivingEntity) entity;
			Vec3 toBlast = pos.subtract(living.getEyePosition());
			if (toBlast.lengthSqr() < 1.0E-4) {
				continue;
			}
			toBlast = toBlast.normalize();
			boolean facing = living.getViewVector(1.0F).dot(toBlast) > 0.35;
			if (facing) {
				living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 140, 0));
				living.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 100, 0));
			} else {
				living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 45, 0));
			}
		}
	}
}
