package com.realweapons;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class WeaponFx {
	private WeaponFx() {
	}

	public static void explosion(ServerLevel level, Vec3 pos, float power, Entity source) {
		level.explode(source, pos.x, pos.y, pos.z, power, Level.ExplosionInteraction.NONE);
	}

	public static void playSound(ServerLevel level, Vec3 pos, String id, float volume, float pitch) {
		SoundEvent sound = ModContent.sound(id);
		if (sound != null) {
			level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.PLAYERS, volume, pitch);
		}
	}

	public static void igniteArea(ServerLevel level, Vec3 pos, double radius) {
		int steps = (int) Math.ceil(radius);
		for (int dx = -steps; dx <= steps; dx++) {
			for (int dz = -steps; dz <= steps; dz++) {
				if (dx * dx + dz * dz > radius * radius + 1.0) {
					continue;
				}
				if (level.getRandom().nextFloat() > 0.55F) {
					continue;
				}
				for (int dy = 1; dy >= -2; dy--) {
					BlockPos candidate = BlockPos.containing(pos.x + dx, pos.y + dy, pos.z + dz);
					BlockState below = level.getBlockState(candidate.below());
					if (level.getBlockState(candidate).isAir()
							&& below.isFaceSturdy(level, candidate.below(), Direction.UP)) {
						level.setBlock(candidate, BaseFireBlock.getState(level, candidate), 3);
						break;
					}
				}
			}
		}

		AABB area = new AABB(pos, pos).inflate(3.0);
		for (Entity entity : level.getEntities((Entity) null, area, e -> e instanceof LivingEntity)) {
			((LivingEntity) entity).igniteForSeconds(6.0F);
		}
	}
}
