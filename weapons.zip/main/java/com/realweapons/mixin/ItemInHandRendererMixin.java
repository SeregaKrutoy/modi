package com.realweapons.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.realweapons.client.FpState;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
	@Inject(method = "renderHandsWithItems", at = @At("HEAD"))
	private void realweapons$enterHands(float tickDelta, PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
			LocalPlayer player, int light, CallbackInfo callbackInfo) {
		FpState.enter();
	}

	@Inject(method = "renderHandsWithItems", at = @At("RETURN"))
	private void realweapons$exitHands(float tickDelta, PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
			LocalPlayer player, int light, CallbackInfo callbackInfo) {
		FpState.exit();
	}
}
