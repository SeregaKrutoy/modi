package com.realweapons;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FragGrenadeEntity extends BaseGrenadeEntity {
	public FragGrenadeEntity(EntityType<FragGrenadeEntity> entityType, Level level) {
		super(entityType, level);
	}

	public FragGrenadeEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.FRAG_GRENADE, owner, level, stack);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("frag_grenade");
	}

	@Override
	protected int fuseTicks() {
		return 50;
	}

	@Override
	protected boolean impactDetonates() {
		return false;
	}

	@Override
	protected void detonate(ServerLevel level) {
		WeaponFx.explosion(level, this.position(), 3.2F, this.getOwner());
		WeaponFx.playSound(level, this.position(), "explosion.grenade", 7.0F, 1.0F);
	}
}
