package com.realweapons;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class MolotovEntity extends BaseGrenadeEntity {
	public MolotovEntity(EntityType<MolotovEntity> entityType, Level level) {
		super(entityType, level);
	}

	public MolotovEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.MOLOTOV, owner, level, stack);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("molotov");
	}

	@Override
	protected int fuseTicks() {
		return 140;
	}

	@Override
	protected boolean impactDetonates() {
		return true;
	}

	@Override
	protected void detonate(ServerLevel level) {
		Vec3 pos = this.position();
		WeaponFx.playSound(level, pos, "glass.break", 2.5F, 1.0F);
		WeaponFx.playSound(level, pos, "fire.ignite", 3.5F, 1.0F);
		level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y + 0.2, pos.z, 14, 0.5, 0.4, 0.5, 0.06);
		level.sendParticles(ParticleTypes.LAVA, pos.x, pos.y + 0.2, pos.z, 6, 0.4, 0.3, 0.4, 0.0);
		WeaponFx.igniteArea(level, pos, 2.6);
	}

	@Override
	protected void clientFx() {
		this.level().addParticle(ParticleTypes.FLAME, this.getX(), this.getY() + 0.15, this.getZ(), 0.0, 0.01, 0.0);
		if (this.tickCount % 3 == 0) {
			this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.1, this.getZ(), 0.0, 0.02,
					0.0);
		}
	}
}
