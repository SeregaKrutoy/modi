package com.realweapons;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class WeaponSpecs {
	private static final List<WeaponSpec> ORDERED = List.of(
			WeaponSpec.gun("pistol", WeaponCategory.PISTOL, 5.5, 1, 5, 12, 30, false, 0.7, 0.40, 90.0, 0.10, 62, 1.25),
			WeaponSpec.gun("revolver", WeaponCategory.REVOLVER, 11.0, 1, 13, 6, 52, false, 0.45, 1.00, 110.0, 0.25, 58, 1.35),
			WeaponSpec.gun("double_barrel", WeaponCategory.SHOTGUN_DOUBLE, 6.0, 8, 14, 2, 40, false, 4.5, 1.20, 28.0, 0.50, 64, 1.50),
			WeaponSpec.gun("pump_shotgun", WeaponCategory.SHOTGUN_PUMP, 5.0, 8, 24, 6, 75, false, 4.2, 0.95, 30.0, 0.40, 64, 1.50),
			WeaponSpec.gun("combat_mg", WeaponCategory.MACHINE_GUN, 4.5, 1, 2, 50, 85, true, 1.6, 0.55, 105.0, 0.12, 62, 1.60),
			WeaponSpec.gun("assault_rifle", WeaponCategory.RIFLE, 5.5, 1, 3, 30, 55, true, 1.1, 0.45, 120.0, 0.12, 60, 1.70),
			WeaponSpec.gun("assault_sniper", WeaponCategory.SNIPER, 16.0, 1, 16, 10, 60, false, 0.25, 1.10, 170.0, 0.30, 38, 2.00),
			WeaponSpec.launcher("grenade_launcher", WeaponCategory.GRENADE_LAUNCHER, 20, 6, 70, 0.90, 60, 1.40, 0),
			WeaponSpec.launcher("rpg", WeaponCategory.RPG, 34, 1, 85, 1.50, 60, 2.20, 0),
			WeaponSpec.throwable("molotov", WeaponCategory.MOLOTOV, 16, 0.72, 0),
			WeaponSpec.throwable("flashbang", WeaponCategory.FLASHBANG, 18, 0.75, 50),
			WeaponSpec.throwable("frag_grenade", WeaponCategory.FRAG, 16, 0.78, 50),
			WeaponSpec.throwable("smoke_grenade", WeaponCategory.SMOKE, 16, 0.75, 40),
			WeaponSpec.knife("knife", 8.5, 3.0, 0.20)
	);

	private static final Map<String, WeaponSpec> BY_ID = new LinkedHashMap<>();

	static {
		for (WeaponSpec spec : ORDERED) {
			BY_ID.put(spec.id(), spec);
		}
	}

	private WeaponSpecs() {
	}

	public static List<WeaponSpec> all() {
		return ORDERED;
	}

	public static WeaponSpec byId(String id) {
		return BY_ID.get(id);
	}
}
