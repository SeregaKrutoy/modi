package com.realweapons;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SmokeGrenadeEntity extends BaseGrenadeEntity {
	public SmokeGrenadeEntity(EntityType<SmokeGrenadeEntity> entityType, Level level) {
		super(entityType, level);
	}

	public SmokeGrenadeEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.SMOKE_GRENADE, owner, level, stack);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("smoke_grenade");
	}

	@Override
	protected int fuseTicks() {
		return 30;
	}

	@Override
	protected boolean impactDetonates() {
		return false;
	}

	@Override
	protected void detonate(ServerLevel level) {
		ServerState.addCloud(new SmokeCloud(level, this.position(), 280));
		level.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.2, this.getZ(), 12, 0.4, 0.3, 0.4,
				0.02);
	}
}
