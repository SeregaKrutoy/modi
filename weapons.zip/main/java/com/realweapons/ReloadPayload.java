package com.realweapons;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record ReloadPayload() implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ReloadPayload> TYPE =
			new CustomPacketPayload.Type<>(RealWeaponsMod.id("reload"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ReloadPayload> CODEC = StreamCodec.unit(new ReloadPayload());

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
