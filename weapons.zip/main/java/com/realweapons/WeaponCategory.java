package com.realweapons;

public enum WeaponCategory {
	PISTOL,
	REVOLVER,
	SHOTGUN_DOUBLE,
	SHOTGUN_PUMP,
	MACHINE_GUN,
	RIFLE,
	SNIPER,
	GRENADE_LAUNCHER,
	RPG,
	MOLOTOV,
	FLASHBANG,
	FRAG,
	SMOKE,
	KNIFE;

	public boolean isFirearm() {
		return this == PISTOL || this == REVOLVER || this == SHOTGUN_DOUBLE || this == SHOTGUN_PUMP
				|| this == MACHINE_GUN || this == RIFLE || this == SNIPER;
	}

	public boolean isLauncher() {
		return this == GRENADE_LAUNCHER || this == RPG;
	}

	public boolean isThrowable() {
		return this == MOLOTOV || this == FLASHBANG || this == FRAG || this == SMOKE;
	}

	public boolean usesAds() {
		return this.isFirearm() || this.isLauncher();
	}
}
