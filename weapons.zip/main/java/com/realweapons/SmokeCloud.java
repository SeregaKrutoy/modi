package com.realweapons;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

public final class SmokeCloud {
	private final ServerLevel level;
	private final Vec3 pos;
	private final int life;
	private int age;

	public SmokeCloud(ServerLevel level, Vec3 pos, int life) {
		this.level = level;
		this.pos = pos;
		this.life = life;
	}

	public boolean tick() {
		this.age++;
		if (this.age > this.life) {
			return false;
		}

		if (this.age == 1) {
			SoundEvent sound = ModContent.sound("smoke.pop");
			if (sound != null) {
				this.level.playSound(null, this.pos.x, this.pos.y, this.pos.z, sound, SoundSource.PLAYERS, 1.8F, 1.0F);
			}
		}

		if (this.age % 2 == 0) {
			RandomSource random = this.level.getRandom();
			double grow = Math.min(1.0, this.age / 18.0);
			double radius = 1.2 + 2.0 * grow;

			for (int i = 0; i < 3; i++) {
				double x = this.pos.x + (random.nextDouble() - 0.5) * 2.0 * radius;
				double y = this.pos.y + 0.25 + random.nextDouble() * (1.3 + radius * 0.4);
				double z = this.pos.z + (random.nextDouble() - 0.5) * 2.0 * radius;
				this.level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 1, 0.22, 0.18, 0.22, 0.01);
			}

			double x = this.pos.x + (random.nextDouble() - 0.5) * 1.4;
			double y = this.pos.y + 0.4 + random.nextDouble() * 1.2;
			double z = this.pos.z + (random.nextDouble() - 0.5) * 1.4;
			this.level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, 1, 0.4, 0.25, 0.4, 0.005);
		}

		return true;
	}
}
