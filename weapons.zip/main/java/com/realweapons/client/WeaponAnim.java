package com.realweapons.client;

import java.util.HashMap;
import java.util.Map;

import com.realweapons.HitMarkerPayload;
import com.realweapons.ModContent;
import com.realweapons.WeaponCategory;
import com.realweapons.WeaponItem;
import com.realweapons.WeaponSpec;
import com.realweapons.WeaponSpecs;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;

public final class WeaponAnim {
	public static final float NO_TIME = 999.0F;

	private static final State LOCAL = new State(true);
	private static final State IDLE = new State(false);
	private static final Map<Integer, Remote> REMOTE = new HashMap<>();

	private static String localWeapon;
	private static boolean aiming;
	private static float hitT = NO_TIME;
	private static boolean hitHead;
	private static float equipT = NO_TIME;

	private static final String[][] SCHED_EMPTY = new String[0][];
	private static final String[][] SCHED_PISTOL = {
			{ "0.08", "reload.mag_out" }, { "0.5", "reload.mag_in" }, { "0.64", "reload.rack" } };
	private static final String[][] SCHED_REVOLVER = {
			{ "0.1", "reload.cylinder" }, { "0.32", "reload.cylinder" }, { "0.45", "reload.shell" },
			{ "0.55", "reload.shell" }, { "0.65", "reload.shell" }, { "0.78", "reload.cylinder" },
			{ "0.9", "reload.rack" } };
	private static final String[][] SCHED_DOUBLE = {
			{ "0.16", "reload.break_open" }, { "0.5", "reload.shell" }, { "0.58", "reload.shell" },
			{ "0.8", "reload.break_close" } };
	private static final String[][] SCHED_PUMP = {
			{ "0.18", "reload.shell" }, { "0.332", "reload.shell" }, { "0.484", "reload.shell" },
			{ "0.636", "reload.shell" }, { "0.788", "reload.shell" }, { "0.92", "reload.pump" } };
	private static final String[][] SCHED_MG = {
			{ "0.06", "reload.belt" }, { "0.5", "reload.belt" }, { "0.88", "reload.rack" } };
	private static final String[][] SCHED_RIFLE = {
			{ "0.08", "reload.mag_out" }, { "0.5", "reload.mag_in" }, { "0.8", "reload.rack" } };
	private static final String[][] SCHED_SNIPER = {
			{ "0.1", "reload.mag_out" }, { "0.52", "reload.mag_in" }, { "0.76", "reload.rack" } };
	private static final String[][] SCHED_GL = {
			{ "0.14", "reload.break_open" }, { "0.55", "reload.shell" }, { "0.78", "reload.break_close" } };
	private static final String[][] SCHED_RPG = {
			{ "0.12", "reload.rocket" }, { "0.68", "reload.rack" }, { "0.84", "reload.rack" } };

	private static final float[] SWING_NONE = new float[0];
	private static final float[] SWING_PISTOL = { 0.08F, 0.5F };
	private static final float[] SWING_REVOLVER = { 0.1F, 0.45F, 0.78F };
	private static final float[] SWING_DOUBLE = { 0.16F, 0.5F, 0.8F };
	private static final float[] SWING_PUMP = { 0.18F, 0.484F, 0.788F, 0.92F };
	private static final float[] SWING_MG = { 0.06F, 0.5F, 0.88F };
	private static final float[] SWING_RIFLE = { 0.08F, 0.5F, 0.8F };
	private static final float[] SWING_SNIPER = { 0.1F, 0.52F, 0.76F };
	private static final float[] SWING_GL = { 0.14F, 0.55F, 0.78F };
	private static final float[] SWING_RPG = { 0.12F, 0.68F, 0.84F };

	private record FireParams(float kickZ, float kickY, float kickR, float recover) {
	}

	private static final FireParams PARAMS_DEFAULT = new FireParams(0.9F, 0.25F, 5.0F, 5.0F);

	public static final class State {
		public final boolean local;
		public WeaponCategory category;
		public float fireT = NO_TIME;
		public float reloadT = -1.0F;
		public float pumpT = NO_TIME;
		public float boltT = NO_TIME;
		public float throwT = NO_TIME;
		public float dryT = NO_TIME;
		public float ads;
		public int shots;
		public int dur;
		public int soundStep;
		public int swingStep;

		State(boolean local) {
			this.local = local;
		}
	}

	private record Remote(String weapon, State state) {
	}

	public record PartPose(float[] t, float[] r, boolean hidden) {
	}

	public record Frame(float[] gunT, float[] gunR, float flash, float flashRoll, float flashX, float sightGlow,
			Map<String, PartPose> parts) {
	}

	private static final Frame EMPTY = new Frame(new float[3], new float[3], 0.0F, 0.0F, 0.0F, 0.0F, Map.of());

	private WeaponAnim() {
	}

	public static boolean isAiming() {
		return aiming;
	}

	public static void setAiming(boolean value) {
		aiming = value;
	}

	public static boolean reloading() {
		return LOCAL.reloadT >= 0.0F;
	}

	public static float reloadProgress() {
		return LOCAL.reloadT < 0.0F || LOCAL.dur <= 0 ? -1.0F : Mth.clamp(LOCAL.reloadT / LOCAL.dur, 0.0F, 1.0F);
	}

	public static float reloadSmooth() {
		if (LOCAL.reloadT < 0.0F || LOCAL.dur <= 0) {
			return -1.0F;
		}
		return Mth.clamp((LOCAL.reloadT - partialTick()) / LOCAL.dur, 0.0F, 1.0F);
	}

	public static float adsBlend() {
		return LOCAL.ads;
	}

	public static float dryAge() {
		return LOCAL.dryT;
	}

	public static float hitMarker() {
		return hitT;
	}

	public static boolean hitWasHead() {
		return hitHead;
	}

	public static String localWeapon() {
		return localWeapon;
	}

	public static void tick(Minecraft minecraft) {
		LocalPlayer player = minecraft.player;
		String held = player == null ? null : heldWeapon(player);
		if (held == null) {
			if (localWeapon != null) {
				reset(LOCAL);
				aiming = false;
			}
			localWeapon = null;
			equipT = NO_TIME;
		} else {
			if (!held.equals(localWeapon)) {
				reset(LOCAL);
				localWeapon = held;
				aiming = false;
				equipT = 0.0F;
			}
			float target = aiming ? 1.0F : 0.0F;
			LOCAL.ads += Mth.clamp(target - LOCAL.ads, -0.22F, 0.22F);
			advance(LOCAL);
			tickLocal(player);
		}
		tickEquip(minecraft);
		hitT = Math.min(NO_TIME, hitT + 1.0F);

		var iterator = REMOTE.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<Integer, Remote> entry = iterator.next();
			State state = entry.getValue().state();
			advance(state);
			tickRemote(minecraft, entry.getKey(), state);
			if (state.fireT > 300.0F && state.reloadT < 0.0F && state.throwT > 300.0F) {
				iterator.remove();
			}
		}
	}

	private static void tickEquip(Minecraft minecraft) {
		if (equipT >= NO_TIME) {
			return;
		}
		equipT += 1.0F;
		if (equipT < 3.0F) {
			return;
		}
		equipT = NO_TIME;
		LocalPlayer player = minecraft.player;
		WeaponSpec spec = localWeapon == null ? null : WeaponSpecs.byId(localWeapon);
		if (player != null && spec != null && spec.category().usesAds()) {
			swingOff(player);
		}
	}

	private static String heldWeapon(Player player) {
		if (player.getMainHandItem().getItem() instanceof WeaponItem weapon) {
			return weapon.spec().id();
		}
		return null;
	}

	private static void reset(State state) {
		state.category = null;
		state.fireT = NO_TIME;
		state.reloadT = -1.0F;
		state.pumpT = NO_TIME;
		state.boltT = NO_TIME;
		state.throwT = NO_TIME;
		state.dryT = NO_TIME;
		state.ads = 0.0F;
		state.shots = 0;
		state.dur = 0;
		state.soundStep = 0;
		state.swingStep = 0;
	}

	private static void advance(State state) {
		state.fireT = Math.min(NO_TIME, state.fireT + 1.0F);
		state.pumpT = Math.min(NO_TIME, state.pumpT + 1.0F);
		state.boltT = Math.min(NO_TIME, state.boltT + 1.0F);
		state.throwT = Math.min(NO_TIME, state.throwT + 1.0F);
		state.dryT = Math.min(NO_TIME, state.dryT + 1.0F);
		if (state.reloadT >= 0.0F) {
			state.reloadT += 1.0F;
			if (state.dur > 0 && state.reloadT > state.dur + 2.0F) {
				state.reloadT = -1.0F;
			}
		}
	}

	public static void onLocalFire(WeaponSpec spec) {
		LOCAL.category = spec.category();
		LOCAL.fireT = 0.0F;
		LOCAL.shots++;
		LOCAL.dryT = NO_TIME;
		afterShot(LOCAL, spec.category());
	}

	public static void onLocalDry() {
		LOCAL.dryT = 0.0F;
	}

	public static void onLocalReload(WeaponSpec spec) {
		LOCAL.category = spec.category();
		LOCAL.reloadT = 0.0F;
		LOCAL.dur = spec.reloadTicks();
		LOCAL.soundStep = 0;
		LOCAL.swingStep = 0;
	}

	public static void onLocalReloadEnd() {
		if (LOCAL.reloadT >= 0.0F && LOCAL.dur > 0) {
			LOCAL.reloadT = LOCAL.dur;
		}
	}

	public static void cancelLocalReload() {
		LOCAL.reloadT = -1.0F;
	}

	public static void onLocalThrow(WeaponSpec spec) {
		LOCAL.category = spec.category();
		LOCAL.throwT = 0.0F;
	}

	public static void onHit(HitMarkerPayload payload) {
		hitT = 0.0F;
		hitHead = payload.headshot();
	}

	private static void afterShot(State state, WeaponCategory category) {
		if (category == WeaponCategory.SHOTGUN_PUMP) {
			state.pumpT = 0.0F;
		}
		if (category == WeaponCategory.SNIPER || category == WeaponCategory.MACHINE_GUN
				|| category == WeaponCategory.RIFLE) {
			state.boltT = 0.0F;
		}
	}

	public static void onRemoteEvent(int entityId, int event, String weapon) {
		WeaponSpec spec = WeaponSpecs.byId(weapon);
		if (spec == null) {
			return;
		}
		Remote remote = REMOTE.computeIfAbsent(entityId, id -> new Remote(weapon, new State(false)));
		State state = remote.state();
		state.category = spec.category();
		switch (event) {
			case 0 -> {
				state.fireT = 0.0F;
				state.shots++;
				state.dryT = NO_TIME;
				afterShot(state, spec.category());
			}
			case 1 -> {
				state.reloadT = 0.0F;
				state.dur = spec.reloadTicks();
				state.soundStep = 0;
				state.swingStep = 0;
			}
			case 2 -> {
				state.dur = spec.reloadTicks();
				state.reloadT = spec.reloadTicks();
			}
			case 3 -> state.throwT = 0.0F;
			default -> {
			}
		}
	}

	private static void tickLocal(Player player) {
		if (player == null) {
			return;
		}
		if (LOCAL.pumpT == 4.0F) {
			playAt(player.getX(), player.getY(), player.getZ(), "reload.pump", 0.8F, 1.0F);
			swingOff(player);
		}
		if (LOCAL.boltT == 3.0F && LOCAL.category == WeaponCategory.SNIPER) {
			playAt(player.getX(), player.getY(), player.getZ(), "reload.rack", 0.8F, 1.05F);
		}
		if (LOCAL.boltT == 1.0F && (LOCAL.category == WeaponCategory.RIFLE || LOCAL.category == WeaponCategory.MACHINE_GUN)) {
			playAt(player.getX(), player.getY(), player.getZ(), "reload.rack", 0.22F, 1.4F);
		}
		tickSchedule(player, LOCAL);
	}

	private static void tickRemote(Minecraft minecraft, int entityId, State state) {
		Entity entity = minecraft.level == null ? null : minecraft.level.getEntity(entityId);
		if (entity == null) {
			return;
		}
		if (state.pumpT == 4.0F) {
			playAt(entity.getX(), entity.getY(), entity.getZ(), "reload.pump", 0.8F, 1.0F);
			swingOff(entity);
		}
		if (state.boltT == 3.0F && state.category == WeaponCategory.SNIPER) {
			playAt(entity.getX(), entity.getY(), entity.getZ(), "reload.rack", 0.8F, 1.05F);
		}
		tickSchedule(entity, state);
	}

	private static void tickSchedule(Entity entity, State state) {
		if (state.reloadT < 0.0F || state.dur <= 0) {
			state.soundStep = 0;
			state.swingStep = 0;
			return;
		}
		float progress = state.reloadT / state.dur;
		String[][] schedule = scheduleFor(state.category);
		while (state.soundStep < schedule.length && progress >= Float.parseFloat(schedule[state.soundStep][0])) {
			playAt(entity.getX(), entity.getY(), entity.getZ(), schedule[state.soundStep][1], 0.9F, 1.0F);
			state.soundStep++;
		}
		float[] swings = swingScheduleFor(state.category);
		while (state.swingStep < swings.length && progress >= swings[state.swingStep]) {
			swingOff(entity);
			state.swingStep++;
		}
	}

	private static float[] swingScheduleFor(WeaponCategory category) {
		if (category == null) {
			return SWING_NONE;
		}
		return switch (category) {
			case PISTOL -> SWING_PISTOL;
			case REVOLVER -> SWING_REVOLVER;
			case SHOTGUN_DOUBLE -> SWING_DOUBLE;
			case SHOTGUN_PUMP -> SWING_PUMP;
			case MACHINE_GUN -> SWING_MG;
			case RIFLE -> SWING_RIFLE;
			case SNIPER -> SWING_SNIPER;
			case GRENADE_LAUNCHER -> SWING_GL;
			case RPG -> SWING_RPG;
			default -> SWING_NONE;
		};
	}

	private static void swingOff(Entity entity) {
		if (entity instanceof LivingEntity living) {
			living.swing(InteractionHand.OFF_HAND);
		}
	}

	private static void playAt(double x, double y, double z, String id, float volume, float pitch) {
		SoundEvent sound = ModContent.sound(id);
		Minecraft minecraft = Minecraft.getInstance();
		if (sound != null && minecraft.level != null) {
			minecraft.level.playLocalSound(x, y, z, sound, SoundSource.PLAYERS, volume, pitch, false);
		}
	}

	public static void playLocal(String id, float volume, float pitch) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.player != null) {
			playAt(minecraft.player.getX(), minecraft.player.getY(), minecraft.player.getZ(), id, volume, pitch);
		}
	}

	private static String[][] scheduleFor(WeaponCategory category) {
		if (category == null) {
			return SCHED_EMPTY;
		}
		return switch (category) {
			case PISTOL -> SCHED_PISTOL;
			case REVOLVER -> SCHED_REVOLVER;
			case SHOTGUN_DOUBLE -> SCHED_DOUBLE;
			case SHOTGUN_PUMP -> SCHED_PUMP;
			case MACHINE_GUN -> SCHED_MG;
			case RIFLE -> SCHED_RIFLE;
			case SNIPER -> SCHED_SNIPER;
			case GRENADE_LAUNCHER -> SCHED_GL;
			case RPG -> SCHED_RPG;
			default -> SCHED_EMPTY;
		};
	}

	private static FireParams params(WeaponCategory category) {
		if (category == null) {
			return PARAMS_DEFAULT;
		}
		return switch (category) {
			case PISTOL -> new FireParams(1.0F, 0.28F, 7.0F, 5.0F);
			case REVOLVER -> new FireParams(1.3F, 0.42F, 11.0F, 6.0F);
			case SHOTGUN_DOUBLE -> new FireParams(1.9F, 0.55F, 14.0F, 7.0F);
			case SHOTGUN_PUMP -> new FireParams(1.5F, 0.45F, 11.0F, 6.0F);
			case MACHINE_GUN -> new FireParams(0.8F, 0.22F, 4.5F, 4.0F);
			case RIFLE -> new FireParams(1.0F, 0.28F, 6.0F, 5.0F);
			case SNIPER -> new FireParams(1.9F, 0.55F, 13.0F, 9.0F);
			case GRENADE_LAUNCHER -> new FireParams(1.3F, 0.35F, 9.0F, 7.0F);
			case RPG -> new FireParams(2.2F, 0.65F, 7.0F, 9.0F);
			case KNIFE -> new FireParams(-1.1F, 0.1F, -6.0F, 4.0F);
			default -> PARAMS_DEFAULT;
		};
	}

	private static float partialTick() {
		return Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
	}

	public static Frame frame(String weapon, Entity owner, ItemDisplayContext ctx, WeaponModel model) {
		State state = pickState(owner, ctx);
		if (state == null || state.category == null) {
			return EMPTY;
		}
		return compute(state, partialTick(), model);
	}

	private static State pickState(Entity owner, ItemDisplayContext ctx) {
		Minecraft minecraft = Minecraft.getInstance();
		if (ctx.firstPerson()) {
			return LOCAL;
		}
		if (owner == null) {
			return IDLE;
		}
		if (owner == minecraft.player) {
			return LOCAL;
		}
		Remote remote = REMOTE.get(owner.getId());
		return remote == null ? IDLE : remote.state();
	}

	private static float seg(float t, float a, float b) {
		return Mth.clamp((t - a) / (b - a), 0.0F, 1.0F);
	}

	private static float ease(float t) {
		float x = Mth.clamp(t, 0.0F, 1.0F);
		return 1.0F - (1.0F - x) * (1.0F - x);
	}

	private static float lerp(float a, float b, float t) {
		return a + (b - a) * t;
	}

	private static void put(Map<String, PartPose> parts, String name, float tx, float ty, float tz, float rx, float ry,
			float rz, boolean hidden) {
		parts.put(name, new PartPose(new float[] { tx, ty, tz }, new float[] { rx, ry, rz }, hidden));
	}

	private static Frame compute(State state, float partial, WeaponModel model) {
		float[] gunT = new float[3];
		float[] gunR = new float[3];
		Map<String, PartPose> parts = new HashMap<>();
		float flash = 0.0F;
		float flashRoll = 0.0F;
		float flashX = 0.0F;
		WeaponCategory cat = state.category;

		float fireT = Math.max(0.0F, state.fireT - partial);
		float reloadT = state.reloadT - partial;
		float progress = -1.0F;

		FireParams fp = params(cat);
		if (state.fireT < NO_TIME) {
			float r = 1.0F - ease(seg(fireT, 0.0F, fp.recover()));
			gunT[1] += fp.kickY() * r;
			gunT[2] += fp.kickZ() * r;
			gunR[0] += fp.kickR() * r;
			if (cat == WeaponCategory.MACHINE_GUN && r > 0.01F) {
				gunT[0] += Mth.sin((fireT + state.shots) * 1.7F) * 0.22F * r;
				gunR[2] += Mth.sin(fireT * 2.1F) * 1.4F * r;
			}
			if (cat.isFirearm() || cat.isLauncher()) {
				flash = Math.max(0.0F, 1.0F - seg(fireT, 0.0F, 2.4F));
				flashRoll = state.shots * 47.0F;
				if (cat == WeaponCategory.SHOTGUN_DOUBLE) {
					flashX = (state.shots % 2 == 0) ? -0.75F : 0.75F;
				}
			}
		}

		float throwT = Math.max(0.0F, state.throwT - partial);
		if (state.throwT < NO_TIME) {
			float t1 = 1.0F - ease(seg(throwT, 0.0F, 3.5F));
			gunR[0] -= 16.0F * t1;
			gunT[1] += 0.4F * t1;
		}

		if (state.reloadT >= 0.0F && state.dur > 0) {
			progress = Mth.clamp(reloadT / state.dur, 0.0F, 1.0F);
			reload(state, cat, progress, parts, gunT, gunR);
		}

		float[] adsT = state.local ? model.adsTranslate() : null;
		float[] adsR = state.local ? model.adsRotate() : null;
		if (adsT != null && state.ads > 0.001F) {
			gunT[0] += adsT[0] * state.ads;
			gunT[1] += adsT[1] * state.ads;
			gunT[2] += adsT[2] * state.ads;
			gunR[0] += adsR[0] * state.ads;
			gunR[1] += adsR[1] * state.ads;
			gunR[2] += adsR[2] * state.ads;
		}

		if (state.local && state.ads < 0.5F && state.fireT > 2.0F && state.reloadT < 0.0F) {
			Minecraft minecraft = Minecraft.getInstance();
			float time = (minecraft.player == null ? 0.0F : minecraft.player.tickCount) + partial;
			gunT[0] += Mth.sin(time * 0.09F) * 0.045F;
			gunT[1] += Mth.sin(time * 0.14F + 1.3F) * 0.06F;
			gunR[2] += Mth.sin(time * 0.11F + 0.4F) * 0.4F;
		}

		float sightGlow = 0.3F + 0.6F * state.ads;
		return new Frame(gunT, gunR, flash, flashRoll, flashX, sightGlow, parts);
	}

	private static void reload(State state, WeaponCategory cat, float p, Map<String, PartPose> parts, float[] gunT,
			float[] gunR) {
		switch (cat) {
			case PISTOL -> {
				float dip = ease(seg(p, 0.0F, 0.12F)) * (1.0F - ease(seg(p, 0.8F, 1.0F)));
				gunR[2] -= 18.0F * dip;
				gunR[0] += 7.0F * dip;
				gunT[1] -= 1.1F * dip;
				float magY = p < 0.34F ? 5.0F * ease(seg(p, 0.1F, 0.2F)) : 5.0F * (1.0F - ease(seg(p, 0.34F, 0.4F)));
				put(parts, "mag", 0.0F, -magY, 0.0F, 0.0F, 0.0F, 0.0F, p > 0.19F && p < 0.4F);
				float rack = ease(seg(p, 0.55F, 0.63F)) * (1.0F - ease(seg(p, 0.63F, 0.75F)));
				if (rack > 0.001F) {
					put(parts, "slide", 0.0F, 0.0F, 1.8F * rack, 0.0F, 0.0F, 0.0F, false);
				}
			}
			case REVOLVER -> {
				float roll = ease(seg(p, 0.0F, 0.14F)) * (1.0F - ease(seg(p, 0.84F, 1.0F)));
				gunR[2] -= 68.0F * roll;
				gunR[1] -= 18.0F * roll;
				gunR[0] += 8.0F * roll;
				gunT[1] -= 0.8F * roll;
				gunT[2] += 0.4F * roll;
				float swing = ease(seg(p, 0.16F, 0.28F)) * (1.0F - ease(seg(p, 0.72F, 0.84F)));
				float spin = Math.max(0.0F, p - 0.3F) * (1.0F - ease(seg(p, 0.7F, 0.8F)));
				put(parts, "cylinder", -1.6F * swing, 0.0F, 0.0F, 0.0F, 24.0F * swing, 480.0F * spin, false);
				float cock = ease(seg(p, 0.85F, 1.0F));
				put(parts, "hammer", 0.0F, 0.0F, 0.0F, 26.0F * cock, 0.0F, 0.0F, false);
			}
			case SHOTGUN_DOUBLE -> {
				float tilt = ease(seg(p, 0.0F, 0.16F)) * (1.0F - ease(seg(p, 0.8F, 1.0F)));
				gunR[0] += 30.0F * tilt;
				gunT[1] -= 1.3F * tilt;
				gunT[2] += 0.6F * tilt;
				float open = ease(seg(p, 0.18F, 0.34F)) * (1.0F - ease(seg(p, 0.7F, 0.82F)));
				put(parts, "barrel", 0.0F, 0.0F, 0.0F, -30.0F * open, 0.0F, 0.0F, false);
				float shellIn = ease(seg(p, 0.5F, 0.66F));
				float shellOut = ease(seg(p, 0.4F, 0.46F));
				float shellY = p < 0.5F ? 1.6F * shellOut : lerp(4.0F, 0.0F, shellIn);
				boolean shellHidden = p > 0.44F && p < 0.52F;
				put(parts, "shell1", -1.1F, shellY, 0.0F, 0.0F, 0.0F, 0.0F, shellHidden);
				put(parts, "shell2", 1.1F, shellY, 0.0F, 0.0F, 0.0F, 0.0F, shellHidden);
				float cock = ease(seg(p, 0.82F, 1.0F));
				put(parts, "hammer", 0.0F, 0.0F, 0.0F, 26.0F * cock, 0.0F, 0.0F, false);
			}
			case SHOTGUN_PUMP -> {
				float tilt = ease(seg(p, 0.0F, 0.08F)) * (1.0F - ease(seg(p, 0.92F, 1.0F)));
				gunR[0] += 13.0F * tilt;
				gunR[2] -= 6.0F * tilt;
				gunT[1] -= 0.6F * tilt;
				float cycle = seg(p, 0.12F, 0.88F) * 5.0F;
				float u = cycle - (float) Math.floor(Math.min(cycle, 4.999F));
				float pumpZ = 3.0F * Mth.sin(u * (float) Math.PI);
				put(parts, "pump", 0.0F, 0.0F, pumpZ, 0.0F, 0.0F, 0.0F, false);
				boolean shellOn = u > 0.08F && u < 0.45F && p < 0.9F;
				put(parts, "shell1", 0.0F, lerp(0.0F, 3.0F, Mth.clamp(u * 2.2F, 0.0F, 1.0F)), 0.0F, 0.0F, 0.0F, 0.0F,
						!shellOn);
				put(parts, "hammer", 0.0F, 0.0F, 0.0F, 20.0F * ease(seg(p, 0.9F, 1.0F)), 0.0F, 0.0F, false);
			}
			case MACHINE_GUN -> {
				float tilt = ease(seg(p, 0.0F, 0.1F)) * (1.0F - ease(seg(p, 0.86F, 1.0F)));
				gunR[2] -= 10.0F * tilt;
				gunR[0] += 10.0F * tilt;
				gunT[1] -= 1.0F * tilt;
				float open = ease(seg(p, 0.08F, 0.24F)) * (1.0F - ease(seg(p, 0.72F, 0.86F)));
				put(parts, "cover", 0.0F, 0.0F, 0.0F, 75.0F * open, 0.0F, 0.0F, false);
				float beltIn = ease(seg(p, 0.44F, 0.46F));
				float beltY = p < 0.44F ? 5.0F * ease(seg(p, 0.1F, 0.24F)) : lerp(5.0F, 0.0F, beltIn);
				put(parts, "belt", 0.0F, -beltY, 0.0F, 0.0F, 0.0F, 0.0F, p > 0.26F && p < 0.46F);
				float rack = ease(seg(p, 0.86F, 0.92F)) * (1.0F - ease(seg(p, 0.92F, 0.98F)));
				put(parts, "bolt", 0.0F, 0.0F, 2.6F * rack, 0.0F, 0.0F, 0.0F, false);
			}
			case RIFLE -> {
				float dip = ease(seg(p, 0.0F, 0.1F)) * (1.0F - ease(seg(p, 0.86F, 1.0F)));
				gunR[2] -= 15.0F * dip;
				gunR[0] += 6.0F * dip;
				gunT[1] -= 1.0F * dip;
				float magY = p < 0.4F ? 5.5F * ease(seg(p, 0.12F, 0.24F)) : 5.5F * (1.0F - ease(seg(p, 0.4F, 0.44F)));
				put(parts, "mag", 0.0F, -magY, 0.0F, 0.0F, 0.0F, 0.0F, p > 0.22F && p < 0.44F);
				float rack = ease(seg(p, 0.72F, 0.8F)) * (1.0F - ease(seg(p, 0.8F, 0.92F)));
				put(parts, "bolt", 0.0F, 0.0F, 2.4F * rack, 0.0F, 0.0F, 0.0F, false);
			}
			case SNIPER -> {
				float dip = ease(seg(p, 0.0F, 0.1F)) * (1.0F - ease(seg(p, 0.86F, 1.0F)));
				gunR[2] -= 14.0F * dip;
				gunR[0] += 5.0F * dip;
				gunT[1] -= 1.0F * dip;
				float magY = p < 0.42F ? 6.0F * ease(seg(p, 0.12F, 0.24F)) : 6.0F * (1.0F - ease(seg(p, 0.42F, 0.46F)));
				put(parts, "mag", 0.0F, -magY, 0.0F, 0.0F, 0.0F, 0.0F, p > 0.22F && p < 0.46F);
				float bt = seg(p, 0.68F, 0.92F) * 10.0F;
				float handle = 55.0F * ease(seg(bt, 0.0F, 2.5F)) - 55.0F * ease(seg(bt, 8.5F, 10.0F));
				float back = 3.2F * ease(seg(bt, 3.0F, 6.0F)) - 3.2F * ease(seg(bt, 6.0F, 8.5F));
				put(parts, "bolt", 0.0F, 0.0F, back, 0.0F, 0.0F, handle, false);
			}
			case GRENADE_LAUNCHER -> {
				float tilt = ease(seg(p, 0.0F, 0.12F)) * (1.0F - ease(seg(p, 0.82F, 1.0F)));
				gunR[0] += 26.0F * tilt;
				gunT[1] -= 1.0F * tilt;
				float open = ease(seg(p, 0.16F, 0.3F)) * (1.0F - ease(seg(p, 0.68F, 0.8F)));
				put(parts, "barrel", 0.0F, 0.0F, 0.0F, -26.0F * open, 0.0F, 0.0F, false);
				float shellIn = ease(seg(p, 0.5F, 0.64F));
				put(parts, "grenade", 0.0F, lerp(4.0F, 0.0F, shellIn), lerp(-1.5F, 0.0F, shellIn), 0.0F, 0.0F, 0.0F,
						p > 0.3F && p < 0.42F);
			}
			case RPG -> {
				float tilt = ease(seg(p, 0.0F, 0.14F)) * (1.0F - ease(seg(p, 0.82F, 1.0F)));
				gunR[0] += 18.0F * tilt;
				gunT[1] -= 1.2F * tilt;
				float load = ease(seg(p, 0.15F, 0.62F));
				put(parts, "rocket", 0.0F, 0.0F, lerp(-6.0F, 0.0F, load), 0.0F, 0.0F, 0.0F, p < 0.12F);
				float cover = ease(seg(p, 0.55F, 0.68F)) * (1.0F - ease(seg(p, 0.75F, 0.88F)));
				put(parts, "cover", 0.0F, 0.0F, 0.0F, -35.0F * cover, 0.0F, 0.0F, false);
			}
			default -> {
			}
		}
	}
}
