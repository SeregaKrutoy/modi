package com.realweapons.client;

import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.realweapons.client.WeaponAnim.PartPose;
import com.realweapons.RealWeaponsMod;
import com.realweapons.WeaponCategory;
import com.realweapons.WeaponSpec;
import com.realweapons.WeaponSpecs;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

public final class GunRenderer implements SpecialModelRenderer<GunRenderer.RenderData> {
	public static final GunRenderer INSTANCE = new GunRenderer();
	private static final Identifier FLASH_TEXTURE = RealWeaponsMod.id("textures/entity/weapon/flash.png");
	private static final Identifier DOT_TEXTURE = RealWeaponsMod.id("textures/entity/weapon/dot.png");
	private static final RenderType FLASH_LAYER = RenderTypes.entityTranslucentEmissive(FLASH_TEXTURE);
	private static final RenderType DOT_LAYER = RenderTypes.entityTranslucentEmissive(DOT_TEXTURE);

	public record RenderData(String weapon, @Nullable Entity owner, ItemDisplayContext context) {
	}

	private GunRenderer() {
	}

	@Nullable
	@Override
	public RenderData extractArgument(ItemStack itemStack) {
		return null;
	}

	@Override
	public void getExtents(Consumer<Vector3fc> consumer) {
		consumer.accept(new Vector3f(-0.6F, -0.6F, -0.6F));
		consumer.accept(new Vector3f(0.6F, 0.6F, 0.6F));
	}

	@Override
	public void submit(@Nullable RenderData data, ItemDisplayContext itemDisplayContext, PoseStack poseStack,
			SubmitNodeCollector submitNodeCollector, int light, int overlay, boolean foil, int outline) {
		if (data == null) {
			return;
		}
		WeaponModel model = WeaponModel.get(data.weapon());
		if (model == null) {
			return;
		}
		ItemDisplayContext context = data.context();
		if (context.firstPerson() && model.scope() > 0.0F && WeaponAnim.adsBlend() >= 0.6F) {
			return;
		}
		WeaponAnim.Frame frame = WeaponAnim.frame(data.weapon(), data.owner(), context, model);
		boolean left = context.leftHand();
		float[] gunT = frame.gunT();
		float[] gunR = frame.gunR();
		poseStack.pushPose();
		levelThirdPerson(context, poseStack, data.weapon());
		poseStack.translate((left ? -gunT[0] : gunT[0]) / 16.0F, gunT[1] / 16.0F, gunT[2] / 16.0F);
		poseStack.mulPose(new Quaternionf().rotationXYZ(gunR[0] * Mth.DEG_TO_RAD,
				(left ? -gunR[1] : gunR[1]) * Mth.DEG_TO_RAD, (left ? -gunR[2] : gunR[2]) * Mth.DEG_TO_RAD));

		submitNodeCollector.submitCustomGeometry(poseStack, model.solidLayer(), (pose, vertexConsumer) ->
				emitParts(vertexConsumer, pose.pose(), model, frame, light, overlay, WeaponModel.MAT_SOLID, left));
		submitNodeCollector.submitCustomGeometry(poseStack, model.glassLayer(), (pose, vertexConsumer) ->
				emitParts(vertexConsumer, pose.pose(), model, frame, light, overlay, WeaponModel.MAT_GLASS, left));
		submitNodeCollector.submitCustomGeometry(poseStack, model.glowLayer(), (pose, vertexConsumer) ->
				emitParts(vertexConsumer, pose.pose(), model, frame, light, overlay, WeaponModel.MAT_GLOW, left));
		submitNodeCollector.submitCustomGeometry(poseStack, FLASH_LAYER, (pose, vertexConsumer) ->
				emitFlash(vertexConsumer, pose.pose(), model, frame));
		submitNodeCollector.submitCustomGeometry(poseStack, DOT_LAYER, (pose, vertexConsumer) ->
				emitSight(vertexConsumer, pose.pose(), model, frame));
		if (context.firstPerson()) {
			FpHands.submit(frame, data.weapon(), model, poseStack, submitNodeCollector, light, overlay, left);
		}

		poseStack.popPose();
	}

	private static void levelThirdPerson(ItemDisplayContext context, PoseStack poseStack, String weapon) {
		if (context != ItemDisplayContext.THIRD_PERSON_LEFT_HAND
				&& context != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND) {
			return;
		}
		WeaponSpec spec = WeaponSpecs.byId(weapon);
		if (spec == null || spec.category() == WeaponCategory.KNIFE) {
			return;
		}
		Vector3f axis = new Vector3f(0.0F, 0.0F, -1.0F);
		poseStack.last().pose().transformDirection(axis);
		float length = axis.length();
		if (!(length > 1.0E-4F)) {
			return;
		}
		axis.div(length);
		float elevation = (float) Math.asin(Mth.clamp(axis.y, -1.0F, 1.0F));
		if (!Float.isFinite(elevation) || Math.abs(elevation) < 0.0015F) {
			return;
		}
		poseStack.mulPose(new Quaternionf().rotationX(-elevation));
	}

	private static void emitParts(VertexConsumer vertexConsumer, Matrix4f base, WeaponModel model,
			WeaponAnim.Frame frame, int light, int overlay, int material, boolean left) {
		float tex = model.texSize();
		Matrix4f matrix = new Matrix4f();
		Vector3f normal = new Vector3f();
		for (WeaponModel.Part part : model.parts()) {
			WeaponAnim.PartPose pose = frame.parts().get(part.name());
			if (pose != null && pose.hidden()) {
				continue;
			}
			partMatrix(matrix, base, part, pose, left);
			for (WeaponModel.Quad quad : part.quads()) {
				if (quad.mat() != material) {
					continue;
				}
				normal.set(quad.nx(), quad.ny(), quad.nz());
				matrix.transformDirection(normal);
				normal.normalize();
				int packedLight = material == WeaponModel.MAT_GLOW ? LightTexture.FULL_BRIGHT : light;
				for (int vertex = 0; vertex < 4; vertex++) {
					vertexConsumer.addVertex(matrix, quad.px()[vertex] / 16.0F, quad.py()[vertex] / 16.0F,
							quad.pz()[vertex] / 16.0F)
							.setColor(255, 255, 255, 255)
							.setUv(quad.u()[vertex] / tex, quad.v()[vertex] / tex)
							.setOverlay(overlay)
							.setLight(packedLight)
							.setNormal(normal.x, normal.y, normal.z);
				}
			}
		}
	}

	private static void partMatrix(Matrix4f matrix, Matrix4f base, WeaponModel.Part part,
			@Nullable PartPose pose, boolean left) {
		matrix.set(base);
		if (pose != null) {
			matrix.translate((left ? -pose.t()[0] : pose.t()[0]) / 16.0F, pose.t()[1] / 16.0F,
					pose.t()[2] / 16.0F);
		}
		float[] rest = part.rest();
		boolean hasRest = rest[0] != 0.0F || rest[1] != 0.0F || rest[2] != 0.0F;
		float pivotX = (left ? 16.0F - part.pivotX() : part.pivotX()) / 16.0F;
		float pivotY = part.pivotY() / 16.0F;
		float pivotZ = part.pivotZ() / 16.0F;
		if (pose != null || hasRest) {
			matrix.translate(pivotX, pivotY, pivotZ);
			if (pose != null) {
				float[] r = pose.r();
				matrix.rotate(new Quaternionf().rotationXYZ(r[0] * Mth.DEG_TO_RAD,
						(left ? -r[1] : r[1]) * Mth.DEG_TO_RAD, (left ? -r[2] : r[2]) * Mth.DEG_TO_RAD));
			}
			if (hasRest) {
				matrix.rotate(new Quaternionf().rotationXYZ(rest[0] * Mth.DEG_TO_RAD,
						(left ? -rest[1] : rest[1]) * Mth.DEG_TO_RAD,
						(left ? -rest[2] : rest[2]) * Mth.DEG_TO_RAD));
			}
			matrix.translate(-pivotX, -pivotY, -pivotZ);
		}
	}

	private static void emitFlash(VertexConsumer vertexConsumer, Matrix4f base, WeaponModel model,
			WeaponAnim.Frame frame) {
		float flash = frame.flash();
		if (flash <= 0.01F) {
			return;
		}
		float[] muzzle = model.muzzle();
		float size = model.flashSize() * (0.7F + 0.5F * flash);
		Matrix4f matrix = new Matrix4f(base);
		matrix.translate((muzzle[0] + frame.flashX()) / 16.0F, muzzle[1] / 16.0F, muzzle[2] / 16.0F);
		matrix.rotateZ(frame.flashRoll() * Mth.DEG_TO_RAD);
		int alpha = (int) (255.0F * Mth.clamp(flash * 1.6F, 0.0F, 1.0F));
		float half = size / 32.0F;
		quadDual(vertexConsumer, matrix,
				-half, -half, 0.0F, half, -half, 0.0F, half, half, 0.0F, -half, half, 0.0F,
				0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 255, 236, 178, alpha);
		quadDual(vertexConsumer, matrix,
				-half, 0.0F, -half, half, 0.0F, -half, half, 0.0F, half, -half, 0.0F, half,
				0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 255, 220, 150, alpha);
	}

	private static void emitSight(VertexConsumer vertexConsumer, Matrix4f base, WeaponModel model,
			WeaponAnim.Frame frame) {
		float[] sight = model.sight();
		float[] color = model.sightColor();
		float glow = Mth.clamp(frame.sightGlow(), 0.0F, 1.0F);
		float size = 0.5F + 0.4F * glow;
		Matrix4f matrix = new Matrix4f(base);
		matrix.translate(sight[0] / 16.0F, sight[1] / 16.0F, sight[2] / 16.0F);
		float half = size / 32.0F;
		int alpha = (int) (100.0F + 155.0F * glow);
		int r = (int) (color[0] * 255.0F);
		int g = (int) (color[1] * 255.0F);
		int b = (int) (color[2] * 255.0F);
		quadDual(vertexConsumer, matrix,
				-half, -half, 0.0F, half, -half, 0.0F, half, half, 0.0F, -half, half, 0.0F,
				0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, r, g, b, alpha);
	}

	private static void quadDual(VertexConsumer vertexConsumer, Matrix4f matrix, float x0, float y0, float z0,
			float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float u0,
			float v0, float u1, float v1, float u2, float v2, float u3, float v3, int r, int g, int b, int a) {
		vertex(vertexConsumer, matrix, x0, y0, z0, u0, v0, r, g, b, a);
		vertex(vertexConsumer, matrix, x1, y1, z1, u1, v1, r, g, b, a);
		vertex(vertexConsumer, matrix, x2, y2, z2, u2, v2, r, g, b, a);
		vertex(vertexConsumer, matrix, x3, y3, z3, u3, v3, r, g, b, a);
		vertex(vertexConsumer, matrix, x3, y3, z3, u3, v3, r, g, b, a);
		vertex(vertexConsumer, matrix, x2, y2, z2, u2, v2, r, g, b, a);
		vertex(vertexConsumer, matrix, x1, y1, z1, u1, v1, r, g, b, a);
		vertex(vertexConsumer, matrix, x0, y0, z0, u0, v0, r, g, b, a);
	}

	private static void vertex(VertexConsumer vertexConsumer, Matrix4f matrix, float x, float y, float z, float u,
			float v, int r, int g, int b, int a) {
		vertexConsumer.addVertex(matrix, x, y, z)
				.setColor(r, g, b, a)
				.setUv(u, v)
				.setOverlay(OverlayTexture.NO_OVERLAY)
				.setLight(LightTexture.FULL_BRIGHT)
				.setNormal(0.0F, 0.0F, 1.0F);
	}
}
