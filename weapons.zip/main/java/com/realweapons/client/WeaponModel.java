package com.realweapons.client;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.realweapons.RealWeaponsMod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;

public final class WeaponModel {
	public static final int MAT_SOLID = 0;
	public static final int MAT_GLASS = 1;
	public static final int MAT_GLOW = 2;

	public record Quad(float[] px, float[] py, float[] pz, float[] u, float[] v, float nx, float ny, float nz,
			int mat) {
	}

	public record Part(String name, float pivotX, float pivotY, float pivotZ, float[] rest, List<Quad> quads,
			boolean hasGlow, boolean hasGlass) {
	}

	private static final Map<String, WeaponModel> CACHE = new HashMap<>();

	private final List<Part> parts;
	private final float[] muzzle;
	private final float[] sight;
	private final float flashSize;
	private final float[] adsTranslate;
	private final float[] adsRotate;
	private final float[] bounds;
	private final RenderType solidLayer;
	private final RenderType glassLayer;
	private final RenderType glowLayer;
	private final float[] sightColor;
	private final float texSize;
	private final float scope;
	private final Map<String, float[]> anchors;

	private WeaponModel(List<Part> parts, float[] muzzle, float[] sight, float flashSize, float[] adsTranslate,
			float[] adsRotate, float[] bounds, float[] sightColor, float texSize, float scope, Identifier texture,
			Map<String, float[]> anchors) {
		this.parts = parts;
		this.muzzle = muzzle;
		this.sight = sight;
		this.flashSize = flashSize;
		this.adsTranslate = adsTranslate;
		this.adsRotate = adsRotate;
		this.bounds = bounds;
		this.sightColor = sightColor;
		this.texSize = texSize;
		this.scope = scope;
		this.anchors = anchors;
		this.solidLayer = RenderTypes.entityCutout(texture);
		this.glassLayer = RenderTypes.entityTranslucent(texture);
		this.glowLayer = RenderTypes.entityTranslucentEmissive(texture);
	}

	public float[] anchor(String name) {
		return this.anchors.get(name);
	}

	public Part part(String name) {
		for (Part part : this.parts) {
			if (part.name().equals(name)) {
				return part;
			}
		}
		return null;
	}

	public float texSize() {
		return this.texSize;
	}

	public float scope() {
		return this.scope;
	}

	public List<Part> parts() {
		return this.parts;
	}

	public float[] muzzle() {
		return this.muzzle;
	}

	public float[] sight() {
		return this.sight;
	}

	public float flashSize() {
		return this.flashSize;
	}

	public float[] adsTranslate() {
		return this.adsTranslate;
	}

	public float[] adsRotate() {
		return this.adsRotate;
	}

	public float[] bounds() {
		return this.bounds;
	}

	public float[] sightColor() {
		return this.sightColor;
	}

	public RenderType solidLayer() {
		return this.solidLayer;
	}

	public RenderType glassLayer() {
		return this.glassLayer;
	}

	public RenderType glowLayer() {
		return this.glowLayer;
	}

	public static WeaponModel get(String weaponId) {
		if (CACHE.containsKey(weaponId)) {
			return CACHE.get(weaponId);
		}
		WeaponModel model = load(weaponId);
		CACHE.put(weaponId, model);
		return model;
	}

	private static WeaponModel load(String weaponId) {
		try {
			Identifier location = RealWeaponsMod.id("weapon_models/" + weaponId + ".json");
			Minecraft minecraft = Minecraft.getInstance();
			Optional<Resource> resource = minecraft.getResourceManager().getResource(location);
			if (resource.isEmpty()) {
				return null;
			}
			try (Reader reader = resource.get().openAsReader()) {
				JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
				float tex = getFloat(root, "tex", 64.0F);
				String textureName = root.has("texture") ? root.get("texture").getAsString() : weaponId;
				Identifier texture = RealWeaponsMod.id("textures/entity/weapon/" + textureName + ".png");

				float[] muzzle = getVector(root, "muzzle", new float[] { 8.0F, 8.0F, 1.0F });
				float[] sight = getVector(root, "sight", new float[] { 8.0F, 8.0F, 6.0F });
				float[] sightColor = getVector(root, "sight_color", new float[] { 0.35F, 1.0F, 0.4F });
				float flash = getFloat(root, "flash", 2.6F);
				float scope = getFloat(root, "scope", 0.0F);
				float[] adsTranslate = new float[] { 0.0F, 0.0F, 0.0F };
				float[] adsRotate = new float[] { 0.0F, 0.0F, 0.0F };
				if (root.has("ads")) {
					JsonObject ads = root.getAsJsonObject("ads");
					adsTranslate = getVector(ads, "translate", adsTranslate);
					adsRotate = getVector(ads, "rotate", adsRotate);
				}

				List<Part> parts = new ArrayList<>();
				float minX = Float.MAX_VALUE;
				float minY = Float.MAX_VALUE;
				float minZ = Float.MAX_VALUE;
				float maxX = -Float.MAX_VALUE;
				float maxY = -Float.MAX_VALUE;
				float maxZ = -Float.MAX_VALUE;

				JsonArray partsArray = root.getAsJsonArray("parts");
				for (int i = 0; i < partsArray.size(); i++) {
					JsonObject partObject = partsArray.get(i).getAsJsonObject();
					String name = partObject.get("name").getAsString();
					float[] pivot = getVector(partObject, "pivot", new float[] { 8.0F, 8.0F, 8.0F });
					float[] rest = getVector(partObject, "rot", new float[] { 0.0F, 0.0F, 0.0F });
					List<Quad> quads = new ArrayList<>();
					boolean hasGlow = false;
					boolean hasGlass = false;

					JsonArray cubesArray = partObject.getAsJsonArray("cubes");
					if (cubesArray != null) {
						for (int c = 0; c < cubesArray.size(); c++) {
							JsonObject cubeObject = cubesArray.get(c).getAsJsonObject();
							float[] origin = getVector(cubeObject, "origin", new float[] { 0.0F, 0.0F, 0.0F });
							float[] size = getVector(cubeObject, "size", new float[] { 1.0F, 1.0F, 1.0F });
							float[] uv = getVector(cubeObject, "uv", new float[] { 0.0F, 0.0F });
							String mat = cubeObject.has("mat") ? cubeObject.get("mat").getAsString() : "steel";
							int material = mat.equals("glow") ? MAT_GLOW : (mat.equals("glass") ? MAT_GLASS : MAT_SOLID);
							if (material == MAT_GLOW) {
								hasGlow = true;
							}
							if (material == MAT_GLASS) {
								hasGlass = true;
							}
							addCube(quads, origin[0], origin[1], origin[2], size[0], size[1], size[2], uv[0], uv[1],
									material);
							minX = Math.min(minX, origin[0]);
							minY = Math.min(minY, origin[1]);
							minZ = Math.min(minZ, origin[2]);
							maxX = Math.max(maxX, origin[0] + size[0]);
							maxY = Math.max(maxY, origin[1] + size[1]);
							maxZ = Math.max(maxZ, origin[2] + size[2]);
						}
					}
					JsonArray quadsArray = partObject.getAsJsonArray("quads");
					if (quadsArray != null) {
						for (int q = 0; q < quadsArray.size(); q++) {
							JsonObject quadObject = quadsArray.get(q).getAsJsonObject();
							float[] p = getVector(quadObject, "p", new float[12]);
							float[] quadUv = getVector(quadObject, "uv", new float[8]);
							float[] n = getVector(quadObject, "n", new float[] { 0.0F, 1.0F, 0.0F });
							int material = quadObject.has("m") ? quadObject.get("m").getAsInt() : MAT_SOLID;
							if (material == MAT_GLOW) {
								hasGlow = true;
							}
							if (material == MAT_GLASS) {
								hasGlass = true;
							}
							quads.add(new Quad(new float[] { p[0], p[3], p[6], p[9] },
									new float[] { p[1], p[4], p[7], p[10] },
									new float[] { p[2], p[5], p[8], p[11] },
									new float[] { quadUv[0], quadUv[2], quadUv[4], quadUv[6] },
									new float[] { quadUv[1], quadUv[3], quadUv[5], quadUv[7] },
									n[0], n[1], n[2], material));
							for (int v = 0; v < 12; v += 3) {
								minX = Math.min(minX, p[v]);
								maxX = Math.max(maxX, p[v]);
								minY = Math.min(minY, p[v + 1]);
								maxY = Math.max(maxY, p[v + 1]);
								minZ = Math.min(minZ, p[v + 2]);
								maxZ = Math.max(maxZ, p[v + 2]);
							}
						}
					}
					parts.add(new Part(name, pivot[0], pivot[1], pivot[2], rest, quads, hasGlow, hasGlass));
				}

				float[] bounds = new float[] { minX / 16.0F, minY / 16.0F, minZ / 16.0F, maxX / 16.0F, maxY / 16.0F,
						maxZ / 16.0F };
				Map<String, float[]> anchors = new HashMap<>();
				if (root.has("anchors")) {
					JsonObject anchorsObject = root.getAsJsonObject("anchors");
					for (String key : anchorsObject.keySet()) {
						anchors.put(key, getVector(anchorsObject, key, new float[] { 8.0F, 8.0F, 8.0F }));
					}
				}
				return new WeaponModel(parts, muzzle, sight, flash, adsTranslate, adsRotate, bounds, sightColor, tex,
						scope, texture, anchors);
			}
		} catch (Exception exception) {
			return null;
		}
	}

	private static void addCube(List<Quad> quads, float x0, float y0, float z0, float w, float h, float d, float u,
			float v, int mat) {
		float x1 = x0 + w;
		float y1 = y0 + h;
		float z1 = z0 + d;

		if (w > 0.0F && d > 0.0F) {
			quad(quads, mat, 0.0F, -1.0F, 0.0F, u + d, v, u + d + w, v + d,
					x1, y0, z1, x0, y0, z1, x0, y0, z0, x1, y0, z0);
			quad(quads, mat, 0.0F, 1.0F, 0.0F, u + d + w, v + d, u + d + w + w, v,
					x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1);
		}
		if (w > 0.0F && h > 0.0F) {
			quad(quads, mat, 0.0F, 0.0F, -1.0F, u + d, v + d, u + d + w, v + d + h,
					x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0);
			quad(quads, mat, 0.0F, 0.0F, 1.0F, u + d + w + d, v + d, u + d + w + d + w, v + d + h,
					x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
		}
		if (d > 0.0F && h > 0.0F) {
			quad(quads, mat, -1.0F, 0.0F, 0.0F, u, v + d, u + d, v + d + h,
					x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
			quad(quads, mat, 1.0F, 0.0F, 0.0F, u + d + w, v + d, u + d + w + d, v + d + h,
					x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1);
		}
	}

	private static void quad(List<Quad> quads, int mat, float nx, float ny, float nz, float uA, float vA, float uB,
			float vB, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
			float dx, float dy, float dz) {
		float[] px = new float[] { ax, bx, cx, dx };
		float[] py = new float[] { ay, by, cy, dy };
		float[] pz = new float[] { az, bz, cz, dz };
		float[] u = new float[] { uB, uA, uA, uB };
		float[] v = new float[] { vA, vA, vB, vB };
		quads.add(new Quad(px, py, pz, u, v, nx, ny, nz, mat));
	}

	private static float getFloat(JsonObject object, String key, float fallback) {
		return object.has(key) ? object.get(key).getAsFloat() : fallback;
	}

	private static float[] getVector(JsonObject object, String key, float[] fallback) {
		if (!object.has(key)) {
			return fallback;
		}
		JsonArray array = object.getAsJsonArray(key);
		float[] result = new float[array.size()];
		for (int i = 0; i < array.size(); i++) {
			result[i] = array.get(i).getAsFloat();
		}
		return result;
	}
}
