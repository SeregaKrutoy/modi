package com.realweapons.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realweapons.FirePayload;
import com.realweapons.HitMarkerPayload;
import com.realweapons.ModContent;
import com.realweapons.RealWeaponsMod;
import com.realweapons.ReloadPayload;
import com.realweapons.WeaponCategory;
import com.realweapons.WeaponEventPayload;
import com.realweapons.WeaponItem;
import com.realweapons.WeaponSpec;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.item.ItemModels;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import org.lwjgl.glfw.GLFW;

public class RealWeaponsClient implements ClientModInitializer {
	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(RealWeaponsMod.id("weapons"));
	private static final KeyMapping RELOAD_KEY = new KeyMapping("key.realweapons.reload", InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_R, CATEGORY);

	private static boolean attackHeld;
	private static int fireCooldown;
	private static float recoilPending;
	private static int originalFov = -1;

	@Override
	public void onInitializeClient() {
		ItemModels.ID_MAPPER.put(RealWeaponsMod.id("gun"), GunItemModel.Unbaked.MAP_CODEC);
		KeyBindingHelper.registerKeyBinding(RELOAD_KEY);

		EntityRendererRegistry.register(ModContent.FRAG_GRENADE, ThrownItemRenderer::new);
		EntityRendererRegistry.register(ModContent.SMOKE_GRENADE, ThrownItemRenderer::new);
		EntityRendererRegistry.register(ModContent.FLASHBANG, ThrownItemRenderer::new);
		EntityRendererRegistry.register(ModContent.MOLOTOV, ThrownItemRenderer::new);
		EntityRendererRegistry.register(ModContent.GRENADE_SHELL, ThrownItemRenderer::new);
		EntityRendererRegistry.register(ModContent.ROCKET, ThrownItemRenderer::new);

		ClientPlayNetworking.registerGlobalReceiver(WeaponEventPayload.TYPE, (payload, context) ->
				context.client().execute(() -> {
					Minecraft minecraft = context.client();
					LocalPlayer player = minecraft.player;
					if (player != null && payload.entityId() == player.getId()) {
						if (payload.event() == WeaponEventPayload.RELOAD_END) {
							WeaponAnim.onLocalReloadEnd();
						}
						return;
					}
					WeaponAnim.onRemoteEvent(payload.entityId(), payload.event(), payload.weapon());
				}));

		ClientPlayNetworking.registerGlobalReceiver(HitMarkerPayload.TYPE, (payload, context) ->
				context.client().execute(() -> WeaponAnim.onHit(payload)));

		ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> heldSpec(player) != null);

		UseBlockCallback.EVENT.register((player, level, hand, hitResult) -> suppressUse(player, hand));
		UseItemCallback.EVENT.register((player, level, hand) -> suppressUse(player, hand));

		ClientTickEvents.END_CLIENT_TICK.register(RealWeaponsClient::tick);
		HudElementRegistry.addLast(RealWeaponsMod.id("ammo"), AmmoHud::render);
	}

	private static void tick(Minecraft minecraft) {
		WeaponAnim.tick(minecraft);
		LocalPlayer player = minecraft.player;
		if (player == null || minecraft.level == null) {
			attackHeld = false;
			fireCooldown = 0;
			recoilPending = 0.0F;
			WeaponAnim.setAiming(false);
			return;
		}

		while (RELOAD_KEY.consumeClick()) {
			requestReload(player);
		}

		WeaponSpec spec = heldSpec(player);
		boolean aiming = spec != null && spec.category().usesAds() && minecraft.options.keyUse.isDown()
				&& minecraft.screen == null;
		WeaponAnim.setAiming(aiming);
		applyFov(minecraft, aiming ? spec.adsZoom() : 0);

		boolean attackDown = spec != null && minecraft.options.keyAttack.isDown() && minecraft.screen == null;
		if (!attackDown) {
			attackHeld = false;
		} else {
			boolean fresh = !attackHeld;
			attackHeld = true;
			if (fireCooldown <= 0 && (fresh || spec.automatic())) {
				tryAttack(minecraft, player, spec);
			}
		}

		if (fireCooldown > 0) {
			fireCooldown--;
		}

		if (recoilPending > 0.0F) {
			float apply = recoilPending * 0.4F;
			recoilPending = recoilPending - apply < 0.02F ? 0.0F : recoilPending - apply;
			player.setXRot(player.getXRot() - apply);
		}

		AmmoHud.adoptTick(player, spec);
	}

	private static void tryAttack(Minecraft minecraft, LocalPlayer player, WeaponSpec spec) {
		if (WeaponAnim.reloading()) {
			return;
		}
		fireCooldown = spec.interval();
		if (spec.category() == WeaponCategory.KNIFE) {
			ClientPlayNetworking.send(new FirePayload(WeaponAnim.isAiming()));
			WeaponAnim.onLocalFire(spec);
			player.swing(InteractionHand.MAIN_HAND);
			return;
		}
		if (spec.magSize() > 0) {
			if (AmmoHud.clientCount(player, spec) <= 0) {
				dryFire(player, spec);
				return;
			}
			AmmoHud.spend(player, spec);
		}
		ClientPlayNetworking.send(new FirePayload(WeaponAnim.isAiming()));
		WeaponAnim.onLocalFire(spec);
		if (spec.category().isThrowable()) {
			WeaponAnim.playLocal("throw.whoosh", 0.8F, 0.95F + player.getRandom().nextFloat() * 0.1F);
		} else {
			WeaponAnim.playLocal("weapon." + spec.id(), 0.9F, 0.97F + player.getRandom().nextFloat() * 0.06F);
			recoilPending = Math.min(4.0F, recoilPending + (float) spec.recoil());
		}
	}

	private static void dryFire(LocalPlayer player, WeaponSpec spec) {
		if (WeaponAnim.dryAge() > 5.0F) {
			WeaponAnim.onLocalDry();
			WeaponAnim.playLocal("weapon.dry", 0.9F, 1.0F);
		}
		if (!WeaponAnim.reloading() && spec.reloadTicks() > 0) {
			ClientPlayNetworking.send(new ReloadPayload());
			WeaponAnim.onLocalReload(spec);
		}
	}

	private static void requestReload(LocalPlayer player) {
		WeaponSpec spec = heldSpec(player);
		if (spec == null || spec.magSize() <= 0 || WeaponAnim.reloading()) {
			return;
		}
		if (AmmoHud.clientCount(player, spec) >= spec.magSize()) {
			return;
		}
		ClientPlayNetworking.send(new ReloadPayload());
		WeaponAnim.onLocalReload(spec);
	}

	private static WeaponSpec heldSpec(LocalPlayer player) {
		if (player == null) {
			return null;
		}
		return player.getMainHandItem().getItem() instanceof WeaponItem weapon ? weapon.spec() : null;
	}

	private static InteractionResult suppressUse(net.minecraft.world.entity.player.Player player,
			InteractionHand hand) {
		if (hand == InteractionHand.MAIN_HAND && player.getMainHandItem().getItem() instanceof WeaponItem) {
			return InteractionResult.FAIL;
		}
		return InteractionResult.PASS;
	}

	private static void applyFov(Minecraft minecraft, int adsZoom) {
		if (adsZoom > 0) {
			if (originalFov < 0) {
				originalFov = minecraft.options.fov().get();
			}
		} else if (originalFov < 0) {
			return;
		}
		int target = adsZoom > 0 ? Math.min(originalFov, adsZoom) : originalFov;
		int current = minecraft.options.fov().get();
		if (current == target) {
			if (adsZoom == 0) {
				originalFov = -1;
			}
			return;
		}
		int next = current + Mth.clamp(target - current, -8, 8);
		if (Math.abs(next - target) <= 1) {
			next = target;
		}
		minecraft.options.fov().set(next);
	}
}
