package com.realweapons.client;

public final class FpState {
	private static boolean handsPass;

	private FpState() {
	}

	public static void enter() {
		handsPass = true;
	}

	public static void exit() {
		handsPass = false;
	}

	public static boolean handsPass() {
		return handsPass;
	}
}
