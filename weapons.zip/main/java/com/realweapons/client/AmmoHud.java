package com.realweapons.client;

import com.realweapons.Components;
import com.realweapons.RealWeaponsMod;
import com.realweapons.WeaponItem;
import com.realweapons.WeaponSpec;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3x2fStack;

public final class AmmoHud {
	private static final int COLOR_TEXT = 0xFFF2F5F8;
	private static final int COLOR_DIM = 0xB0C6CDD6;
	private static final int COLOR_RED = 0xFFFF5238;
	private static final int COLOR_ACCENT = 0xFFFFB84D;
	private static final int COLOR_TRACK = 0x88101318;
	private static final Identifier SCOPE_TEXTURE = RealWeaponsMod.id("textures/gui/scope.png");

	private static String weaponId;
	private static int predicted = -1;
	private static int sinceFire = 100;

	private AmmoHud() {
	}

	public static int clientCount(Player player, WeaponSpec spec) {
		ItemStack stack = player.getMainHandItem();
		int server = stack.getOrDefault(Components.MAGAZINE, new Components.Magazine(spec.magSize())).count();
		if (!spec.id().equals(weaponId)) {
			weaponId = spec.id();
			predicted = server;
			sinceFire = 100;
		}
		if (server > predicted) {
			if (WeaponAnim.reloading()) {
				WeaponAnim.cancelLocalReload();
			}
			predicted = server;
		} else if (sinceFire > 20) {
			predicted = server;
		}
		predicted = Mth.clamp(predicted, 0, Math.max(1, spec.magSize()));
		return predicted;
	}

	public static void spend(Player player, WeaponSpec spec) {
		clientCount(player, spec);
		predicted = Math.max(0, predicted - 1);
		sinceFire = 0;
	}

	public static void adoptTick(Player player, WeaponSpec spec) {
		if (spec != null) {
			clientCount(player, spec);
		}
		sinceFire++;
	}

	public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null) {
			return;
		}
		if (!(player.getMainHandItem().getItem() instanceof WeaponItem weapon)) {
			return;
		}
		WeaponSpec spec = weapon.spec();
		int width = minecraft.getWindow().getGuiScaledWidth();
		int height = minecraft.getWindow().getGuiScaledHeight();
		int cx = width / 2;
		int cy = height / 2;
		boolean aiming = WeaponAnim.isAiming();
		boolean reloading = WeaponAnim.reloading();

		WeaponModel model = WeaponModel.get(spec.id());
		if (aiming && model != null && model.scope() > 0.0F && WeaponAnim.adsBlend() >= 0.6F) {
			renderScope(g, width, height);
		}

		if (spec.category().isThrowable()) {
			int count = player.getMainHandItem().getCount();
			Matrix3x2fStack pose = g.pose();
			pose.pushMatrix();
			pose.translate(width - 26.0F, height - 60.0F);
			pose.scale(2.0F, 2.0F);
			String text = "x" + count;
			g.drawString(minecraft.font, text, -minecraft.font.width(text), 0, count == 0 ? COLOR_RED : COLOR_TEXT, true);
			pose.popMatrix();
		} else if (spec.magSize() > 0) {
			int count = clientCount(player, spec);
			boolean low = count <= Math.max(1, spec.magSize() / 4);
			int countColor = count == 0 ? COLOR_RED : (low ? COLOR_ACCENT : COLOR_TEXT);
			Matrix3x2fStack pose = g.pose();
			pose.pushMatrix();
			pose.translate(width - 26.0F, height - 62.0F);
			pose.scale(2.0F, 2.0F);
			String text = Integer.toString(count);
			g.drawString(minecraft.font, text, -minecraft.font.width(text), 0, countColor, true);
			pose.popMatrix();

			String total = "/ " + spec.magSize();
			g.drawString(minecraft.font, total, width - 26 - minecraft.font.width(total), height - 40, COLOR_DIM, true);

			if (reloading) {
				float progress = WeaponAnim.reloadProgress();
				int barW = 52;
				int barX = width - 30 - barW;
				int barY = height - 32;
				g.fill(barX - 1, barY - 1, barX + barW + 1, barY + 5, COLOR_TRACK);
				int fillW = (int) (barW * Mth.clamp(progress, 0.0F, 1.0F));
				g.fill(barX, barY, barX + fillW, barY + 4, COLOR_ACCENT);
			}
		}

		if (!aiming && !reloading) {
			float gap = 3.0F + (float) spec.spread() * 2.0F;
			if (player.getDeltaMovement().horizontalDistanceSqr() > 0.01) {
				gap += 1.5F;
			}
			int tick = (int) gap;
			int len = 4;
			int color = 0xB8FFFFFF;
			g.fill(cx - tick - len, cy, cx - tick, cy + 1, color);
			g.fill(cx + tick + 1, cy, cx + tick + len + 1, cy + 1, color);
			g.fill(cx, cy - tick - len, cx + 1, cy - tick, color);
			g.fill(cx, cy + tick + 1, cx + 1, cy + tick + len + 1, color);
			g.fill(cx, cy, cx + 1, cy + 1, 0xE0FFFFFF);
		}

		float hit = WeaponAnim.hitMarker();
		if (hit < 8.0F) {
			int alpha = (int) ((1.0F - hit / 8.0F) * 255.0F);
			int base = WeaponAnim.hitWasHead() ? 0xFF5238 : 0xFFFFFF;
			int color = (alpha << 24) | base;
			int inner = 4 + (int) hit / 2;
			int outer = 9 + (int) hit;
			for (int i = inner; i < outer; i++) {
				g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, color);
				g.fill(cx - i - 1, cy - i, cx - i, cy - i + 1, color);
				g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
				g.fill(cx - i - 1, cy + i, cx - i, cy + i + 1, color);
			}
		}
	}

	private static void renderScope(GuiGraphics g, int width, int height) {
		int size = Math.min(width, height);
		int x0 = (width - size) / 2;
		int y0 = (height - size) / 2;
		int black = 0xFF000000;
		g.fill(0, 0, width, y0, black);
		g.fill(0, y0 + size, width, height, black);
		g.fill(0, y0, x0, y0 + size, black);
		g.fill(x0 + size, y0, width, y0 + size, black);
		g.blit(SCOPE_TEXTURE, x0, y0, x0 + size, y0 + size, 0.0F, 1.0F, 0.0F, 1.0F);
	}
}
