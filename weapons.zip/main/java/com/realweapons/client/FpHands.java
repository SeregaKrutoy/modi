package com.realweapons.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.realweapons.WeaponCategory;
import com.realweapons.WeaponSpec;
import com.realweapons.WeaponSpecs;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerModelType;
import org.joml.AxisAngle4f;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class FpHands {
	private static final float MAG_OFF_X = 2.9F;
	private static final float MAG_OFF_Y = 0.9F;
	private static final float MAG_OFF_Z = -0.1F;
	private static final float[] ZERO = new float[] { 0.0F, 0.0F, 0.0F };

	private static Identifier skinId;
	private static RenderType skinLayer;

	private FpHands() {
	}

	private record Plan(float a, float b, float c, float d, float e, float f, float g, float h, float i, boolean carry,
			boolean toss) {
	}

	public static void submit(WeaponAnim.Frame frame, String weapon, WeaponModel model, PoseStack poseStack,
			SubmitNodeCollector submitNodeCollector, int light, int overlay, boolean leftHand) {
		WeaponSpec spec = WeaponSpecs.byId(weapon);
		if (spec == null) {
			return;
		}
		WeaponCategory category = spec.category();
		if (category == null || !category.usesAds()) {
			return;
		}
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null || player.isInvisible()) {
			return;
		}

		float p = WeaponAnim.reloadSmooth();
		float[] support = support(category);
		float[] supportAnchor = model.anchor("support");
		if (supportAnchor != null) {
			support = supportAnchor;
		}
		float[] grab = grab(category);
		String partName = partName(category);
		float[] pivot = pivot(model, partName);
		boolean hasPart = pivot != null;
		if (pivot == null) {
			pivot = new float[] { 8.0F, support[1] + 1.6F, support[2] + 1.4F };
		}
		float[] partOffset = hasPart ? partT(frame, partName) : ZERO;
		float[] magAnchor = model.anchor("mag");
		WeaponModel.Part carriedPart = null;
		if (hasPart && magAnchor != null && partName != null) {
			carriedPart = model.part(partName);
		}
		final WeaponModel.Part carried = carriedPart;

		float sx = mirror(support[0], leftHand);
		float sy = support[1];
		float sz = support[2];
		float handX = sx;
		float handY = sy;
		float handZ = sz;
		boolean carry = false;
		boolean toss = false;
		float carryX = 0.0F;
		float carryY = 0.0F;
		float carryZ = 0.0F;
		float tossX = 0.0F;
		float tossY = 0.0F;
		float tossZ = 0.0F;
		float tossSpinX = 0.0F;
		float tossSpinZ = 0.0F;

		float tox = leftHand ? -partOffset[0] : partOffset[0];
		float trackX;
		float trackY;
		float trackZ;
		if (magAnchor != null) {
			trackX = mirror(magAnchor[0], leftHand) + tox;
			trackY = magAnchor[1] + partOffset[1];
			trackZ = magAnchor[2] + partOffset[2];
		} else {
			trackX = mirror(pivot[0], leftHand) + mirror(grab[0], leftHand) + tox;
			trackY = pivot[1] + grab[1] + partOffset[1];
			trackZ = pivot[2] + grab[2] + partOffset[2];
		}

		if (category == WeaponCategory.SHOTGUN_PUMP) {
			handX = trackX;
			handY = trackY;
			handZ = trackZ;
		} else if (p >= 0.0F) {
			Plan plan = plan(category);
			float dipY = trackY - 7.5F;
			float dipZ = trackZ + 1.2F;
			if (p < plan.a()) {
				handX = sx;
				handY = sy;
				handZ = sz;
			} else if (p < plan.b()) {
				float k = ease(seg(p, plan.a(), plan.b()));
				handX = lerp(sx, trackX, k);
				handY = lerp(sy, trackY, k);
				handZ = lerp(sz, trackZ, k);
			} else if (p < plan.c()) {
				handX = trackX;
				handY = trackY;
				handZ = trackZ;
			} else if (p < plan.d()) {
				float k = ease(seg(p, plan.c(), plan.d()));
				handX = trackX;
				handY = lerp(trackY, dipY, k);
				handZ = lerp(trackZ, dipZ, k);
			} else if (p < plan.e()) {
				float k = ease(seg(p, plan.d(), plan.e()));
				handX = trackX;
				handY = lerp(dipY, trackY, k);
				handZ = lerp(dipZ, trackZ, k);
			} else if (p < plan.f()) {
				handX = trackX;
				handY = trackY;
				handZ = trackZ;
			} else if (p < plan.g()) {
				float bump = Mth.sin(seg(p, plan.f(), plan.g()) * (float) Math.PI);
				handX = trackX;
				handY = trackY + 0.9F * bump;
				handZ = trackZ - 0.6F * bump;
			} else {
				float[] rack = rackPos(model, category, leftHand);
				if (rack == null) {
					float k = ease(seg(p, plan.i(), 1.0F));
					handX = lerp(trackX, sx, k);
					handY = lerp(trackY, sy, k);
					handZ = lerp(trackZ, sz, k);
				} else if (p < plan.h()) {
					float k = ease(seg(p, plan.g(), plan.h()));
					handX = lerp(trackX, rack[0], k);
					handY = lerp(trackY, rack[1], k);
					handZ = lerp(trackZ, rack[2], k);
				} else if (p < plan.i()) {
					float[] bolt = partT(frame, rackPart(category));
					float pull = Mth.clamp(Math.abs(bolt[2]) / 1.5F, 0.0F, 1.0F);
					handX = rack[0];
					handY = rack[1] - 0.35F * pull;
					handZ = rack[2] + bolt[2];
				} else {
					float k = ease(seg(p, plan.i(), 1.0F));
					handX = lerp(rack[0], sx, k);
					handY = lerp(rack[1], sy, k);
					handZ = lerp(rack[2], sz, k);
				}
			}
			float magOffsetX = leftHand ? -MAG_OFF_X : MAG_OFF_X;
			boolean realMag = carried != null;
			float magX = realMag ? (leftHand ? 0.6F : -0.6F) : magOffsetX;
			float magY = realMag ? 0.5F : MAG_OFF_Y;
			float magZ = realMag ? -0.5F : MAG_OFF_Z;
			if (hasPart && plan.carry() && p >= plan.d() && p <= plan.e()) {
				carry = true;
				carryX = handX + magX;
				carryY = handY + magY;
				carryZ = handZ + magZ;
			}
			if (hasPart && plan.toss() && p >= plan.c() && p <= plan.c() + 0.15F) {
				toss = true;
				float q = (p - plan.c()) / 0.15F;
				float out = leftHand ? 2.4F : -2.4F;
				tossX = handX + magX + out * q;
				tossY = handY + magY - 0.5F * q - 26.0F * q * q;
				tossZ = handZ + magZ + 1.6F * q;
				tossSpinX = 120.0F * q;
				tossSpinZ = 540.0F * q;
			}
		}

		Identifier texture = player.getSkin().body().texturePath();
		boolean slim = player.getSkin().model() == PlayerModelType.SLIM;
		float width = slim ? 3.0F : 4.0F;
		int armU = leftHand ? 40 : 32;
		int armV = leftHand ? 16 : 48;
		Vector3f dir = new Vector3f(leftHand ? 0.60F : -0.60F, -0.74F, 0.30F).normalize();
		Quaternionf rotation = between(new Vector3f(0.0F, 1.0F, 0.0F), dir);
		RenderType layer = skinLayer(texture);
		final float hx = handX;
		final float hy = handY;
		final float hz = handZ;
		submitNodeCollector.submitCustomGeometry(poseStack, layer, (pose, vertexConsumer) ->
				emitArm(vertexConsumer, pose.pose(), hx, hy, hz, rotation, armU, armV, width, light, overlay));
		if (carry) {
			final float cx = carryX;
			final float cy = carryY;
			final float cz = carryZ;
			if (carried != null && magAnchor != null) {
				final WeaponModel.Part part = carried;
				final float[] anchor = magAnchor;
				submitNodeCollector.submitCustomGeometry(poseStack, model.solidLayer(), (pose, vertexConsumer) ->
						emitMagPart(vertexConsumer, pose.pose(), part, anchor, cx, cy, cz, 0.0F, 0.0F,
								model.texSize(), leftHand, light, overlay));
			} else {
				submitNodeCollector.submitCustomGeometry(poseStack, model.solidLayer(), (pose, vertexConsumer) ->
						emitMag(vertexConsumer, pose.pose(), cx, cy, cz, 0.0F, 0.0F, model.texSize(), light, overlay));
			}
		}
		if (toss) {
			final float ox = tossX;
			final float oy = tossY;
			final float oz = tossZ;
			final float spinX = tossSpinX;
			final float spinZ = tossSpinZ;
			if (carried != null && magAnchor != null) {
				final WeaponModel.Part part = carried;
				final float[] anchor = magAnchor;
				submitNodeCollector.submitCustomGeometry(poseStack, model.solidLayer(), (pose, vertexConsumer) ->
						emitMagPart(vertexConsumer, pose.pose(), part, anchor, ox, oy, oz, spinX, spinZ,
								model.texSize(), leftHand, light, overlay));
			} else {
				submitNodeCollector.submitCustomGeometry(poseStack, model.solidLayer(), (pose, vertexConsumer) ->
						emitMag(vertexConsumer, pose.pose(), ox, oy, oz, spinX, leftHand ? -spinZ : spinZ,
								model.texSize(), light, overlay));
			}
		}
	}

	private static void emitArm(VertexConsumer vertexConsumer, Matrix4f base, float x, float y, float z,
			Quaternionf rotation, int armU, int armV, float width, int light, int overlay) {
		Matrix4f matrix = new Matrix4f(base);
		matrix.translate(x / 16.0F, y / 16.0F, z / 16.0F);
		matrix.rotate(rotation);
		emitBoxUv(vertexConsumer, matrix, -width / 2.0F, -2.0F, -2.0F, width, 4.0F, 4.0F, armU, armV, armV + 16.0F,
				armV + 12.0F, true, light, overlay);
		emitBoxUv(vertexConsumer, matrix, -width / 2.0F, 1.8F, -2.0F, width, 14.8F, 4.0F, armU, armV, armV + 12.0F,
				armV + 4.0F, false, light, overlay);
	}

	private static void emitMag(VertexConsumer vertexConsumer, Matrix4f base, float x, float y, float z, float spinX,
			float spinZ, float texSize, int light, int overlay) {
		Matrix4f matrix = new Matrix4f(base);
		matrix.translate(x / 16.0F, y / 16.0F, z / 16.0F);
		matrix.rotate(new Quaternionf().rotationXYZ(spinX * Mth.DEG_TO_RAD, 0.0F, spinZ * Mth.DEG_TO_RAD));
		emitBox(vertexConsumer, matrix, -1.1F, -1.3F, -1.1F, 2.2F, 2.6F, 2.2F, 44.8F, 0.0F, texSize, light, overlay);
		Matrix4f lower = new Matrix4f(matrix);
		lower.translate(0.0F, -2.35F / 16.0F, -0.35F / 16.0F);
		lower.rotate(new Quaternionf().rotationX(0.45F));
		emitBox(vertexConsumer, lower, -1.05F, -1.4F, -1.05F, 2.1F, 2.8F, 2.1F, 35.4F, 0.0F, texSize, light, overlay);
	}

	private static void emitMagPart(VertexConsumer vertexConsumer, Matrix4f base, WeaponModel.Part part, float[] anchor,
			float x, float y, float z, float spinX, float spinZ, float texSize, boolean leftHand, int light,
			int overlay) {
		Matrix3f spin = new Matrix3f().rotation(new Quaternionf().rotationXYZ(spinX * Mth.DEG_TO_RAD, 0.0F,
				spinZ * Mth.DEG_TO_RAD));
		Vector3f offset = new Vector3f();
		Vector3f normal = new Vector3f();
		for (WeaponModel.Quad quad : part.quads()) {
			normal.set(quad.nx(), quad.ny(), quad.nz());
			spin.transform(normal);
			if (leftHand) {
				normal.x = -normal.x;
			}
			normal.normalize();
			for (int vertex = 0; vertex < 4; vertex++) {
				offset.set(quad.px()[vertex] - anchor[0], quad.py()[vertex] - anchor[1],
						quad.pz()[vertex] - anchor[2]);
				spin.transform(offset);
				float vx = x + (leftHand ? -offset.x : offset.x);
				float vy = y + offset.y;
				float vz = z + offset.z;
				vertexConsumer.addVertex(base, vx / 16.0F, vy / 16.0F, vz / 16.0F).setColor(255, 255, 255, 255)
						.setUv(quad.u()[vertex] / texSize, quad.v()[vertex] / texSize).setOverlay(overlay)
						.setLight(light).setNormal(normal.x, normal.y, normal.z);
			}
		}
	}

	private static void emitBox(VertexConsumer vertexConsumer, Matrix4f matrix, float x0, float y0, float z0, float w,
			float h, float d, float u, float v, float tex, int light, int overlay) {
		float x1 = x0 + w;
		float y1 = y0 + h;
		float z1 = z0 + d;
		if (w > 0.0F && d > 0.0F) {
			face(vertexConsumer, matrix, 0.0F, -1.0F, 0.0F, u + d, v, u + d + w, v + d, x1, y0, z1, x0, y0, z1, x0,
					y0, z0, x1, y0, z0, tex, light, overlay);
			face(vertexConsumer, matrix, 0.0F, 1.0F, 0.0F, u + d + w, v + d, u + d + w + w, v, x1, y1, z0, x0, y1, z0,
					x0, y1, z1, x1, y1, z1, tex, light, overlay);
		}
		if (w > 0.0F && h > 0.0F) {
			face(vertexConsumer, matrix, 0.0F, 0.0F, -1.0F, u + d, v + d, u + d + w, v + d + h, x1, y0, z0, x0, y0,
					z0, x0, y1, z0, x1, y1, z0, tex, light, overlay);
			face(vertexConsumer, matrix, 0.0F, 0.0F, 1.0F, u + d + w + d, v + d, u + d + w + d + w, v + d + h, x0, y0,
					z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, tex, light, overlay);
		}
		if (d > 0.0F && h > 0.0F) {
			face(vertexConsumer, matrix, -1.0F, 0.0F, 0.0F, u, v + d, u + d, v + d + h, x0, y0, z0, x0, y0, z1, x0,
					y1, z1, x0, y1, z0, tex, light, overlay);
			face(vertexConsumer, matrix, 1.0F, 0.0F, 0.0F, u + d + w, v + d, u + d + w + d, v + d + h, x1, y0, z1, x1,
					y0, z0, x1, y1, z0, x1, y1, z1, tex, light, overlay);
		}
	}

	private static void emitBoxUv(VertexConsumer vertexConsumer, Matrix4f matrix, float x0, float y0, float z0, float w,
			float h, float d, float u, float vCap, float va, float vb, boolean capSwap, int light, int overlay) {
		float x1 = x0 + w;
		float y1 = y0 + h;
		float z1 = z0 + d;
		float capA = capSwap ? u + d + w : u + d;
		float capB = capA + w;
		float capC = capSwap ? u + d : u + d + w;
		float capD = capC + w;
		face(vertexConsumer, matrix, 0.0F, -1.0F, 0.0F, capA, vCap, capB, vCap + d, x1, y0, z1, x0, y0, z1, x0, y0, z0,
				x1, y0, z0, 64.0F, light, overlay);
		face(vertexConsumer, matrix, 0.0F, 1.0F, 0.0F, capC, vCap + d, capD, vCap, x1, y1, z0, x0, y1, z0, x0, y1, z1,
				x1, y1, z1, 64.0F, light, overlay);
		face(vertexConsumer, matrix, 0.0F, 0.0F, -1.0F, u + d, va, u + d + w, vb, x1, y0, z0, x0, y0, z0, x0, y1, z0,
				x1, y1, z0, 64.0F, light, overlay);
		face(vertexConsumer, matrix, 0.0F, 0.0F, 1.0F, u + d + w + d, va, u + d + w + d + w, vb, x0, y0, z1, x1, y0, z1,
				x1, y1, z1, x0, y1, z1, 64.0F, light, overlay);
		face(vertexConsumer, matrix, -1.0F, 0.0F, 0.0F, u, va, u + d, vb, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1,
				z0, 64.0F, light, overlay);
		face(vertexConsumer, matrix, 1.0F, 0.0F, 0.0F, u + d + w, va, u + d + w + d, vb, x1, y0, z1, x1, y0, z0, x1,
				y1, z0, x1, y1, z1, 64.0F, light, overlay);
	}

	private static void face(VertexConsumer vertexConsumer, Matrix4f matrix, float nx, float ny, float nz, float uA,
			float vA, float uB, float vB, float ax, float ay, float az, float bx, float by, float bz, float cx,
			float cy, float cz, float dx, float dy, float dz, float tex, int light, int overlay) {
		Vector3f normal = matrix.transformDirection(new Vector3f(nx, ny, nz));
		vertexConsumer.addVertex(matrix, ax / 16.0F, ay / 16.0F, az / 16.0F).setColor(255, 255, 255, 255)
				.setUv(uB / tex, vA / tex).setOverlay(overlay).setLight(light).setNormal(normal.x, normal.y, normal.z);
		vertexConsumer.addVertex(matrix, bx / 16.0F, by / 16.0F, bz / 16.0F).setColor(255, 255, 255, 255)
				.setUv(uA / tex, vA / tex).setOverlay(overlay).setLight(light).setNormal(normal.x, normal.y, normal.z);
		vertexConsumer.addVertex(matrix, cx / 16.0F, cy / 16.0F, cz / 16.0F).setColor(255, 255, 255, 255)
				.setUv(uA / tex, vB / tex).setOverlay(overlay).setLight(light).setNormal(normal.x, normal.y, normal.z);
		vertexConsumer.addVertex(matrix, dx / 16.0F, dy / 16.0F, dz / 16.0F).setColor(255, 255, 255, 255)
				.setUv(uB / tex, vB / tex).setOverlay(overlay).setLight(light).setNormal(normal.x, normal.y, normal.z);
	}

	private static Quaternionf between(Vector3f from, Vector3f to) {
		Vector3f f = new Vector3f(from).normalize();
		Vector3f t = new Vector3f(to).normalize();
		float dot = Mth.clamp(f.dot(t), -1.0F, 1.0F);
		Vector3f axis = new Vector3f(f).cross(t);
		if (axis.lengthSquared() < 1.0E-7F) {
			return dot > 0.0F ? new Quaternionf() : new Quaternionf().rotationX((float) Math.PI);
		}
		axis.normalize();
		return new Quaternionf(new AxisAngle4f((float) Math.acos(dot), axis.x, axis.y, axis.z));
	}

	private static RenderType skinLayer(Identifier texture) {
		if (skinId == null || !skinId.equals(texture)) {
			skinId = texture;
			skinLayer = RenderTypes.entityCutout(texture);
		}
		return skinLayer;
	}

	private static float mirror(float x, boolean leftHand) {
		return leftHand ? 16.0F - x : x;
	}

	private static float lerp(float a, float b, float t) {
		return a + (b - a) * t;
	}

	private static float seg(float t, float a, float b) {
		return b <= a ? 1.0F : Mth.clamp((t - a) / (b - a), 0.0F, 1.0F);
	}

	private static float ease(float t) {
		float c = Mth.clamp(t, 0.0F, 1.0F);
		return c * c * (3.0F - 2.0F * c);
	}

	private static float[] support(WeaponCategory category) {
		return switch (category) {
			case PISTOL -> new float[] { 6.0F, 4.6F, 10.2F };
			case REVOLVER -> new float[] { 6.0F, 4.8F, 10.0F };
			case SHOTGUN_DOUBLE -> new float[] { 6.2F, 5.8F, 8.6F };
			case SHOTGUN_PUMP -> new float[] { 6.2F, 5.2F, 8.0F };
			case MACHINE_GUN -> new float[] { 6.0F, 5.4F, 6.6F };
			case RIFLE -> new float[] { 6.0F, 6.4F, 5.9F };
			case SNIPER -> new float[] { 6.0F, 6.4F, 6.6F };
			case GRENADE_LAUNCHER -> new float[] { 6.1F, 5.6F, 7.2F };
			case RPG -> new float[] { 6.2F, 5.0F, 7.8F };
			default -> new float[] { 6.0F, 5.6F, 7.0F };
		};
	}

	private static float[] grab(WeaponCategory category) {
		return switch (category) {
			case PISTOL, RIFLE, SNIPER -> new float[] { -2.9F, -2.2F, 0.0F };
			case MACHINE_GUN -> new float[] { -2.8F, -1.8F, 0.0F };
			case REVOLVER -> new float[] { -2.6F, -1.4F, 0.0F };
			case SHOTGUN_DOUBLE -> new float[] { -1.8F, -1.6F, 0.0F };
			case SHOTGUN_PUMP -> new float[] { -2.6F, -2.8F, 0.0F };
			case GRENADE_LAUNCHER -> new float[] { -2.8F, -1.8F, 0.0F };
			case RPG -> new float[] { -2.6F, -1.4F, 0.0F };
			default -> new float[] { -2.8F, -2.0F, 0.0F };
		};
	}

	private static String partName(WeaponCategory category) {
		return switch (category) {
			case PISTOL, RIFLE, SNIPER -> "mag";
			case REVOLVER -> "cylinder";
			case SHOTGUN_DOUBLE -> "shell1";
			case SHOTGUN_PUMP -> "pump";
			case MACHINE_GUN -> "belt";
			case GRENADE_LAUNCHER -> "grenade";
			case RPG -> "rocket";
			default -> null;
		};
	}

	private static String rackPart(WeaponCategory category) {
		return switch (category) {
			case PISTOL -> "slide";
			case RIFLE, SNIPER, MACHINE_GUN -> "bolt";
			default -> null;
		};
	}

	private static float[] rackPos(WeaponModel model, WeaponCategory category, boolean leftHand) {
		String name = rackPart(category);
		if (name == null) {
			return null;
		}
		float[] anchor = model.anchor("rack");
		if (anchor != null) {
			return new float[] { mirror(anchor[0], leftHand), anchor[1], anchor[2] };
		}
		for (WeaponModel.Part part : model.parts()) {
			if (part.name().equals(name)) {
				return new float[] { mirror(part.pivotX() - 0.8F, leftHand), part.pivotY() + 1.8F,
						part.pivotZ() + 0.6F };
			}
		}
		return null;
	}

	private static float[] pivot(WeaponModel model, String name) {
		if (name == null) {
			return null;
		}
		for (WeaponModel.Part part : model.parts()) {
			if (part.name().equals(name)) {
				return new float[] { part.pivotX(), part.pivotY(), part.pivotZ() };
			}
		}
		return null;
	}

	private static float[] partT(WeaponAnim.Frame frame, String name) {
		WeaponAnim.PartPose pose = frame.parts().get(name);
		return pose == null ? ZERO : pose.t();
	}

	private static Plan plan(WeaponCategory category) {
		return switch (category) {
			case PISTOL -> new Plan(0.05F, 0.10F, 0.19F, 0.34F, 0.40F, 0.46F, 0.51F, 0.55F, 0.75F, true, true);
			case REVOLVER -> new Plan(0.06F, 0.14F, 0.30F, 0.46F, 0.50F, 0.72F, 0.82F, 0.82F, 0.82F, false, false);
			case SHOTGUN_DOUBLE -> new Plan(0.06F, 0.14F, 0.40F, 0.54F, 0.56F, 0.66F, 0.76F, 0.76F, 0.76F, false, false);
			case MACHINE_GUN -> new Plan(0.06F, 0.10F, 0.26F, 0.44F, 0.46F, 0.66F, 0.76F, 0.86F, 0.96F, true, false);
			case RIFLE -> new Plan(0.06F, 0.12F, 0.22F, 0.40F, 0.44F, 0.58F, 0.66F, 0.72F, 0.92F, true, true);
			case SNIPER -> new Plan(0.06F, 0.12F, 0.22F, 0.42F, 0.46F, 0.56F, 0.64F, 0.68F, 0.92F, true, true);
			case GRENADE_LAUNCHER -> new Plan(0.08F, 0.16F, 0.30F, 0.44F, 0.50F, 0.64F, 0.76F, 0.76F, 0.76F, false, false);
			case RPG -> new Plan(0.08F, 0.15F, 0.62F, 0.72F, 0.72F, 0.80F, 0.86F, 0.86F, 0.86F, false, false);
			default -> new Plan(0.06F, 0.12F, 0.22F, 0.40F, 0.44F, 0.60F, 0.74F, 0.74F, 0.74F, false, false);
		};
	}
}
