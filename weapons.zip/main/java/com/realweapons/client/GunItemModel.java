package com.realweapons.client;

import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.realweapons.RealWeaponsMod;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.item.ModelRenderProperties;
import net.minecraft.client.resources.model.ResolvableModel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

public class GunItemModel implements ItemModel {
	private static final Supplier<Vector3fc[]> EXTENTS = Suppliers.memoize(() -> new Vector3fc[] {
			new Vector3f(-0.6F, -0.6F, -0.6F), new Vector3f(0.6F, 0.6F, 0.6F) });

	private final String weapon;
	private final ModelRenderProperties properties;

	public GunItemModel(String weapon, ModelRenderProperties properties) {
		this.weapon = weapon;
		this.properties = properties;
	}

	@Override
	public void update(ItemStackRenderState itemStackRenderState, ItemStack itemStack,
			ItemModelResolver itemModelResolver, ItemDisplayContext itemDisplayContext,
			@Nullable ClientLevel clientLevel, @Nullable ItemOwner itemOwner, int seed) {
		itemStackRenderState.setAnimated();
		itemStackRenderState.appendModelIdentityElement(this);
		Entity entity = itemOwner == null ? null : itemOwner.asLivingEntity();
		ItemDisplayContext context = itemDisplayContext;
		if (FpState.handsPass()) {
			if (itemDisplayContext == ItemDisplayContext.THIRD_PERSON_LEFT_HAND) {
				context = ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
			} else if (itemDisplayContext == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND) {
				context = ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
			}
		}
		ItemStackRenderState.LayerRenderState layer = itemStackRenderState.newLayer();
		layer.setupSpecialModel(GunRenderer.INSTANCE, new GunRenderer.RenderData(this.weapon, entity, context));
		this.properties.applyToLayer(layer, context);
		layer.setExtents(EXTENTS);
	}

	public record Unbaked(String weapon, Identifier base) implements ItemModel.Unbaked {
		public static final MapCodec<Unbaked> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
				Codec.STRING.fieldOf("weapon").forGetter(Unbaked::weapon),
				Identifier.CODEC.fieldOf("base").forGetter(Unbaked::base)
		).apply(instance, Unbaked::new));

		@Override
		public MapCodec<? extends ItemModel.Unbaked> type() {
			return MAP_CODEC;
		}

		@Override
		public void resolveDependencies(ResolvableModel.Resolver resolver) {
			resolver.markDependency(this.base);
		}

		@Override
		public ItemModel bake(ItemModel.BakingContext context) {
			var baker = context.blockModelBaker();
			var resolved = baker.getModel(this.base);
			var properties = ModelRenderProperties.fromResolvedModel(baker, resolved, resolved.getTopTextureSlots());
			return new GunItemModel(this.weapon, properties);
		}
	}
}
