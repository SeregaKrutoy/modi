package com.realweapons;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record HitMarkerPayload(boolean headshot) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<HitMarkerPayload> TYPE =
			new CustomPacketPayload.Type<>(RealWeaponsMod.id("hit_marker"));

	public static final StreamCodec<RegistryFriendlyByteBuf, HitMarkerPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL, HitMarkerPayload::headshot,
			HitMarkerPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
