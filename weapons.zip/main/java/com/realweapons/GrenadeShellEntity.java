package com.realweapons;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GrenadeShellEntity extends BaseGrenadeEntity {
	public GrenadeShellEntity(EntityType<GrenadeShellEntity> entityType, Level level) {
		super(entityType, level);
	}

	public GrenadeShellEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.GRENADE_SHELL, owner, level, stack);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("grenade_launcher");
	}

	@Override
	protected int fuseTicks() {
		return 120;
	}

	@Override
	protected boolean impactDetonates() {
		return true;
	}

	@Override
	protected void detonate(ServerLevel level) {
		WeaponFx.explosion(level, this.position(), 2.8F, this.getOwner());
		WeaponFx.playSound(level, this.position(), "explosion.grenade", 6.0F, 1.05F);
	}
}
