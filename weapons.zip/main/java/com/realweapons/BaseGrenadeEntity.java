package com.realweapons;

import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public abstract class BaseGrenadeEntity extends ThrowableItemProjectile {
	protected BaseGrenadeEntity(EntityType<? extends BaseGrenadeEntity> entityType, Level level) {
		super(entityType, level);
	}

	protected BaseGrenadeEntity(EntityType<? extends BaseGrenadeEntity> entityType, LivingEntity owner, Level level,
			ItemStack itemStack) {
		super(entityType, owner, level, itemStack);
	}

	protected abstract int fuseTicks();

	protected abstract boolean impactDetonates();

	protected abstract void detonate(ServerLevel level);

	@Override
	protected double getDefaultGravity() {
		return 0.035;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.clientFx();
			return;
		}
		if (!this.isAlive()) {
			return;
		}
		int fuse = this.fuseTicks();
		if (fuse > 0 && this.tickCount >= fuse) {
			this.detonateNow();
		}
	}

	@Override
	protected void onHit(HitResult hitResult) {
		if (this.level().isClientSide()) {
			return;
		}
		if (this.impactDetonates()) {
			this.detonateNow();
			return;
		}

		Vec3 normal;
		if (hitResult instanceof BlockHitResult blockHit) {
			Direction direction = blockHit.getDirection();
			normal = new Vec3(direction.getStepX(), direction.getStepY(), direction.getStepZ());
		} else if (hitResult instanceof EntityHitResult entityHit) {
			normal = this.position().subtract(entityHit.getEntity().position());
			if (normal.lengthSqr() < 1.0E-4) {
				normal = new Vec3(0.0, 1.0, 0.0);
			} else {
				normal = normal.normalize();
			}
		} else {
			return;
		}

		Vec3 motion = this.getDeltaMovement();
		Vec3 reflected = motion.subtract(normal.scale(2.0 * motion.dot(normal))).scale(0.42);
		if (reflected.length() < 0.04) {
			reflected = Vec3.ZERO;
		}
		this.setDeltaMovement(reflected);
		this.setPos(this.position().add(normal.scale(0.02)));

		if (reflected.lengthSqr() > 0.01) {
			SoundEvent sound = ModContent.sound("bounce.clink");
			if (sound != null) {
				this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.PLAYERS, 0.5F,
						0.9F + this.random.nextFloat() * 0.25F);
			}
		}
	}

	protected void detonateNow() {
		if (!(this.level() instanceof ServerLevel serverLevel)) {
			return;
		}
		this.detonate(serverLevel);
		this.discard();
	}

	protected void clientFx() {
		if (this.impactDetonates()) {
			return;
		}
		int fuse = this.fuseTicks();
		if (fuse > 0 && fuse - this.tickCount < 24 && this.tickCount % 2 == 0) {
			this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.2, this.getZ(), 0.0, 0.015,
					0.0);
		}
	}
}
