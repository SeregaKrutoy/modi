package com.realweapons;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class RocketEntity extends BaseGrenadeEntity {
	public RocketEntity(EntityType<RocketEntity> entityType, Level level) {
		super(entityType, level);
		this.setNoGravity(true);
	}

	public RocketEntity(Level level, LivingEntity owner, ItemStack stack) {
		super(ModContent.ROCKET, owner, level, stack);
		this.setNoGravity(true);
	}

	@Override
	protected Item getDefaultItem() {
		return ModContent.item("rpg");
	}

	@Override
	protected double getDefaultGravity() {
		return 0.0;
	}

	@Override
	protected int fuseTicks() {
		return 260;
	}

	@Override
	protected boolean impactDetonates() {
		return true;
	}

	@Override
	protected void detonate(ServerLevel level) {
		Vec3 pos = this.position();
		WeaponFx.explosion(level, pos, 5.5F, this.getOwner());
		WeaponFx.playSound(level, pos, "explosion.rpg", 12.0F, 1.0F);
	}

	@Override
	protected void clientFx() {
		Vec3 motion = this.getDeltaMovement();
		this.level().addParticle(ParticleTypes.FLAME, this.getX(), this.getY(), this.getZ(), -motion.x * 0.2,
				-motion.y * 0.2 + 0.01, -motion.z * 0.2);
		this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), -motion.x * 0.1, 0.0,
				-motion.z * 0.1);
	}
}
