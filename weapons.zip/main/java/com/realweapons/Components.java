package com.realweapons;

import com.mojang.serialization.Codec;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;

public final class Components {
	public static final DataComponentType<Magazine> MAGAZINE = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			ResourceKey.create(Registries.DATA_COMPONENT_TYPE, RealWeaponsMod.id("magazine")),
			DataComponentType.<Magazine>builder()
					.persistent(Magazine.CODEC)
					.networkSynchronized(Magazine.STREAM_CODEC)
					.cacheEncoding()
					.build()
	);

	private Components() {
	}

	public record Magazine(int count) {
		public static final Codec<Magazine> CODEC = Codec.INT.xmap(Magazine::new, Magazine::count);
		public static final StreamCodec<ByteBuf, Magazine> STREAM_CODEC = ByteBufCodecs.VAR_INT.map(Magazine::new, Magazine::count);
	}
}
