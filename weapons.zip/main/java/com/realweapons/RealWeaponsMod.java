package com.realweapons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;

public class RealWeaponsMod implements ModInitializer {
	public static final String MOD_ID = "realweapons";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModContent.register();
		ServerState.register();

		PayloadTypeRegistry.playC2S().register(FirePayload.TYPE, FirePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ReloadPayload.TYPE, ReloadPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(WeaponEventPayload.TYPE, WeaponEventPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(HitMarkerPayload.TYPE, HitMarkerPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(FirePayload.TYPE, (payload, context) ->
				context.server().execute(() -> FireLogic.fire(context.player(), payload.aiming())));
		ServerPlayNetworking.registerGlobalReceiver(ReloadPayload.TYPE, (payload, context) ->
				context.server().execute(() -> FireLogic.reload(context.player())));
	}
}
