package com.realweapons;

import net.minecraft.world.item.Item;

public class WeaponItem extends Item {
	private final WeaponSpec spec;

	public WeaponItem(WeaponSpec spec, Item.Properties properties) {
		super(properties);
		this.spec = spec;
	}

	public WeaponSpec spec() {
		return this.spec;
	}
}
