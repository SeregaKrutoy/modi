package com.realweapons;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class ServerState {
	private static final Map<UUID, Long> LAST_ACTION = new HashMap<>();
	private static final Map<UUID, Long> LAST_DRY = new HashMap<>();
	private static final Map<UUID, Reload> RELOADS = new HashMap<>();
	private static final List<SmokeCloud> CLOUDS = new ArrayList<>();

	private ServerState() {
	}

	public record Reload(String weapon, long endTick) {
	}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(ServerState::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			LAST_ACTION.clear();
			LAST_DRY.clear();
			RELOADS.clear();
			CLOUDS.clear();
		});
	}

	public static boolean onCooldown(ServerPlayer player, WeaponSpec spec, long now) {
		Long last = LAST_ACTION.get(player.getUUID());
		return last != null && now - last < spec.interval();
	}

	public static void markAction(ServerPlayer player, long now) {
		LAST_ACTION.put(player.getUUID(), now);
	}

	public static boolean dryCooldown(ServerPlayer player, long now) {
		Long last = LAST_DRY.get(player.getUUID());
		return last == null || now - last >= 10;
	}

	public static void markDry(ServerPlayer player, long now) {
		LAST_DRY.put(player.getUUID(), now);
	}

	public static boolean isReloading(ServerPlayer player) {
		return RELOADS.containsKey(player.getUUID());
	}

	public static void startReload(ServerPlayer player, String weapon, long endTick) {
		RELOADS.put(player.getUUID(), new Reload(weapon, endTick));
	}

	public static void cancelReload(ServerPlayer player) {
		RELOADS.remove(player.getUUID());
	}

	public static void addCloud(SmokeCloud cloud) {
		CLOUDS.add(cloud);
	}

	private static void tick(MinecraftServer server) {
		long time = server.overworld().getGameTime();

		Iterator<Map.Entry<UUID, Reload>> reloads = RELOADS.entrySet().iterator();
		while (reloads.hasNext()) {
			Map.Entry<UUID, Reload> entry = reloads.next();
			if (time >= entry.getValue().endTick()) {
				reloads.remove();
				ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
				if (player != null && player.isAlive()) {
					FireLogic.finishReload(player, entry.getValue().weapon());
				}
			}
		}

		Iterator<SmokeCloud> clouds = CLOUDS.iterator();
		while (clouds.hasNext()) {
			if (!clouds.next().tick()) {
				clouds.remove();
			}
		}
	}
}
